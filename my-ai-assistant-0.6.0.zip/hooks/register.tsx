// My AI Assistant プラグイン版（試作）の本体。
//
// 1) セッションが始まったら、手元の小さな Web サーバー（server/server.py・127.0.0.1:8790）を起動する
// 2) 1 秒ごとにサーバーへ「画面から頼まれた仕事はある？」と取りに行く（$.http.fetch）
// 3) 仕事があれば、この Claude の中で動かす
//      chat  モード（既定）: $.prompt.submit でこの会話に流す（待ち行列で1件ずつ。答えは turn.complete）
//      agent モード: $.agent.spawn でサブエージェントに頼む（自動モードでは拒否されることがある）
// 4) 答えをサーバーへ返す → 画面に出る
// 5) 本会話（agentId なし）の turn.start / turn.step / turn.complete のたびに、会話の中身（$.session.messages）を
//    画面用の形に直してサーバーへ送る（POST /api/bridge/state）。Code タブで人が打った発言も含めて会話全体を出す
//
// 6) 段5の補助機能:
//    使用量: $.session.usage() を読み、会話の量（context）と利用上限（usage）に直して state に載せる
//    入力の予測: 画面が頼んだとき（mode: suggest の依頼）だけ $.model.complete(haiku) で1つ作る（1時間30回まで）
//    履歴検索: $.tool.register で search_history・read_session・list_memory を出し、サーバーの /api/history/* を呼んで答える
//    ▶ 実行: 画面は「次のコマンドを実行してください」の依頼を chat の待ち行列で会話に入れるだけ（サーバーでは実行しない）
//
// 7) 段7の設定（画面の「設定」→「アシスタント」）: 表示名・執行役への追加の指示・部署。
//    画面 → POST /api/settings（サーバーが検証して mode:'settings' の依頼にする）→ ここで受け取り、もう一度検証して $.store に保存
//    → 部署を $.agent.register で登録し直す → サーバーへ今の値を知らせる（POST /api/bridge/settings）。$.store の値が config/org.json より優先
//
// 8) Web 版（W3・既定は使わない）: 画面を持っている会話（8790 を起動した会話）だけが、bridge/bridge.mjs（node）を子プロセスとして起動する。
//    橋渡しは中継（Supabase の Broadcast）につなぎ、許した操作だけを手元のサーバーへ渡す（許可リストは bridge/lib/ops.mjs）。
//    プラグイン → 橋渡しは制御窓口（127.0.0.1・ランダムなポート・合言葉つき）の HTTP、橋渡し → プラグインは標準出力の JSON 行
//    （$.process.spawn は起動後に標準入力へ書けないため）。ペアリングの6桁の見比べは $.ui.ask で必ず聞く。
//    コマンド: /my-ai-assistant web-on | web-off | web-pair | web-list | web-revoke <名前> | web-history on|off
//
// `claude -p` を別に起動することはしない。動くのは、利用者が開いている Claude Code のセッションそのもの。
import { atom, read, update } from 'claude-code'
import type { AgentInfo, EngineInterface, Register, SessionContextUsage, SessionMessage, SessionRateLimit } from 'claude-code'

import type { MyAiAssistantStatus } from '../types'

export const VERSION = '0.6.0'
export const PORT = 8790 // 8787 は旧版（別の常駐アプリ）の画面なので使わない
export const BASE = `http://127.0.0.1:${PORT}`
export const APP = 'my-ai-assistant'
const PANE = 'my-ai-assistant'
const POLL_MS = 1000
// 別のセッションが 8790 を持っているとき、空いたかを確かめる間隔（空いたらこのセッションが引き継ぐ）
export const TAKEOVER_MS = 5000
// chat モードで会話に入れた依頼の turn が、この時間たっても始まらなければ諦めて次へ進む
export const CHAT_START_TIMEOUT_MS = 5 * 60 * 1000
// 会話の中身をサーバーへ送る間隔の下限（turn.step の間引き）と、送る本文の大きさの上限
export const STATE_MIN_MS = 2000
export const STATE_MAX_BYTES = 1_500_000
// 仕事（部署の動き）: agent.list の見直し間隔、仕事の最大件数、道具ログの最大件数
export const AGENT_SYNC_MS = 5000
// 新しい版が入っていないかを見る間隔（持ち主のとき）
export const VERSION_CHECK_MS = 10000
export const MAX_TASKS = 60
export const MAX_TOOLS = 40
// 画面から開けるファイルの種類（server.py の DOC_EXT と同じ。できたファイルの候補をここで絞る）
const DOC_EXT = ['.xlsx', '.xls', '.xlsm', '.csv', '.pdf', '.docx', '.doc', '.pptx', '.png', '.jpg', '.jpeg', '.zip', '.dxf', '.txt', '.md']
const WRITE_TOOLS = ['Write', 'Edit', 'MultiEdit', 'NotebookEdit']
// 部署（org.json）の登録名の前置き。`$.agent.register` は「<プラグイン名>:<name>」で登録する
export const DEPT_PREFIX = 'my-ai-assistant:'
// agent モードが拒否されたときに画面へ返す案内（自動モードの安全確認に止められる）
export const AGENT_DENIED_HINT =
  'agent モードは、デスクトップの自動モードでは安全確認に止められることがあります。画面で「この会話で頼む（chat モード）」を選んで、もう一度頼んでください。'

// ---- Web 版（W3） ----
export const WEB_STORE_KEY = 'web' // $.store: { enabled: boolean, history?: boolean }。既定は使わない・履歴は読めない
export const WEB_STATUS_MS = 3000 // 橋渡しの状態を取りに行く間隔（親が生きている合図も兼ねる。橋渡しは 45 秒途絶えると止まる）
export const WEB_RETRY_MS = 15000 // 橋渡しが落ちたあと、起こし直すまでの間隔
export const WEB_STOP_WAIT_MS = 5000 // 止める合図（quit）のあと、この間に止まらなければ子プロセスを止める
export const WEB_SAS_WAIT_MS = 300000 // 6桁の見比べを待つ長さ（橋渡し側の sasTimeoutMs と同じ 5 分。ブラウザ側の待ち 310 秒より短い）
export const WEB_NO_NODE = 'node 22 以降が要ります（Web 版を使うときだけ）。入れてから /my-ai-assistant web-on をもう一度打ってください'
export const SAS_YES = '一致（登録する）'
export const SAS_NO = '違う（登録しない）'
export const WEB_HELP = [
  'Web 版のコマンド:',
  '  /my-ai-assistant web-on          Web 版を使う（既定は使わない。node 22 以降が要ります）',
  '  /my-ai-assistant web-pair        ペアリングの番号を出す（ブラウザに入れる。6桁の見比べを聞きます）',
  '  /my-ai-assistant web-ok          確認用の6桁がブラウザと同じ（登録する）',
  '  /my-ai-assistant web-ng          確認用の6桁が違う（登録しない）',
  '  /my-ai-assistant web-list        登録したブラウザの一覧',
  '  /my-ai-assistant web-revoke 名前  登録を取り消す（同じ名前が複数なら、web-list の指紋の先頭で）',
  '  /my-ai-assistant web-history on|off  Web から会話の履歴を読めるようにするか（既定は読めない）',
  '  /my-ai-assistant web-off         Web 版をすぐ切る（橋渡しを止め、Web から来て会話に入る前の依頼を捨て、設定を「使わない」に）',
  'コマンドは Claude の会話の入力欄に打ちます（画面の「▶ 実行」やターミナルではありません）。',
].join('\n')

// 執行役の人格・決まり（汎用ひな形）。個人名・社名は入れない。利用者が書き換えてよい。
export const EXECUTIVE_SYSTEM = [
  '# 執行役',
  'あなたは利用者の「執行役」です。依頼を受け、自分で答えるか、部署（サブエージェント）に任せるかを決め、結果をまとめて返します。',
  '- 依頼の範囲だけをやる。頼まれていないことに広げない。',
  '- 部署に任せるときは Agent ツールを使い、subagent_type に下の部署の登録名を指定する。短い依頼は自分で答えてよい。',
  '- 外部への送信（メール・メッセージ・投稿など、他人に届くもの）は実行しない。文面と送り先をまとめて報告して止まる。',
  '- git の commit・push・ブランチ切り替えは、利用者に頼まれたときだけ行う。',
  '- ファイルを作ったら、置き場所を絶対パスで書く。',
  '- 値や数字を自分の判断で作らない。分からないことは「分からない」と書く。',
  '- 過去のやりとり・決めたこと・ユーザー指示は、道具 search_history（read_session・list_memory も）で調べられる。依頼に関係しそうなときは先に調べる。',
  '- 返事は日本語で、結論を先に、短く。実物で確かめたことと、まだ確かめていないことを分けて書く。',
  '- Web 版のペアリングの6桁は、利用者が Claude Code のペインで見比べて、ボタンかコマンドで答える。手順を長く説明せず、ペインを見るよう一言で案内する。',
  '- /my-ai-assistant のコマンドは、執行役からは実行できない（利用者が打つ）。',
].join('\n')

type Dept = {
  name: string
  label?: string
  description: string
  prompt: string
  model?: string
  effort?: string | number
  tools?: string[]
  image?: string
  color?: string
}
type Org = { defaults?: { model?: string; effort?: string | number }; departments: unknown[]; executive?: { title?: string } }

// ---- 設定（段7）。上限・規則は server/server.py（validate_settings）と同じ。変えるときは両方を直す ----
export const SETTINGS_KEY = 'settings'
export const DEFAULT_NAME = 'My AI Assistant'
export const LIMITS = { displayName: 30, extraInstructions: 2000, departments: 12, deptName: 32, label: 20, description: 300, prompt: 4000, tools: 30 } as const
export const ROLE_IMAGES = ['executive', 'planning', 'analyst', 'programmer', 'designer', 'support', 'hr', 'marketing', 'sales', 'accounting'] as const
export const EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const
const DEPT_NAME_RE = /^[a-z0-9][a-z0-9-]*$/
const MODEL_RE = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/
const TOOL_RE = /^[A-Za-z0-9_*:.-]{1,100}$/
const COLOR_RE = /^#[0-9a-fA-F]{6}$/
const CTRL = /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/ // 改行・タブ以外の制御文字
const CTRL_LINE = /[\x00-\x1f\x7f]/ // 1行の欄: 改行・タブも不可
const ROLE_IMAGE_OF: Record<string, string> = { planning: 'planning', research: 'analyst', programmer: 'programmer', designer: 'designer', general: 'support' }
export type SettingsPatch = { displayName?: string | null; extraInstructions?: string; departments?: Dept[] | null }

// 文字数はコードポイントで数える（server.py の len() と同じ）。前後の空白は除く
function textField(v: unknown, name: string, max: number, line: boolean, required = false): string {
  if (typeof v !== 'string') throw new Error(`${name}は文字列で入れてください`)
  const t = v.trim()
  if ((line ? CTRL_LINE : CTRL).test(t)) throw new Error(line ? `${name}に使えない文字（改行や制御文字）が入っています` : `${name}に使えない制御文字が入っています`)
  const n = Array.from(t).length
  if (n > max) throw new Error(`${name}は${max}文字までです（いま${n}文字）`)
  if (required && t === '') throw new Error(`${name}を入れてください`)
  return t
}
const blank = (v: unknown) => v === undefined || v === null || v === ''

export function cleanDept(raw: unknown, index: number, defaults: { model?: string; effort?: string | number } = {}): Dept {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) throw new Error(`部署${index + 1}の形が違います`)
  const r = raw as Record<string, unknown>
  const name = textField(r.name, `部署${index + 1}の名前`, LIMITS.deptName, true, true)
  if (!DEPT_NAME_RE.test(name)) throw new Error(`部署の名前「${name}」は、半角の英小文字・数字・ハイフンだけにしてください（先頭は英小文字か数字）`)
  const out: Dept = {
    name,
    label: textField(blank(r.label) ? name : r.label, `部署「${name}」の表示名`, LIMITS.label, true),
    description: textField(r.description, `部署「${name}」の説明`, LIMITS.description, true, true),
    prompt: textField(r.prompt, `部署「${name}」の指示`, LIMITS.prompt, false, true),
  }
  const model = blank(r.model) ? (defaults.model ?? 'sonnet') : r.model
  if (typeof model !== 'string' || !MODEL_RE.test(model)) throw new Error(`部署「${name}」のモデルの指定が正しくありません`)
  out.model = model
  const effort = r.effort ?? defaults.effort
  if (effort !== undefined) {
    const ok = (typeof effort === 'string' && (EFFORTS as readonly string[]).includes(effort)) || (typeof effort === 'number' && Number.isInteger(effort) && effort >= 1 && effort <= 200000)
    if (!ok) throw new Error(`部署「${name}」の effort が正しくありません`)
    out.effort = effort
  }
  if (r.tools !== undefined && r.tools !== null) {
    const t = r.tools
    if (!Array.isArray(t) || t.length > LIMITS.tools || !t.every(x => typeof x === 'string' && TOOL_RE.test(x))) throw new Error(`部署「${name}」の tools の指定が正しくありません`)
    out.tools = [...(t as string[])]
  }
  const image = blank(r.image) ? (ROLE_IMAGE_OF[name] ?? 'support') : r.image
  if (typeof image !== 'string' || !(ROLE_IMAGES as readonly string[]).includes(image)) throw new Error(`部署「${name}」の画像の指定が正しくありません`)
  out.image = image
  const color = blank(r.color) ? '#5b6677' : r.color
  if (typeof color !== 'string' || !COLOR_RE.test(color)) throw new Error(`部署「${name}」の色の指定が正しくありません`)
  out.color = color
  return out
}

// 設定の更新（部分でよい）を検証する。返り値は「渡された項目だけ」。不正なら Error（日本語の理由）
// displayName: null か空 → 既定に戻す（null）。extraInstructions: null → ''。departments: null → 既定（org.json）に戻す
export function validateSettings(raw: unknown): SettingsPatch {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) throw new Error('設定の形が違います')
  const r = raw as Record<string, unknown>
  const out: SettingsPatch = {}
  if ('displayName' in r) {
    const v = r.displayName
    out.displayName = v === null || (typeof v === 'string' && v.trim() === '') ? null : textField(v, '表示名', LIMITS.displayName, true)
  }
  if ('extraInstructions' in r) out.extraInstructions = r.extraInstructions === null ? '' : textField(r.extraInstructions, '執行役への追加の指示', LIMITS.extraInstructions, false)
  if ('departments' in r) {
    const v = r.departments
    if (v === null) out.departments = null
    else {
      if (!Array.isArray(v)) throw new Error('部署は一覧で入れてください')
      if (v.length > LIMITS.departments) throw new Error(`部署は${LIMITS.departments}件までです（いま${v.length}件）`)
      const seen = new Set<string>()
      out.departments = v.map((x, i) => {
        const d = cleanDept(x, i)
        if (seen.has(d.name)) throw new Error(`部署の名前「${d.name}」が重なっています`)
        seen.add(d.name)
        return d
      })
    }
  }
  return out
}

// 部署の一覧を SYSTEM 文の後ろに付ける文（部署が1つも登録できていなければ付けない）
export function departmentsSection(depts: readonly Dept[]): string {
  if (depts.length === 0) return ''
  return ['## 部署（subagent_type に指定する登録名）', ...depts.map(d => `- ${DEPT_PREFIX}${d.name}: ${d.label ?? d.name}。${d.description}`)].join('\n')
}

// 執行役の SYSTEM 文の全体: 決まり（EXECUTIVE_SYSTEM）→ 利用者の追加の指示（空なら足さない）→ 部署の一覧
export function executiveText(extra: string, depts: readonly Dept[]): string {
  const parts = [EXECUTIVE_SYSTEM]
  if (extra.trim() !== '') parts.push(`## 利用者からの追加の指示\n${extra.trim()}`)
  const d = departmentsSection(depts)
  if (d !== '') parts.push(d)
  return parts.join('\n\n')
}

const status = atom(
  { plugin: 'my-ai-assistant', key: 'status' } as const,
  { phase: 'starting', message: '起動の準備中' } as MyAiAssistantStatus,
)
const handled = atom({ plugin: 'my-ai-assistant', key: 'handled' } as const, 0)
const last = atom({ plugin: 'my-ai-assistant', key: 'last' } as const, null as string | null)
const orgAtom = atom({ plugin: 'my-ai-assistant', key: 'org' } as const, '部署: 読み込み前')
const nameAtom = atom({ plugin: 'my-ai-assistant', key: 'name' } as const, DEFAULT_NAME) // 表示名（ペインの見出し）
const webAtom = atom({ plugin: 'my-ai-assistant', key: 'web' } as const, { line: 'Web: 使わない', pair: null, sas: null, history: false, note: null } as { line: string; pair: { code: string; expiresAt: number } | null; sas: { code: string; name: string } | null; history: boolean; note: string | null })

// mode が無いときは chat。stop は画面の「全部止める」、stoptask は画面の「この仕事を止める」（taskId・title が付く）
// internal は、会話に入れるだけで画面へ答えを返さない依頼（止められなかった仕事を執行役に頼む文）
// suggest は画面が頼んだ入力の予測（reply: 執行役の直前の返事の末尾・recent: 利用者の直近の発言・forId: 対象の返事の id）
type Job = {
  id: string
  text: string
  mode?: 'agent' | 'chat' | 'stop' | 'stoptask' | 'suggest' | 'settings'
  settings?: unknown
  taskId?: string
  title?: string
  internal?: boolean
  reply?: string
  recent?: string[]
  forId?: string
  origin?: 'web' // Web 経由の依頼（サーバーが合言葉つきの印を確かめて付ける）。webFp は橋渡しが付けた登録ブラウザの指紋
  webFp?: string
}
type SessionMsg = SessionMessage
// 画面へ送る会話の1件（server.py の clean_messages が読む形）
type ViewMsg = {
  id: string
  role: 'user' | 'assistant' | 'step' | 'files'
  text: string
  ts: string
  kind?: 'tool'
  outputs?: string[]
}
type ChatActive = { job: Job; startedAt: number; turnId?: string }
// 画面へ送る仕事の1件（server.py の clean_tasks が読む形）。部署（サブエージェント）1つ＝仕事1件。id は agentId
type TaskView = {
  id: string
  department: string
  title: string
  prompt: string
  model: string
  background: boolean
  status: 'working' | 'done' | 'failed' | 'stopped'
  startedAt: string
  finishedAt: string | null
  summary: string | null
  tools: { ts: string; text: string }[]
  live: string | null
  outputs: string[]
  parentId?: string
}
// 仕事1件の控え（画面へは view だけ送る）。toolCount: 道具ログに入れ終えた道具の数 / lastRead: 部署の会話を最後に読んだ時刻
// provisional: agent.list にまだ載っておらず、題名・部署が仮のもの
// waitingBg: 部署の turn は答えて終わったが、部署はまだ動いている（裏で動かした作業の終わりを待っている）
type TaskRec = { view: TaskView; toolCount: number; lastRead: number; provisional: boolean; waitingBg: boolean }

const PROMPT_HEAD =
  'あなたはアシスタント（試作）の担当です。画面から次の依頼が来ました。' +
  '日本語で、短く答えてください。ファイルの変更・外部への送信はしないこと。\n\n依頼:\n'

// ---- このモジュールの中だけの控え（再読み込みで消える。画面に出す値は $.state へ） ----
const mem = {
  token: '',
  webKey: '', // 手元サーバーと橋渡しで共有する、起動ごとの合言葉（Web から来た依頼の印。X-Web-Origin）
  phase: 'starting' as MyAiAssistantStatus['phase'],
  isPolling: false,
  isStarting: false,
  lastTakeoverCheck: 0,
  lastVersionCheck: 0,
  outdated: null as string | null, // 新しい版に画面を譲ったとき、その版
  platform: 'mac' as 'windows' | 'mac' | 'linux',
  agentJobs: new Map<string, string>(), // agentId -> jobId
  agentPending: new Map<string, string>(), // spawn 済みで agentId がまだ分からない jobId -> 渡した依頼文
  // chat モードは待ち行列で1件ずつ処理する。会話は1本なので、同時に会話へ入れるのは1件だけ。
  // active の turn は「入れた直後の最初の turn.start」で結び付ける（ほかに入れた依頼は無いので取り違えない）
  chatQueue: [] as Job[],
  chatActive: null as ChatActive | null,
  isPumping: false,
  mainTurnId: undefined as string | undefined, // 本会話で動いている turn（画面の「止める」で turn.abort する）
  busySince: null as string | null,
  model: null as string | null,
  lastPush: 0,
  isPushing: false,
  pushAgain: false,
  sentInitial: false,
  msgTs: [] as string[], // 会話の i 番目を初めて見た時刻（ts の代用）
  depts: [] as Dept[], // いま登録している部署（有効な設定のもの）
  orgDepts: [] as Dept[], // config/org.json の部署（検証済み）
  defaultName: DEFAULT_NAME, // org.json の executive.title（無ければ DEFAULT_NAME）
  displayName: null as string | null, // 設定の表示名（null=既定）
  extra: '', // 設定の「執行役への追加の指示」
  custom: null as Dept[] | null, // 設定の部署（null=org.json）
  settingsLoaded: false,
  settingsPushed: false, // サーバーへ今の設定を知らせ済みか（サーバーを起こし直したら false に戻す）
  paneOpen: false,
  orgTries: 0,
  orgDone: false,
  tasks: new Map<string, TaskRec>(), // agentId -> 仕事
  stopping: new Set<string>(), // 止めると決めた仕事の id（終わり方が aborted でなくても stopped にする）
  lastAgentSync: 0,
  isSyncing: false,
  stopSeq: 0,
  suggestTimes: [] as number[], // 入力の予測を作った時刻（1時間に SUGGEST_MAX_PER_HOUR 回まで）
  stopNotes: [] as string[], // 画面の止めるボタンで止めた内容の控え。次に会話へ入る発言に添えたら消す（prompt.submit の context）
  // Web 版の橋渡し。enabled は $.store の設定（既定 false）。running: 子プロセスが動いている。port/token: 制御窓口
  web: {
    enabled: false,
    history: false, // Web から会話の履歴を読んでよいか（既定は読めない。web-history on で選ぶ）
    note: null as string | null, // 「Web から設定が変わりました」などのお知らせ（ペインに出す）
    loaded: false,
    starting: false,
    running: false,
    port: null as number | null,
    token: '',
    blocked: null as string | null, // 起こせない理由（node が無いなど）。web-on をもう一度打つまで起こし直さない
    retryAt: 0,
    lastStatus: 0,
    isRefreshing: false,
    node: null as string[] | null,
    line: '',
    shownPair: null as string | null,
    lastState: null as { state?: string; browsers?: string[] } | null,
    pair: null as { code: string; expiresAt: number } | null,
    asking: Promise.resolve() as Promise<unknown>, // 6桁の見比べの質問は1つずつ
    sas: null as { id: string; code: string; name: string; expiresAt: number; settle: (yes: boolean, silent: boolean) => void } | null, // 6桁の確認中（質問かコマンドの先に答えた方を使う）
    shownSas: null as string | null,
    shownExtra: '',
    closeIter: null as (() => void) | null, // 子プロセスの流れを閉じる（閉じると子プロセスも止まる）
    killNow: null as (() => void) | null, // 流れを待つ輪を抜ける
    pid: null as number | null,
    stopping: false, // 止める合図を送った（子プロセスが終わるまで）
    stopAt: 0,
    killStage: 0, // 0: まだ 1: 流れを閉じて kill -TERM を送った 2: kill -KILL まで送った
    stoppedNote: false, // 止まったことをペインに出す
  },
}

async function setStatus($: EngineInterface, next: MyAiAssistantStatus) {
  mem.phase = next.phase
  await update($, status, () => next)
}

// ---- サーバーへ答えを返す ----
// note: 画面の会話に出す一言（止めるボタンの結果など）。count=false: 「こなした依頼」に数えない
async function sendResult($: EngineInterface, id: string, ok: boolean, text: string, opts: { note?: string; count?: boolean } = {}) {
  try {
    await $.http.fetch(`${BASE}/api/bridge/result`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bridge-Token': mem.token },
      body: JSON.stringify({ id, ok, text, ...(opts.note !== undefined ? { note: opts.note } : {}) }),
    })
  } catch (err) {
    $.ui.log(`my-ai-assistant: 答えを画面へ返せませんでした (${String(err)})`, { to: 'debug' })
  }
  if (opts.count === false) return
  await update($, handled, n => n + 1)
  await update($, last, () => (ok ? text : `失敗: ${text}`).slice(0, 80))
}

// ---- 止めたことを執行役に伝える：止めるボタンで止めた内容を控え、次の発言に context で添える ----
export const MAX_STOP_NOTES = 20
// システムプロンプトに足す執行役の節の id
export const EXEC_SECTION = 'my-ai-assistant:executive'
export function stopNote(title: string): string {
  return `（画面の止めるボタンで『${title.replace(/\s+/g, ' ').trim()}』を止めました）`
}
export function withStopNotes(text: string, notes: readonly string[]): string {
  return notes.length === 0 ? text : `${text}\n\n${notes.join('\n')}`
}
// 本文の末尾に添えた控え（withStopNotes）を、画面の表示では外す（止めるボタン・設定の変更、どちらも「（画面の」で始まる1行）
const STOP_NOTES_TAIL = /\r?\n\r?\n（画面の[^\r\n]*）(\r?\n（画面の[^\r\n]*）)*$/
// 設定を変えたことを執行役に伝える1行。会話の途中ではシステムプロンプトが組み直されない（実機で確かめた）ので、
// 次に会話へ入る発言に添える。古い設定の控えは置き換える
export const SETTINGS_NOTE_HEAD = '（画面の設定が変わりました。'
export function settingsNote(extra: string, depts: readonly Dept[]): string {
  const one = (t: string) => t.replace(/\s+/g, ' ').trim()
  const list = depts.map(d => `${DEPT_PREFIX}${d.name}（${one(d.label ?? d.name)}）`).join('、')
  const ex = one(extra) === '' ? '追加の指示はありません' : `これからは次の指示にも従ってください：${one(extra)}`
  return `${SETTINGS_NOTE_HEAD}${ex}。使える部署は ${list} です）`
}
function rememberStop(title: string) {
  mem.stopNotes.push(stopNote(title))
  if (mem.stopNotes.length > MAX_STOP_NOTES) mem.stopNotes.splice(0, mem.stopNotes.length - MAX_STOP_NOTES)
}

// ---- この画面を出している会話の情報（画面の上部に小さく出す。個人の秘密は入れない：作業フォルダ・開始時刻・版だけ） ----
export type OwnerView = { cwd: string | null; root: string | null; startedAt: string | null; version: string }

// ---- 会話の中身を画面用の形に直してサーバーへ送る ----
function cut(text: string, n: number): string {
  const t = text.replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n - 1)}…` : t
}

function stepText(use: { tool: string; input: Record<string, unknown> }): string {
  const i = use.input
  for (const key of ['file_path', 'notebook_path', 'command', 'description', 'pattern', 'url', 'query', 'prompt']) {
    const v = i[key]
    if (typeof v === 'string' && v !== '') return cut(`${use.tool}: ${v}`, 120)
  }
  return use.tool
}

// 会話の user 行のうち、画面に出すもの。$.prompt.submit で入れた依頼は Claude Code が
// 「The <plugin> plugin sent a message:\n<本文>\n\nThis is how Claude Code surfaces …」で包むので本文だけにする。
// 部署の終わりの通知・スラッシュコマンドなど、人が書いていない行は出さない（null）
const PLUGIN_FRAME = /^The \S+ plugin sent a message:\r?\n([\s\S]*?)\r?\n\r?\nThis is how Claude Code surfaces a prompt[\s\S]*$/
const SYSTEM_ROW = /^<(task-notification|command-name|command-message|local-command-[a-z]+|system-reminder)>/
const lf = (t: string) => t.replace(/\r\n/g, '\n') // 改行を \n にそろえて比べる（Windows の \r\n 対策）
export function userText(text: string): string | null {
  const t = text.trim()
  if (t === '' || SYSTEM_ROW.test(t)) return null
  const framed = PLUGIN_FRAME.exec(t)
  return (framed?.[1] ?? t).replace(STOP_NOTES_TAIL, '').replace(/\r\n/g, '\n') // Windows の改行（\r\n）は \n にそろえる
}

// SessionMessage の並びを、画面の会話（user / assistant / step / files）に直す。
// id は順番から作り、ts は初めて見た時刻で代用する（会話の記録には時刻が無いため）
export function toViewMessages(msgs: SessionMsg[], stamps: string[], nowIso: string): { view: ViewMsg[]; live: string | null } {
  if (stamps.length > msgs.length) stamps.length = msgs.length
  while (stamps.length < msgs.length) stamps.push(nowIso)
  const view: ViewMsg[] = []
  let live: string | null = null
  msgs.forEach((m, i) => {
    const ts = stamps[i] ?? nowIso
    const id = `m${i}`
    if (m.role === 'user') {
      // 道具の結果だけを運ぶ user 行（text が空）は、画面では assistant の道具の行として出すので飛ばす
      const text = userText(m.text)
      if (text !== null) view.push({ id, role: 'user', text, ts })
      return
    }
    if (m.text.trim() !== '') view.push({ id, role: 'assistant', text: m.text, ts })
    const written: string[] = []
    m.toolUses.forEach((u, j) => {
      view.push({ id: `${id}s${j}`, role: 'step', kind: 'tool', text: stepText(u), ts })
      if (u.text === undefined) live = stepText(u)
      const fp = u.input.file_path ?? u.input.notebook_path
      if (WRITE_TOOLS.includes(u.tool) && u.isError !== true && typeof fp === 'string') {
        const lower = fp.toLowerCase()
        if (DOC_EXT.some(e => lower.endsWith(e)) && !written.includes(fp)) written.push(fp)
      }
    })
    if (written.length > 0) view.push({ id: `${id}f`, role: 'files', text: '', ts, outputs: written })
  })
  if (view.length > 0 && msgs[msgs.length - 1]?.role !== 'assistant') live = null
  return { view, live }
}

// ---- 使用量：$.session.usage() を画面の「会話の量」「利用上限」の形に直す ----
// 画面（renderCtx / renderLimit）が読む形。サーバー（server.py の clean_context / clean_usage）が受け取る
export type CtxView = { tokens: number | null; window: number; pct: number | null; at: string; source: 'plugin'; compact: null; compacting: false }
export type LimitWindow = { pct: number; resetsAt: number | null; at: string }
export type LimitView = { status: null; five_hour: LimitWindow | null; seven_day: LimitWindow | null }

export function toCtxView(c: SessionContextUsage | undefined, nowIso: string): CtxView | null {
  if (c === undefined || typeof c.window !== 'number' || !(c.window > 0)) return null
  const tokens = typeof c.tokens === 'number' && c.tokens >= 0 ? c.tokens : null
  const pct = typeof c.percent === 'number' ? c.percent : tokens !== null ? Math.round((tokens * 1000) / c.window) / 10 : null
  return { tokens, window: c.window, pct, at: nowIso, source: 'plugin', compact: null, compacting: false }
}

// rateLimits の kind は five_hour / seven_day（型の説明どおり）。spend_limit など他の kind は画面に出さない。
// リセット時刻（ISO）を過ぎた窓の値は古いので出さない。resetsAt は画面が読む「秒」に直す
export function toLimitView(limits: readonly SessionRateLimit[] | undefined, nowMs: number, nowIso: string): LimitView {
  const out: LimitView = { status: null, five_hour: null, seven_day: null }
  for (const l of limits ?? []) {
    if (l.kind !== 'five_hour' && l.kind !== 'seven_day') continue
    if (typeof l.percentUsed !== 'number') continue
    const resetMs = l.resetsAt !== undefined ? Date.parse(l.resetsAt) : Number.NaN
    if (!Number.isNaN(resetMs) && resetMs <= nowMs) continue
    out[l.kind] = { pct: Math.min(l.percentUsed, 100), resetsAt: Number.isNaN(resetMs) ? null : Math.floor(resetMs / 1000), at: nowIso }
  }
  return out
}

// ---- 入力の予測：利用者が次に送りそうな短い返事を、haiku で1つ作る（自動では送らない。画面の入力欄に薄く出るだけ） ----
export const SUGGEST_MODEL = 'haiku'
export const SUGGEST_MAX_PER_HOUR = 30
export const SUGGEST_TAIL = 3000
export const SUGGEST_SYSTEM = [
  'あなたはアシスタントの入力予測です。利用者が、アシスタント（執行役）の返事を読んだあと、次に入力しそうな短い返事を1つだけ予測して出力します。',
  '- 出力は返事の文だけ。30字以内・1文・1行。説明・引用符・前置きは書かない。',
  '- 返事に質問や選択肢があれば、その答えの形にする（例：「A」「2」「送って」「直して」）。',
  '- 確認を求められていれば「OK」「進めて」など。報告だけで答えることが無ければ「ありがとう」「OK」など短く。',
  '- 利用者の最近の発言の口調（短い・ですます無し など）に合わせる。',
  '- どうしても予測できなければ「なし」とだけ出力する。',
].join('\n')

export function suggestPrompt(reply: string, recent: readonly string[]): string {
  const tail = reply.slice(-SUGGEST_TAIL)
  const lines = recent.map(r => `- ${r.slice(0, 300)}`).join('\n') || '（なし）'
  return `執行役の直前の返事${reply.length > SUGGEST_TAIL ? '（末尾）' : ''}：\n${tail}\n\n利用者の最近の発言（古い順）：\n${lines}\n\n利用者の次の返事：`
}

// ---- 履歴検索の道具（執行役が使う）：サーバーの /api/history/* を呼び、本番の history_mcp.py と同じ読みやすい文にして返す ----
export const TOOL_PREFIX = 'mcp__my-ai-assistant__'
export const HISTORY_SOURCES = ['code', 'task', 'cowork', 'memory', 'doc'] as const
export const HISTORY_TOOLS = [
  {
    name: 'search_history',
    description:
      'この利用者と Claude の過去の会話を全期間から検索する（Claude Code・定期タスク・Cowork・メモリ（ユーザー指示・決めたこと）・CLAUDE.md）。' +
      '空白区切りの語は全部を含むもの。人名・機能名・ファイル名・『指示』『ルール』などで探す。結果は会話ごとに新しい順。中身を詳しく見るときは read_session を使う。',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '検索語（空白区切りで AND）' },
        source: { type: 'string', enum: [...HISTORY_SOURCES], description: '種類で絞る（省略可）' },
        limit: { type: 'integer', description: '会話の件数（既定 10・最大 30）' },
        since: { type: 'string', description: 'この日時以降（例 2026-09-01）' },
      },
      required: ['query'],
    },
  },
  {
    name: 'read_session',
    description: 'search_history で見つけた会話（session_id）の発言を順番に読む。長い会話は offset で続きを読む。',
    inputSchema: {
      type: 'object',
      properties: {
        session_id: { type: 'string' },
        offset: { type: 'integer', description: '何番目の発言から（既定 0）' },
        limit: { type: 'integer', description: '何件（既定 60・最大 200）' },
        roles: { type: 'string', description: 'user,assistant のように絞る（省略で全部。道具の記録 tool/result も含む）' },
      },
      required: ['session_id'],
    },
  },
  {
    name: 'list_memory',
    description: 'Claude のメモリの索引（利用者のユーザー指示・決めたこと・運用ルールの一覧）を返す。依頼に取りかかる前に目を通す。',
    inputSchema: { type: 'object', properties: {} },
  },
] as const

type HistHit = { seq: number; ts: string | null; role: string; snippet: string }
type HistGroup = { sid: string; title: string; sourceJa: string; lastTs: string | null; hits: HistHit[] }
type HistSession = {
  title: string
  sourceJa: string
  n: number
  offset: number
  messages: { seq: number; ts: string | null; role: string; text: string }[]
}

export function formatSearch(groups: HistGroup[]): string {
  if (groups.length === 0) return '見つかりませんでした。語を短くする・言い換える・空白で区切る、を試してください。'
  const lines: string[] = []
  for (const g of groups) {
    lines.push(`■ [${g.sourceJa}] ${g.title}（最終 ${(g.lastTs ?? '').slice(0, 10)}） session_id=${g.sid}`)
    for (const h of g.hits) lines.push(`   ${(h.ts ?? '').slice(0, 16)} ${h.role}: ${h.snippet}`)
  }
  return lines.join('\n')
}

export function formatSession(s: HistSession, roles: string): string {
  const want = new Set(roles.split(',').map(r => r.trim()).filter(r => r !== ''))
  const head = `[${s.sourceJa}] ${s.title}  発言 ${s.n} 件中 ${s.offset}〜${s.offset + s.messages.length - 1}`
  const body = s.messages.filter(m => want.size === 0 || want.has(m.role)).map(m => `--- #${m.seq} ${(m.ts ?? '').slice(0, 16)} ${m.role}\n${m.text}`)
  const next = s.offset + s.messages.length
  return `${head}\n${body.join('\n')}${next < s.n ? `\n（続きあり：offset=${next}）` : ''}`
}

function intArg(v: unknown, dflt: number, lo: number, hi: number): number {
  const n = typeof v === 'number' ? Math.trunc(v) : typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : dflt
  return Math.max(lo, Math.min(n, hi))
}

// 道具の呼び出し → サーバーの /api/history/*（合言葉つき）→ 文。サーバーが止まっているときはその旨の文を返す
export async function runHistoryTool($: EngineInterface, name: string, a: Record<string, unknown>): Promise<string> {
  const get = async (path: string, q: Record<string, string | number>): Promise<{ status: number; body: unknown }> => {
    const qs = Object.entries(q).filter(([, v]) => v !== '').map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`).join('&')
    const r = await $.http.fetch(`${BASE}${path}${qs !== '' ? `?${qs}` : ''}`, { headers: { 'X-Bridge-Token': mem.token } })
    let body: unknown = null
    try {
      body = JSON.parse(r.text)
    } catch {
      body = null
    }
    return { status: r.status, body }
  }
  try {
    if (name === 'search_history') {
      const q = typeof a.query === 'string' ? a.query : ''
      if (q.trim() === '') return 'query が空です。検索語を入れてください。'
      const r = await get('/api/history/search', {
        q,
        limit: intArg(a.limit, 10, 1, 30),
        source: typeof a.source === 'string' ? a.source : '',
        since: typeof a.since === 'string' ? a.since : '',
      })
      if (r.status !== 200) return `エラー: 履歴の検索に失敗しました（HTTP ${r.status}）`
      const st = (await get('/api/history/stats', {})).body as { ready?: boolean; indexing?: { running?: boolean; done?: number; total?: number } } | null
      const found = formatSearch((r.body as { results?: HistGroup[] } | null)?.results ?? [])
      const note =
        st?.indexing?.running === true ? `\n（注意: 履歴の取り込みが途中です（${st.indexing.done ?? 0}/${st.indexing.total ?? '?'}）。新しい会話や古い会話がまだ入っていないことがあります）` : ''
      return found + note
    }
    if (name === 'read_session') {
      const sid = typeof a.session_id === 'string' ? a.session_id : ''
      if (sid === '') return 'session_id が空です。'
      const r = await get('/api/history/session', { sid, offset: intArg(a.offset, 0, 0, 10_000_000), limit: intArg(a.limit, 60, 1, 200) })
      if (r.status === 404) return 'その session_id の会話はありません。'
      if (r.status !== 200 || r.body === null) return `エラー: 会話を読めませんでした（HTTP ${r.status}）`
      return formatSession(r.body as HistSession, typeof a.roles === 'string' ? a.roles : '')
    }
    if (name === 'list_memory') {
      const r = await get('/api/history/memory', {})
      const text = (r.body as { text?: string } | null)?.text ?? ''
      if (r.status !== 200) return `エラー: メモリの索引を読めませんでした（HTTP ${r.status}）`
      return text !== '' ? text : 'メモリの索引が見つかりません。'
    }
  } catch (err) {
    return `エラー: 履歴の窓口（${BASE}）に届きませんでした。画面のサーバーが動いているか確かめてください（${String(err).slice(0, 80)}）`
  }
  return `エラー: 知らない道具です: ${name}`
}

// ---- 仕事（部署の動き）：部署のサブエージェント1つ＝仕事1件 ----
// 部署の登録名（my-ai-assistant:<name>）が org.json の部署ならその id、それ以外は「その他」(other)
export function departmentOf(type: string | undefined): string {
  if (type?.startsWith(DEPT_PREFIX) === true) {
    const name = type.slice(DEPT_PREFIX.length)
    if (mem.depts.some(d => d.name === name)) return name
  }
  return 'other'
}

function deptModel(id: string): string {
  const d = mem.depts.find(x => x.name === id)
  return d?.model ?? 'sonnet'
}

// 画面へ送る仕事の一覧。新しい順に最大 MAX_TASKS 件
function taskViews(): TaskView[] {
  return [...mem.tasks.values()]
    .map(r => r.view)
    .sort((a, b) => b.startedAt.localeCompare(a.startedAt))
    .slice(0, MAX_TASKS)
}

// 60件を超えたら、終わったものの古い方から捨てる（動いているものは残す）
function trimTasks() {
  while (mem.tasks.size > MAX_TASKS) {
    const all = [...mem.tasks.values()].sort((a, b) => a.view.startedAt.localeCompare(b.view.startedAt))
    const victim = all.find(r => r.view.status !== 'working') ?? all[0]
    if (victim === undefined) return
    mem.tasks.delete(victim.view.id)
    mem.stopping.delete(victim.view.id)
  }
}

function newTask(id: string, prompt: string, info: AgentInfo | undefined, nowIso: string): TaskRec {
  const dept = departmentOf(info?.type)
  const title = cut(info?.description ?? '', 60) || cut(prompt, 40) || '仕事'
  const rec: TaskRec = {
    view: {
      id,
      department: dept,
      title,
      prompt: prompt.slice(0, 2000),
      model: deptModel(dept),
      background: true,
      status: 'working',
      startedAt: nowIso,
      finishedAt: null,
      summary: null,
      tools: [],
      live: '取りかかっています',
      outputs: [],
      ...(info?.parentId !== undefined ? { parentId: info.parentId } : {}),
    },
    toolCount: 0,
    lastRead: 0,
    provisional: info === undefined,
    waitingBg: false,
  }
  mem.tasks.set(id, rec)
  trimTasks()
  return rec
}

function resumeTask(rec: TaskRec, nowIso: string) {
  void nowIso
  rec.view.status = 'working'
  rec.view.finishedAt = null
  rec.view.summary = null
  rec.view.live = '取りかかっています'
  rec.waitingBg = false
  mem.stopping.delete(rec.view.id)
}

function endTask(rec: TaskRec, status: TaskView['status'], nowIso: string) {
  rec.view.status = status
  rec.view.finishedAt = nowIso
  rec.view.live = null
  rec.waitingBg = false
}

// 部署の会話を読み、道具のログ（{ts,text}・最大40件）・できた書類・いまの動きを仕事に反映する。
// 読めない（deny）ときは何もしない。返り値は最後の assistant の本文（無ければ ''）
async function refreshTask($: EngineInterface, rec: TaskRec): Promise<string> {
  rec.lastRead = await $.clock.now()
  let found: Awaited<ReturnType<EngineInterface['session']['messages']>>
  try {
    found = await $.session.messages({ agentId: rec.view.id })
  } catch (err) {
    $.ui.log(`my-ai-assistant: 部署の会話を読めませんでした (${String(err)})`, { to: 'debug' })
    return ''
  }
  if (!Array.isArray(found)) return '' // { deny } のとき（読めない）は無視する
  const msgs = found as SessionMsg[]
  const nowIso = new Date(rec.lastRead).toISOString()
  const uses = msgs.flatMap(m => (m.role === 'assistant' ? m.toolUses : [])).filter(u => u.tool !== 'SubagentHandback')
  if (uses.length < rec.toolCount) rec.toolCount = uses.length // 会話が詰められて減ったときは数え直す
  for (const u of uses.slice(rec.toolCount)) rec.view.tools.push({ ts: nowIso, text: stepText(u) })
  rec.toolCount = uses.length
  rec.view.tools = rec.view.tools.slice(-MAX_TOOLS)
  const outs: string[] = []
  for (const u of uses) {
    const fp = u.input.file_path ?? u.input.notebook_path
    if (WRITE_TOOLS.includes(u.tool) && u.isError !== true && typeof fp === 'string') {
      const lower = fp.toLowerCase()
      if (DOC_EXT.some(e => lower.endsWith(e)) && !outs.includes(fp)) outs.push(fp)
    }
  }
  rec.view.outputs = outs.slice(0, 20)
  const lastMsg = msgs[msgs.length - 1]
  const lastText = [...msgs].reverse().find(m => m.role === 'assistant' && m.text.trim() !== '')?.text ?? ''
  if (rec.view.status === 'working') {
    const running = lastMsg?.role === 'assistant' ? lastMsg.toolUses.filter(u => u.text === undefined && u.tool !== 'SubagentHandback').pop() : undefined
    rec.view.live = running !== undefined ? stepText(running) : lastText !== '' ? cut(lastText, 160) : rec.view.live
  }
  return lastText
}

// 仕事の題名・部署・親を agent.list の情報で直す（仮だったもの）
function applyInfo(rec: TaskRec, info: AgentInfo) {
  if (!rec.provisional) return
  rec.provisional = false
  rec.view.department = departmentOf(info.type)
  rec.view.title = cut(info.description, 60) || rec.view.title
  if (info.parentId !== undefined) rec.view.parentId = info.parentId
}

// 部署がまだ動いているとみなす agent.list の状態
const STILL_RUNNING: readonly string[] = ['pending', 'running', 'waiting']

async function listAgents($: EngineInterface): Promise<AgentInfo[]> {
  try {
    const l = await $.agent.list()
    return Array.isArray(l) ? l : []
  } catch (err) {
    $.ui.log(`my-ai-assistant: agent.list を読めませんでした (${String(err)})`, { to: 'debug' })
    return []
  }
}

// 5 秒に 1 回、agent.list を読んで仕事に反映する（turn.start / turn.complete を取り逃したときの保険）。
// 動いている部署は仕事に加え、completed / failed / killed になったものは done / failed / stopped にする
async function syncAgents($: EngineInterface) {
  if (mem.isSyncing) return
  const now = await $.clock.now()
  if (now - mem.lastAgentSync < AGENT_SYNC_MS) return
  mem.lastAgentSync = now
  mem.isSyncing = true
  try {
    const nowIso = new Date(now).toISOString()
    let changed = false
    const agents = await listAgents($)
    for (const a of agents) {
      let rec = mem.tasks.get(a.id)
      if (rec === undefined) {
        if (a.status !== 'pending' && a.status !== 'running' && a.status !== 'waiting') continue
        rec = newTask(a.id, '', a, nowIso)
        await refreshTask($, rec)
        changed = true
        continue
      }
      if (rec.provisional) {
        applyInfo(rec, a)
        changed = true
      }
      if (rec.view.status !== 'working') continue
      const ended = a.status === 'completed' ? 'done' : a.status === 'failed' ? 'failed' : a.status === 'killed' ? 'stopped' : null
      if (ended === null) continue
      const text = await refreshTask($, rec)
      if (rec.view.summary === null && text !== '') rec.view.summary = text.slice(0, 8000)
      endTask(rec, ended, nowIso)
      changed = true
    }
    // 裏の作業を待っていた部署が、completed を見る前に一覧から消えたときは、答えた内容で終える
    for (const rec of mem.tasks.values()) {
      if (rec.view.status !== 'working' || !rec.waitingBg || agents.some(a => a.id === rec.view.id)) continue
      endTask(rec, 'done', nowIso)
      changed = true
    }
    if (changed) void pushState($, true)
  } finally {
    mem.isSyncing = false
  }
}

// 仕事を止める：本物の TaskStop を呼ぶ（権限の確認を通る）。断られた・例外のときは false
async function callTaskStop($: EngineInterface, rec: TaskRec): Promise<boolean> {
  mem.stopping.add(rec.view.id)
  try {
    const r = await $.tool.call({ tool: 'TaskStop', task_id: rec.view.id })
    if (r.deny !== undefined || r.isError === true) {
      mem.stopping.delete(rec.view.id)
      return false
    }
    endTask(rec, 'stopped', new Date(await $.clock.now()).toISOString())
    return true
  } catch (err) {
    $.ui.log(`my-ai-assistant: TaskStop を呼べませんでした (${String(err)})`, { to: 'debug' })
    mem.stopping.delete(rec.view.id)
    return false
  }
}

// 止められなかった仕事を、執行役に止めてもらう依頼として会話に入れる（自動モードの安全確認は迂回しない）
function askExecutiveToStop($: EngineInterface, recs: TaskRec[]): Promise<void> {
  const one = (r: TaskRec) => `仕事「${r.view.title}」（id: ${r.view.id}）`
  const text = recs.length === 1 ? `${one(recs[0] as TaskRec)}を止めてください` : `次の仕事を止めてください:\n${recs.map(r => `- ${one(r)}`).join('\n')}`
  mem.stopSeq += 1
  mem.chatQueue.push({ id: `stopreq-${mem.stopSeq}`, text, mode: 'chat', internal: true })
  return pumpChat($)
}

// 画面の「この仕事を止める」
async function stopOneTask($: EngineInterface, job: Job) {
  const rec = mem.tasks.get(job.taskId ?? '')
  if (rec === undefined || rec.view.status !== 'working') {
    await sendResult($, job.id, false, 'その仕事は動いていません', { count: false })
    return
  }
  const title = rec.view.title
  if (await callTaskStop($, rec)) {
    rememberStop(title)
    await sendResult($, job.id, true, '止めました', { note: `止めるボタンで「${title}」を止めました。`, count: false })
    await pushState($, true)
    return
  }
  await askExecutiveToStop($, [rec])
  await sendResult($, job.id, true, '執行役に頼みました', {
    note: `止めるボタンで「${title}」を止めようとしましたが、権限の確認で通りませんでした。執行役に止めてもらうよう頼みました。`,
    count: false,
  })
}

async function pushState($: EngineInterface, force: boolean) {
  if (mem.phase !== 'running' || mem.token === '') return
  if (mem.isPushing) {
    mem.pushAgain = true
    return
  }
  const now = await $.clock.now()
  if (!force && now - mem.lastPush < STATE_MIN_MS) return
  mem.isPushing = true
  mem.lastPush = now
  try {
    const found = await $.session.messages()
    if (!Array.isArray(found)) return // { deny } のとき（読めない）は送らない
    const nowIso = new Date(now).toISOString()
    const { view, live } = toViewMessages(found, mem.msgTs, nowIso)
    const tasks = taskViews()
    let usage: { context: CtxView | null; limits: LimitView | null } = { context: null, limits: null }
    const owner: OwnerView = { cwd: null, root: null, startedAt: null, version: VERSION }
    try {
      const u = await $.session.usage()
      usage = { context: toCtxView(u.context, nowIso), limits: toLimitView(u.rateLimits, now, nowIso) }
      if (typeof u.startedAt === 'number' && u.startedAt > 0) owner.startedAt = new Date(u.startedAt).toISOString()
    } catch (err) {
      $.ui.log(`my-ai-assistant: 使用量を読めませんでした (${String(err)})`, { to: 'debug' })
    }
    try {
      const c = await $.session.cwd()
      if (typeof c === 'string' && c !== '') owner.cwd = c
    } catch (err) {
      $.ui.log(`my-ai-assistant: 作業フォルダを読めませんでした (${String(err)})`, { to: 'debug' })
    }
    try {
      const r = await $.session.root()
      if (typeof r === 'string' && r !== '') owner.root = r
    } catch (err) {
      $.ui.log(`my-ai-assistant: プロジェクトの場所を読めませんでした (${String(err)})`, { to: 'debug' })
    }
    const make = () =>
      JSON.stringify({
        messages: view,
        busy: mem.mainTurnId !== undefined,
        busySince: mem.mainTurnId !== undefined ? mem.busySince : null,
        live: mem.mainTurnId !== undefined ? live : null,
        model: mem.model,
        tasks,
        context: usage.context,
        usage: usage.limits,
        owner,
      })
    let body = make()
    while (body.length > STATE_MAX_BYTES && view.length > 1) {
      view.splice(0, Math.ceil(view.length / 4)) // 大きすぎるときは古い方から落とす
      body = make()
    }
    await $.http.fetch(`${BASE}/api/bridge/state`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bridge-Token': mem.token },
      body,
    })
  } catch (err) {
    $.ui.log(`my-ai-assistant: 会話の中身を画面へ送れませんでした (${String(err)})`, { to: 'debug' })
  } finally {
    mem.isPushing = false
    if (mem.pushAgain) {
      mem.pushAgain = false
      void pushState($, true)
    }
  }
}

// 画面の「止める」：待ち行列の依頼を取り下げ、動いている本会話の turn を止め、動いている部署も1つずつ止める
async function stopAll($: EngineInterface, job: Job) {
  for (const j of mem.chatQueue.splice(0)) if (j.internal !== true) await sendResult($, j.id, false, '止めました')
  const turnId = mem.mainTurnId
  if (turnId !== undefined) {
    try {
      await $.turn.abort({ turnId })
      rememberStop('執行役の作業')
    } catch (err) {
      $.ui.log(`my-ai-assistant: turn を止められませんでした (${String(err)})`, { to: 'debug' })
    }
  }
  const stopped: string[] = []
  const declined: TaskRec[] = []
  for (const rec of [...mem.tasks.values()].filter(r => r.view.status === 'working')) {
    if (await callTaskStop($, rec)) {
      stopped.push(rec.view.title)
      rememberStop(rec.view.title)
    } else declined.push(rec)
  }
  if (declined.length > 0) await askExecutiveToStop($, declined)
  const note =
    '止めるボタンで、作業をすべて止めました。' +
    (stopped.length > 0 ? `（止めた仕事：${stopped.join('・')}）` : '') +
    (declined.length > 0 ? `（権限の確認で通らず、執行役に頼んだ仕事：${declined.map(r => r.view.title).join('・')}）` : '')
  await sendResult($, job.id, true, '止めました', { note, count: false })
  if (stopped.length > 0) await pushState($, true)
}

// ---- 仕事を始める ----
async function startJob($: EngineInterface, job: Job) {
  if (job.mode === 'stop') return stopAll($, job)
  if (job.mode === 'stoptask') return stopOneTask($, job)
  if (job.mode === 'settings') return runSettingsJob($, job)
  if (job.mode === 'agent') return startAgentJob($, job)
  if (job.mode === 'suggest') {
    void runSuggest($, job) // モデルの返事を待つ間も、ほかの依頼を取りに行けるようにする
    return
  }
  mem.chatQueue.push(job)
  await pumpChat($)
}

// ---- 入力の予測：画面が頼んだとき（回数制限つき）だけ、haiku に1つ作らせて答えを返す。会話には入れない ----
async function runSuggest($: EngineInterface, job: Job) {
  const now = await $.clock.now()
  mem.suggestTimes = mem.suggestTimes.filter(t => now - t < 3_600_000)
  if (mem.suggestTimes.length >= SUGGEST_MAX_PER_HOUR) {
    await sendResult($, job.id, false, '1時間の回数の上限です', { count: false })
    return
  }
  mem.suggestTimes.push(now)
  try {
    const r = await $.model.complete({
      model: SUGGEST_MODEL,
      system: SUGGEST_SYSTEM,
      prompt: suggestPrompt(job.reply ?? '', job.recent ?? []),
      maxTokens: 120,
      effort: 'low',
      timeoutMs: 20_000,
    })
    if (r.isAnswered) await sendResult($, job.id, true, r.text.trim(), { count: false })
    else await sendResult($, job.id, false, `作れませんでした: ${r.reason}`, { count: false })
  } catch (err) {
    await sendResult($, job.id, false, `作れませんでした: ${String(err).slice(0, 80)}`, { count: false })
  }
}

// ---- chat モード：待ち行列の先頭を1件だけ会話に入れる ----
async function pumpChat($: EngineInterface) {
  if (mem.isPumping) return
  mem.isPumping = true
  try {
    while (mem.chatActive === null) {
      const job = mem.chatQueue.shift()
      if (job === undefined) return
      mem.chatActive = { job, startedAt: await $.clock.now() }
      let entered: Awaited<ReturnType<EngineInterface['prompt']['submit']>> | null = null
      // プラグイン自身が入れる発言は、自分の prompt.submit フックを通らない（実機で確かめた）。
      // 止めるボタンの控えは、ここで本文の末尾に直接添える（画面の表示では userText が外す）
      const notes = mem.stopNotes.splice(0)
      try {
        entered = await $.prompt.submit({ text: withStopNotes(job.text, notes) })
      } catch (err) {
        mem.stopNotes.unshift(...notes)
        await finishChat($, `この会話に入れられませんでした: ${String(err)}`, false)
        continue
      }
      if (entered.drop !== undefined) {
        mem.stopNotes.unshift(...notes)
        await finishChat($, `この会話に入れられませんでした: ${entered.drop}`, false)
        continue
      }
      return // turn.complete が来たら次へ
    }
  } finally {
    mem.isPumping = false
  }
}

// active の依頼を終わらせて答えを返し、次の依頼へ進む
async function finishChat($: EngineInterface, text: string, ok: boolean) {
  const active = mem.chatActive
  mem.chatActive = null
  if (active !== null && active.job.internal !== true) await sendResult($, active.job.id, ok, text)
}

async function startAgentJob($: EngineInterface, job: Job) {
  const prompt = PROMPT_HEAD + job.text
  mem.agentPending.set(job.id, prompt)
  let spawned: Awaited<ReturnType<EngineInterface['agent']['spawn']>>
  try {
    spawned = await $.agent.spawn({ prompt, description: '画面からの依頼', subagentType: 'general-purpose' })
  } catch (err) {
    mem.agentPending.delete(job.id)
    await sendResult($, job.id, false, `担当を起こせませんでした (${String(err)})。${AGENT_DENIED_HINT}`)
    return
  }
  if (spawned.deny !== undefined) {
    mem.agentPending.delete(job.id)
    await sendResult($, job.id, false, `担当を起こせませんでした: ${spawned.deny}。${AGENT_DENIED_HINT}`)
    return
  }
  // agentId は engine が付ける。届かないときは turn.start（依頼文の突き合わせ）で拾う
  if (spawned.agentId !== undefined && mem.agentPending.has(job.id)) {
    mem.agentJobs.set(spawned.agentId, job.id)
    mem.agentPending.delete(job.id)
  }
}

// ---- 設定（$.store）と部署（org.json）----
const shownName = () => mem.displayName ?? mem.defaultName
const effectiveDepts = (): Dept[] => mem.custom ?? mem.orgDepts

// $.store の設定を読む。壊れた項目は捨てて、使える項目だけ使う（読めなければ既定のまま）
async function loadSettings($: EngineInterface) {
  if (mem.settingsLoaded) return
  mem.settingsLoaded = true
  try {
    const raw = await $.store.get(SETTINGS_KEY)
    if (typeof raw !== 'object' || raw === null) return
    const r = raw as Record<string, unknown>
    for (const key of ['displayName', 'extraInstructions', 'departments'] as const) {
      if (!(key in r)) continue
      try {
        const v = validateSettings({ [key]: r[key] })
        if (v.displayName !== undefined) mem.displayName = v.displayName
        if (v.extraInstructions !== undefined) mem.extra = v.extraInstructions
        if (v.departments !== undefined) mem.custom = v.departments
      } catch (err) {
        $.ui.log(`my-ai-assistant: 保存済みの設定「${key}」は使えないので既定に戻します (${String(err)})`, { to: 'debug' })
      }
    }
  } catch (err) {
    $.ui.log(`my-ai-assistant: 設定を読めませんでした (${String(err)})`, { to: 'debug' })
  }
  await update($, nameAtom, () => shownName())
}

// config/org.json を読む（部署の既定・表示名の既定）。形が違う部署は飛ばす
async function loadOrg($: EngineInterface) {
  const raw = await $.fs.read(`${$.plugin.root}/config/org.json`)
  const org = JSON.parse(typeof raw === 'string' ? raw : '') as Org
  const title = org.executive?.title
  mem.defaultName = typeof title === 'string' && title.trim() !== '' && Array.from(title.trim()).length <= LIMITS.displayName ? title.trim() : DEFAULT_NAME
  const list: Dept[] = []
  ;(org.departments ?? []).forEach((x, i) => {
    try {
      list.push(cleanDept(x, i, org.defaults))
    } catch (err) {
      $.ui.log(`my-ai-assistant: org.json の部署${i + 1}は使えないので飛ばします (${String(err)})`, { to: 'debug' })
    }
  })
  mem.orgDepts = list
}

async function registerAll($: EngineInterface, list: readonly Dept[]) {
  for (const d of list) {
    await $.agent.register({
      name: d.name,
      description: d.description,
      prompt: d.prompt,
      model: d.model ?? 'sonnet',
      effort: d.effort ?? 'medium',
      ...(d.tools !== undefined ? { tools: d.tools } : {}),
    })
  }
}

const orgLine = (list: readonly Dept[]) => `部署: ${list.map(d => d.label ?? d.name).join('・')}（${list.length} 部署）`

async function registerDepartments($: EngineInterface) {
  if (mem.orgDone) return
  mem.orgTries += 1
  try {
    await loadSettings($)
    try {
      await loadOrg($)
    } catch (err) {
      if (mem.custom === null) throw err // 自分で決めた部署があれば、org.json が読めなくても続ける
      $.ui.log(`my-ai-assistant: org.json を読めませんでした (${String(err)})`, { to: 'debug' })
    }
    const list = effectiveDepts()
    await registerAll($, list)
    mem.depts = list
    mem.orgDone = true
    await update($, nameAtom, () => shownName())
    await update($, orgAtom, () => orgLine(list))
  } catch (err) {
    $.ui.log(`my-ai-assistant: 部署を登録できませんでした (${String(err)})`, { to: 'debug' })
    await update($, orgAtom, () => `部署: 登録できませんでした (${String(err).slice(0, 60)})`)
  }
}

// 今の設定をサーバーへ知らせる（画面の GET /api/settings と、表示名・部署の表示のもと）。届くまで poll が繰り返す
async function pushSettings($: EngineInterface) {
  if (mem.phase !== 'running' || mem.token === '' || !mem.orgDone) return
  try {
    const r = await $.http.fetch(`${BASE}/api/bridge/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bridge-Token': mem.token },
      body: JSON.stringify({ displayName: mem.displayName, extraInstructions: mem.extra, departments: mem.depts, customDepartments: mem.custom !== null }),
    })
    mem.settingsPushed = r.ok
    if (!r.ok) $.ui.log(`my-ai-assistant: 設定をサーバーへ知らせられませんでした (HTTP ${r.status}: ${r.text.slice(0, 120)})`, { to: 'debug' })
  } catch (err) {
    $.ui.log(`my-ai-assistant: 設定をサーバーへ知らせられませんでした (${String(err)})`, { to: 'debug' })
  }
}

// 画面の「保存する」: 検証 → 部署の登録し直し → $.store に保存 → 表示名の反映 → サーバーへ知らせる
export const SETTINGS_SAVED = '保存しました。次の発言から使われます'
async function applySettings($: EngineInterface, raw: unknown): Promise<{ ok: boolean; text: string }> {
  let patch: SettingsPatch
  try {
    patch = validateSettings(raw)
  } catch (err) {
    return { ok: false, text: err instanceof Error ? err.message : String(err) }
  }
  if (Object.keys(patch).length === 0) return { ok: false, text: '変える項目がありません' }
  if (!mem.orgDone) {
    mem.orgTries = 0 // 起動時の登録がまだ終わっていなければ、ここでやり直す
    await registerDepartments($)
    if (!mem.orgDone) return { ok: false, text: '部署の登録がまだ終わっていません。少し待ってから、もう一度保存してください' }
  }
  const next = {
    // 既定と同じ表示名は未設定として扱う（保存しない。既定に戻すと設定のキーが消える）
    displayName: patch.displayName !== undefined ? (patch.displayName === mem.defaultName ? null : patch.displayName) : mem.displayName,
    extra: patch.extraInstructions !== undefined ? patch.extraInstructions : mem.extra,
    custom: patch.departments !== undefined ? patch.departments : mem.custom,
  }
  // 部署の一覧が既定（config/org.json）と同じなら、「自分で決めた部署」ではなく未設定（既定を使う状態）に戻す
  if (next.custom !== null && JSON.stringify(next.custom) === JSON.stringify(mem.orgDepts)) next.custom = null
  const nextDepts = next.custom ?? mem.orgDepts
  const before = mem.depts
  if (JSON.stringify(nextDepts) !== JSON.stringify(before)) {
    try {
      await registerAll($, nextDepts)
    } catch (err) {
      await registerAll($, before).catch(() => undefined) // 途中まで置き換わった分を、元に戻す（できなければそのまま）
      return { ok: false, text: `部署を登録できませんでした: ${String(err).slice(0, 160)}` }
    }
  }
  try {
    if (next.displayName === null && next.extra === '' && next.custom === null) {
      await $.store.delete(SETTINGS_KEY) // 全部が既定なら、設定のキーごと消す（未設定に戻る）
    } else {
      await $.store.set(SETTINGS_KEY, {
        v: 1,
        ...(next.displayName !== null ? { displayName: next.displayName } : {}),
        ...(next.extra !== '' ? { extraInstructions: next.extra } : {}),
        ...(next.custom !== null ? { departments: next.custom } : {}),
      })
    }
  } catch (err) {
    await registerAll($, before).catch(() => undefined)
    return { ok: false, text: `設定を保存できませんでした: ${String(err).slice(0, 160)}` }
  }
  mem.displayName = next.displayName
  mem.extra = next.extra
  mem.custom = next.custom
  mem.depts = nextDepts
  await update($, nameAtom, () => shownName())
  await update($, orgAtom, () => orgLine(nextDepts))
  if (mem.paneOpen) await $.ui.open({ id: PANE, title: shownName() }).catch(() => undefined) // 開いているペインの見出しを替える
  // システムプロンプトの節と道具の説明（Agent の部署一覧）はエンジンがキャッシュする。捨てないと、
  // 変えた指示・部署が会話に届かない（実機で確かめた）。捨てると次の turn で組み直される
  $.ui.invalidate('prompt.section')
  $.ui.invalidate('tool.describe')
  // それでも会話の途中では指示が届かない（実機で確かめた）ので、次の発言にも添える
  mem.stopNotes = mem.stopNotes.filter(n => !n.startsWith(SETTINGS_NOTE_HEAD))
  mem.stopNotes.push(settingsNote(next.extra, nextDepts))
  mem.settingsPushed = false
  await pushSettings($)
  return { ok: true, text: SETTINGS_SAVED }
}

async function runSettingsJob($: EngineInterface, job: Job) {
  const r = await applySettings($, job.settings)
  await sendResult($, job.id, r.ok, r.text, { count: false })
  if (job.origin === 'web' && r.ok) {
    // Web から設定が変わった。気づけるように、ペインと toast に出す（部署の tools はサーバーが変えさせない）
    const at = fmtTime(await $.clock.now())
    mem.web.note = `Web から設定が変わりました（${at}）`
    $.ui.toast('Web から設定が変わりました')
    await setWebLine($)
  }
}

// Web から来て、まだ会話に入っていない依頼を捨てる（web-off・web-revoke のとき）。fp があればそのブラウザの分だけ。
// 手元サーバーの待ち行列と、取ってきて順番待ちの分（chatQueue）が対象。すでに会話に入って動いている依頼は止めない
// （会話は手元の作業と同じ一本なので、止めると手元の作業も巻き込む）。動いている数を返すので、呼んだ側が利用者に知らせる
async function dropWebJobs($: EngineInterface, fp?: string): Promise<{ dropped: number; running: number }> {
  let dropped = 0
  let running = 0
  try {
    const r = await $.http.fetch(`${BASE}/api/bridge/drop-web`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Bridge-Token': mem.token },
      body: JSON.stringify(fp !== undefined ? { fp } : {}),
    })
    if (r.ok) {
      const j = JSON.parse(r.text) as { dropped?: unknown; running?: unknown }
      if (typeof j.dropped === 'number') dropped += j.dropped
      if (typeof j.running === 'number') running += j.running
    }
  } catch (err) {
    $.ui.log(`my-ai-assistant: Web の依頼を捨てる連絡ができませんでした (${String(err)})`, { to: 'debug' })
  }
  const keep: Job[] = []
  for (const j of mem.chatQueue.splice(0)) {
    if (j.origin === 'web' && (fp === undefined || j.webFp === fp)) {
      dropped += 1
      await sendResult($, j.id, false, 'Web の取り消し・停止で捨てました', { count: false })
    } else keep.push(j)
  }
  mem.chatQueue.push(...keep)
  return { dropped, running }
}

function dropNote(d: { dropped: number; running: number }): string {
  const parts: string[] = []
  if (d.dropped > 0) parts.push(`Web から来て会話に入る前の依頼 ${d.dropped} 件を捨てました。`)
  if (d.running > 0) parts.push(`すでに会話に入って動いている Web の依頼が ${d.running} 件あります（自動では止めません: 会話は手元の作業と同じ一本なので、止めると手元の作業も巻き込むため。止めるなら画面の「止める」か、Claude の会話で止めてください）。`)
  return parts.join('')
}

// ---- 履歴検索の道具を $.tool.register で出す（呼ばれたときの答えは tool.call のフックが作る） ----
async function registerTools($: EngineInterface) {
  for (const t of HISTORY_TOOLS) {
    try {
      await $.tool.register({ name: t.name, description: t.description, inputSchema: t.inputSchema as unknown as Record<string, unknown> })
    } catch (err) {
      $.ui.log(`my-ai-assistant: 道具 ${t.name} を登録できませんでした (${String(err)})`, { to: 'debug' })
    }
  }
}

// ---- 1 秒ごとに仕事を取りに行く ----
async function poll($: EngineInterface) {
  void syncWeb($) // Web 版の橋渡し（使う設定で、この会話が画面を持っているときだけ起こす）
  if (mem.phase === 'port-busy') {
    await tryTakeover($)
    return
  }
  if (mem.outdated !== null) return // 新しい版に譲った（この会話はもう画面を持たない）
  if (mem.phase === 'running' && (await yieldIfOutdated($))) return
  if (!mem.orgDone && mem.orgTries < 5) void registerDepartments($)
  const active = mem.chatActive
  if (active !== null && active.turnId === undefined) {
    // 会話に入れたのに turn が始まらない（会話が長い処理中など）。長く待っても始まらなければ諦めて次へ
    if ((await $.clock.now()) - active.startedAt > CHAT_START_TIMEOUT_MS) {
      await finishChat($, 'この会話で処理が始まりませんでした（時間切れ）。もう一度頼んでください', false)
      void pumpChat($)
    }
  }
  if (mem.isPolling || mem.phase !== 'running') return
  if (!mem.sentInitial) {
    mem.sentInitial = true
    void pushState($, true) // 起動直後に、いまの会話（Code タブで打ったものを含む）を1度送る
  }
  if (!mem.settingsPushed && mem.orgDone) void pushSettings($) // 起動直後（サーバーを起こし直したときも）に、今の設定を知らせる
  void syncAgents($) // 5 秒に 1 回、agent.list で仕事の状態を見直す
  mem.isPolling = true
  try {
    const r = await $.http.fetch(`${BASE}/api/bridge/next`, { headers: { 'X-Bridge-Token': mem.token } })
    if (r.status === 200) {
      await startJob($, JSON.parse(r.text) as Job)
    }
  } catch (err) {
    $.ui.log(`my-ai-assistant: 取りに行けませんでした (${String(err)})`, { to: 'debug' })
  } finally {
    mem.isPolling = false
  }
}

// ---- 新しい版が入っているか ----
// プラグインは版ごとのフォルダ（…/my-ai-assistant/<版>/）に入る。更新すると新しい版のフォルダができ、
// 開いている会話は turn の区切りで読み込み直すまで古い版のまま動く。古い版の会話が 8790 を取ると、
// 新しい版の会話が画面を出せなくなる（実機で起きた）。そこで、自分より新しい版のフォルダがあれば
// 8790 を取らない・持っていれば手放す。--plugin-dir で動かしているとき（版のフォルダでない）は何もしない
export function newerVersion(own: string, names: readonly string[]): string | null {
  const parse = (v: string) => (/^\d+\.\d+\.\d+$/.test(v) ? v.split('.').map(Number) : null)
  const mine = parse(own)
  if (mine === null) return null
  let best: number[] | null = null
  let bestName: string | null = null
  for (const n of names) {
    const v = parse(n)
    if (v === null) continue
    const cmp = (a: number[], b: number[]) => a[0]! - b[0]! || a[1]! - b[1]! || a[2]! - b[2]!
    if (cmp(v, mine) > 0 && (best === null || cmp(v, best) > 0)) {
      best = v
      bestName = n
    }
  }
  return bestName
}

async function installedNewer($: EngineInterface): Promise<string | null> {
  const root = $.plugin.root.replace(/[\\/]+$/, '')
  const cut = Math.max(root.lastIndexOf('/'), root.lastIndexOf('\\'))
  if (cut < 0 || root.slice(cut + 1) !== VERSION) return null // 版のフォルダから動いていない
  try {
    const entries = await $.fs.list(root.slice(0, cut))
    return newerVersion(VERSION, entries.filter(e => e.kind === 'dir').map(e => e.name))
  } catch {
    return null
  }
}

// 持ち主のとき、10 秒に 1 回、新しい版が入っていないかを見る。入っていればサーバーを止めて手放す
async function yieldIfOutdated($: EngineInterface): Promise<boolean> {
  const now = await $.clock.now()
  if (now - mem.lastVersionCheck < VERSION_CHECK_MS) return false
  mem.lastVersionCheck = now
  const newer = await installedNewer($)
  if (newer === null) return false
  mem.outdated = newer
  await setStatus($, { phase: 'stopped', message: `新しい版 ${newer} が入りました。この会話を開き直すと新しい版で動きます（画面は新しい版の会話に譲りました）` })
  await $.http.fetch(`${BASE}/api/bridge/shutdown`, { method: 'POST', headers: { 'X-Bridge-Token': mem.token } }).catch(() => null)
  return true
}

// ---- 8790 の持ち主（別のセッション）が閉じたら、このセッションがサーバーを引き継ぐ ----
async function tryTakeover($: EngineInterface) {
  if (mem.isStarting) return
  const now = await $.clock.now()
  if (now - mem.lastTakeoverCheck < TAKEOVER_MS) return
  mem.lastTakeoverCheck = now
  const alive = await $.http.fetch(`${BASE}/api/health`).catch(() => null)
  if (alive) return // まだ持ち主がいる
  const newer = await installedNewer($)
  if (newer !== null) {
    // 自分は古い版。新しい版の会話が起動するのを待つ（取らない）
    await setStatus($, { phase: 'port-busy', message: `新しい版 ${newer} が入っています。この会話を開き直すと新しい版で動きます` })
    return
  }
  $.ui.log(`my-ai-assistant: ${PORT} が空いたので、このセッションでサーバーを起動します`, { to: 'debug' })
  void startServer($)
}

// ---- Python を探す（無ければ null） ----
async function findPython($: EngineInterface): Promise<string[] | null> {
  const os = await $.env.get('OS')
  if (os === 'Windows_NT') {
    mem.platform = 'windows'
  } else {
    const uname = await $.process.run(['uname']).catch(() => null)
    mem.platform = uname?.stdout.trim() === 'Darwin' ? 'mac' : 'linux'
  }
  let candidates: string[][]
  if (mem.platform === 'windows') {
    candidates = [['py', '-3'], ['python']]
  } else if (mem.platform === 'mac') {
    // macOS の /usr/bin/python3 は「開発ツールを入れますか？」の窓を出すだけの代役のことがある。
    // また PATH の先頭の python3 が動かない（Apple シリコンに Intel 版だけ残っている等）こともあるので、
    // 動くものが見つかるまで順に試す。
    const clt = await $.process.run(['/usr/bin/xcode-select', '-p']).catch(() => null)
    const hasClt = clt !== null && clt.exitCode === 0
    const where = await $.process.run(['/bin/sh', '-c', 'command -v python3']).catch(() => null)
    const onPath = where?.stdout.trim() ?? ''
    candidates = [
      ...(onPath !== '' && (onPath !== '/usr/bin/python3' || hasClt) ? [['python3']] : []),
      ['/opt/homebrew/bin/python3'],
      ['/opt/homebrew/bin/python3.13'],
      ['/opt/homebrew/bin/python3.12'],
      ['/Library/Frameworks/Python.framework/Versions/Current/bin/python3'],
      ...(hasClt ? [['/usr/bin/python3']] : []),
    ]
  } else {
    candidates = [['python3']]
  }
  for (const argv of candidates) {
    const ok = await $.process
      .run([...argv, '-c', 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)'], { timeoutMs: 10000 })
      .catch(() => null)
    if (ok && ok.exitCode === 0) return argv
  }
  return null
}

// ---- サーバーを起動する（子プロセスはこのセッション＝このモジュールが終わると一緒に終わる） ----
async function startServer($: EngineInterface) {
  if (mem.isStarting) return
  mem.isStarting = true
  try {
    await runServer($)
  } finally {
    mem.isStarting = false
  }
}

// 8790 で誰かが応えていれば port-busy にして引き継ぎ待ちにする（応えなければ false）
async function markIfBusy($: EngineInterface): Promise<boolean> {
  const already = await $.http.fetch(`${BASE}/api/health`).catch(() => null)
  if (!already) return false
  const isOurs = already.ok && already.text.includes(APP)
  await setStatus($, {
    phase: 'port-busy',
    message: isOurs
      ? `別のセッションがすでに ${PORT} で画面を出しています（そちらが閉じたら、このセッションが引き継ぎます）`
      : `ポート ${PORT} を別のプログラムが使っています（空いたら起動します）`,
  })
  mem.lastTakeoverCheck = await $.clock.now()
  return true
}

async function runServer($: EngineInterface) {
  await setStatus($, { phase: 'starting', message: '起動中' })
  if (await markIfBusy($)) return
  const python = await findPython($)
  if (python === null) {
    await setStatus($, {
      phase: 'no-python',
      message:
        mem.platform === 'windows'
          ? 'Python 3 が見つかりません（python.org から入れてください）'
          : 'Python 3 が見つかりません（ターミナルで xcode-select --install を実行してください）',
    })
    return
  }
  mem.token = crypto.randomUUID()
  mem.webKey = crypto.randomUUID() + crypto.randomUUID()
  mem.sentInitial = false
  mem.settingsPushed = false
  const child = $.process.spawn({
    argv: [...python, `${$.plugin.root}/server/server.py`, '--port', String(PORT), '--version', VERSION],
    // PYTHONUTF8 / PYTHONIOENCODING: Windows の既定の文字コード（cp932 など）で日本語のログが落ちないように
    env: { MYAI_BRIDGE_TOKEN: mem.token, MYAI_WEB_ORIGIN_KEY: mem.webKey, PYTHONUNBUFFERED: '1', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
  })
  let tail = ''
  try {
    for await (const piece of child) {
      if (piece.stream === 'stdout' && piece.text.includes('LISTENING')) {
        await setStatus($, { phase: 'running', message: `動作中 ${BASE}/` })
      }
      if (piece.stream === 'stderr') {
        tail = (tail + piece.text).slice(-400)
        $.ui.log(`my-ai-assistant: ${piece.text.trimEnd()}`, { to: 'debug' })
      }
    }
    if (mem.outdated !== null) return // 新しい版に譲るために止めた
    // 引き継ぎで2つのセッションが同時に起動し、ポートを先に取られたときは、また引き継ぎ待ちに戻る
    if (mem.phase !== 'running' && (await markIfBusy($))) return
    const lastLine = tail.trim().split('\n').pop() ?? ''
    await setStatus($, { phase: 'stopped', message: `サーバーが止まりました ${lastLine}`.trim() })
  } catch (err) {
    await setStatus($, { phase: 'failed', message: `サーバーを起動できませんでした (${String(err)})` })
  }
}

// ---- 画面を開く（既定のブラウザで） ----
async function openScreen($: EngineInterface) {
  const url = `${BASE}/`
  const argv =
    mem.platform === 'windows'
      ? ['cmd', '/c', 'start', '""', url]
      : mem.platform === 'mac'
        ? ['open', url]
        : ['xdg-open', url]
  const r = await $.process.run(argv).catch(() => null)
  if (!r || r.exitCode !== 0) $.ui.toast(`開けませんでした。${url} をブラウザで開いてください`)
}

// ---- turn.* から仕事を作る・進める・終える ----
// 部署（agentId あり）の turn.start：仕事を1件作る（agent.list に載っているものだけ。エンジン自身の内部の分身は載らない）
async function trackStart($: EngineInterface, agentId: string, prompt: string) {
  const nowIso = new Date(await $.clock.now()).toISOString()
  const existing = mem.tasks.get(agentId)
  if (existing !== undefined) {
    if (existing.view.status !== 'working') resumeTask(existing, nowIso) // 止まった・終えた部署をもう一度動かした
    void pushState($, true)
    return
  }
  const info = (await listAgents($)).find(a => a.id === agentId)
  if (info === undefined) return // 載るのを待つ（5 秒ごとの見直しで拾う）
  newTask(agentId, prompt, info, nowIso)
  void pushState($, true)
}

// 部署の turn.step：道具の動きを更新（部署ごとに 2 秒に 1 回まで）
async function trackStep($: EngineInterface, agentId: string, model: string) {
  const rec = mem.tasks.get(agentId)
  if (rec === undefined) return
  if (model !== '') rec.view.model = model
  if ((await $.clock.now()) - rec.lastRead < STATE_MIN_MS) return
  await refreshTask($, rec)
  void pushState($, false)
}

// 部署の turn.complete：answer は done、止めたもの（aborted・止めると決めた仕事）は stopped、それ以外は failed
async function trackComplete($: EngineInterface, agentId: string, reason: string, answer: string) {
  const nowIso = new Date(await $.clock.now()).toISOString()
  let rec = mem.tasks.get(agentId)
  if (rec === undefined) {
    const info = (await listAgents($)).find(a => a.id === agentId)
    if (info === undefined) return
    rec = newTask(agentId, '', info, nowIso)
  }
  await refreshTask($, rec)
  // 答えて turn を終えても、部署が裏の作業（バックグラウンドの Bash など）の終わりを待っていることがある。
  // agent.list でまだ動いていれば作業中のままにし、completed になったら 5 秒ごとの見直しで終える
  if (reason === 'answer' && !mem.stopping.has(agentId)) {
    const info = (await listAgents($)).find(a => a.id === agentId)
    if (info !== undefined && STILL_RUNNING.includes(info.status)) {
      rec.waitingBg = true
      rec.view.live = '裏で動かした作業の終わりを待っています'
      if (answer !== '') rec.view.summary = answer.slice(0, 8000)
      await pushState($, true)
      return
    }
  }
  const status: TaskView['status'] = reason === 'answer' ? 'done' : reason === 'aborted' || mem.stopping.has(agentId) ? 'stopped' : 'failed'
  rec.view.summary = answer !== '' ? answer.slice(0, 8000) : rec.view.summary
  endTask(rec, status, nowIso)
  await pushState($, true)
}

// ======================================================================
// Web 版（W3）。設計は docs/web-plan.md 2章・6章・7章。
// ======================================================================

// 表示する名前の整理: 制御文字・書式文字（向き制御など）・見えない文字・カギかっこ類を除き、max 文字まで
const LABEL_STRIP = new RegExp('[\\p{Cc}\\p{Cf}\\u034F\\u115F\\u1160\\u17B4\\u17B5\\u180B-\\u180D\\u2800\\u3164\\uFE00-\\uFE0F\\uFFA0\\u2028\\u2029「」『』（）()\\[\\]{}<>〈〉《》【】〔〕"\'`“”‘’＂＇]', 'gu')
export function safeLabel(s: unknown, max: number): string {
  const t = typeof s === 'string' ? s.normalize('NFKC').replace(LABEL_STRIP, '').replace(/\s+/g, ' ').trim().slice(0, max) : ''
  return t === '' ? 'ブラウザ' : t
}
// 12桁の番号を 4桁ずつに区切って見やすくする
export const fmtPairCode = (c: string) => c.replace(/(\d{4})(?=\d)/g, '$1-')

// 橋渡しの状態 → ペインの1行
export function webLine(enabled: boolean, owner: boolean, blocked: string | null, running: boolean, st: { state?: string; browsers?: string[] } | null, stopping = false): string {
  if (stopping && running) return 'Web: 橋渡しを止めています…'
  if (!enabled) return 'Web: 使わない'
  if (blocked !== null) return `Web: 使えません（${blocked}）`
  if (!owner) return 'Web: 使う設定ですが、この会話は画面を持っていないので動かしません'
  if (!running || st === null) return 'Web: 起動中'
  const who = (st.browsers ?? []).join('、')
  if (st.state === 'busy') return `Web: 操作中（${who}）`
  if (st.state === 'connected') return `Web: つながっている（${who}）`
  return 'Web: 待機中'
}

async function setWebLine($: EngineInterface) {
  const w = mem.web
  const line = webLine(w.enabled, mem.phase === 'running' && mem.outdated === null, w.blocked, w.running && (w.port !== null || w.stopping), w.lastState, w.stopping)
  const now = await $.clock.now()
  const pairing = w.pair !== null && w.pair.expiresAt > now ? w.pair : null
  w.pair = pairing
  const sas = w.sas !== null && w.sas.expiresAt > now ? { code: w.sas.code, name: w.sas.name } : null
  const sasKey = sas === null ? null : `${sas.code}/${sas.name}`
  const shown = `${w.history ? 1 : 0}/${w.note ?? ''}`
  if (line === w.line && pairing?.code === w.shownPair && sasKey === w.shownSas && shown === w.shownExtra) return
  w.line = line
  w.shownPair = pairing?.code ?? null
  w.shownSas = sasKey
  w.shownExtra = shown
  await update($, webAtom, () => ({ line, pair: pairing, sas, history: w.history, note: w.note }))
  $.ui.invalidate('ui.render') // 状態の書き込みだけに頼らず、ペインを確実に描き直させる
}

async function loadWeb($: EngineInterface) {
  if (mem.web.loaded) return
  mem.web.loaded = true
  try {
    const raw = await $.store.get(WEB_STORE_KEY)
    mem.web.enabled = typeof raw === 'object' && raw !== null && (raw as { enabled?: unknown }).enabled === true
    mem.web.history = typeof raw === 'object' && raw !== null && (raw as { history?: unknown }).history === true // true と書かれているときだけ読める（壊れた値は読めない）
  } catch (err) {
    $.ui.log(`my-ai-assistant: Web 版の設定を読めませんでした (${String(err)})`, { to: 'debug' })
  }
  await setWebLine($)
}

async function saveWebEnabled($: EngineInterface, enabled: boolean) {
  mem.web.enabled = enabled
  await $.store.set(WEB_STORE_KEY, { enabled, history: mem.web.history })
}

async function saveWebHistory($: EngineInterface, on: boolean) {
  mem.web.history = on
  await $.store.set(WEB_STORE_KEY, { enabled: mem.web.enabled, history: on })
}

// node を探す（標準の WebSocket と CompressionStream があるものだけ。無ければ null）
async function findNode($: EngineInterface): Promise<string[] | null> {
  let candidates: string[][]
  if (mem.platform === 'windows') {
    candidates = [['node']]
  } else {
    const found: string[][] = []
    if (mem.platform === 'mac') {
      // Claude アプリから起動した会話は PATH が短い。ログインシェルでも探す（nvm・volta など）
      const sh = await $.process.run(['/bin/zsh', '-lc', 'command -v node'], { timeoutMs: 10000 }).catch(() => null)
      const p = sh?.stdout.trim().split('\n').pop() ?? ''
      if (sh?.exitCode === 0 && p.startsWith('/')) found.push([p])
    }
    candidates = [['node'], ...found, ['/opt/homebrew/bin/node'], ['/usr/local/bin/node']]
  }
  for (const argv of candidates) {
    const ok = await $.process
      .run([...argv, '-e', "process.exit(typeof WebSocket==='function'&&typeof CompressionStream==='function'&&globalThis.crypto&&crypto.subtle?0:1)"], { timeoutMs: 10000 })
      .catch(() => null)
    if (ok && ok.exitCode === 0) return argv
  }
  return null
}

// 橋渡しの制御窓口を呼ぶ（届かなければ null）
async function webCtl($: EngineInterface, body: Record<string, unknown>): Promise<Record<string, unknown> | null> {
  const w = mem.web
  if (!w.running || w.port === null) return null
  try {
    const r = await $.http.fetch(`http://127.0.0.1:${w.port}/ctl`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Ctl-Token': w.token },
      body: JSON.stringify(body),
    })
    if (!r.ok) return null
    return JSON.parse(r.text) as Record<string, unknown>
  } catch {
    return null
  }
}

// 6桁の見比べ。質問（$.ui.ask）かコマンド（web-ok / web-ng）の、先に答えた方を使う。
// 「一致」のときだけ登録する（聞けない・閉じられた・Other に書いた、はすべて「登録しない」）。
// 会話が turn の途中だと質問が出ない／後回しになることがあるので、ペインとコマンドでも答えられるようにしている
async function askSas($: EngineInterface, ev: { id: string; sas: string; name: string }) {
  const w = mem.web
  let silent = false
  let settle: (yes: boolean, quiet: boolean) => void = () => {}
  const decided = new Promise<boolean>(resolve => {
    settle = (yes, quiet) => {
      silent = silent || quiet
      resolve(yes)
    }
  })
  w.sas = { id: ev.id, code: ev.sas, name: ev.name, expiresAt: (await $.clock.now()) + WEB_SAS_WAIT_MS, settle }
  await setWebLine($)
  // 目立つ通知: 画面の toast（長めに残す）と、使える環境なら端末の通知。出ない環境でも、ペインの先頭とコマンドで答えられる
  $.ui.toast(`Web 版: 確認用の6桁は ${ev.sas} です。Claude Code のペインでブラウザの6桁と見比べてください`, { timeoutMs: 30000 })
  void Promise.resolve($.ui.notify(`Web 版の登録: 確認用の6桁 ${ev.sas}。Claude Code のペインで見比べてください`, { title: 'My AI Assistant' })).catch(() => undefined)
  // ブラウザの名前は相手が決めた文字なので、6桁の文には混ぜない。別の行に、整えた名前だけを「相手が決めた名前」と断って出す
  $.ui
    .ask(`ブラウザに出ている6桁は ${ev.sas} ですか？\n（出ないときは /my-ai-assistant web-ok か web-ng）\n登録する端末の名前（相手が決めた文字です。判断は6桁だけで）: ${safeLabel(ev.name, 40)}`, { options: [SAS_YES, SAS_NO], header: 'Web 版の登録' })
    .then(ans => settle(ans === SAS_YES, false))
    .catch(() => settle(false, false)) // 閉じられた・聞けない
  const yes = await decided
  if (w.sas?.id === ev.id) w.sas = null
  if (!silent) await webCtl($, { cmd: 'sas', id: ev.id, ok: yes }) // 橋渡しが先に終えた（時間切れなど）ときは送らない
  await setWebLine($)
}

// 橋渡しの側で見比べが終わった（時間切れ・登録・拒否・失効）。確認中の質問は閉じる
function closeSas() {
  mem.web.sas?.settle(false, true)
}

async function onBridgeEvent($: EngineInterface, ev: Record<string, unknown>) {
  const w = mem.web
  if (ev.t === 'ready' && typeof ev.port === 'number') {
    w.port = ev.port
    w.pid = typeof ev.pid === 'number' && Number.isInteger(ev.pid) && ev.pid > 1 ? ev.pid : null
    w.running = true
    w.lastStatus = Number.NEGATIVE_INFINITY // すぐ状態を取りに行く
  } else if (ev.t === 'sas' && typeof ev.id === 'string' && typeof ev.sas === 'string') {
    const item = { id: ev.id, sas: ev.sas, name: safeLabel(ev.name, 40) }
    w.asking = w.asking.then(() => askSas($, item)) // 質問は1つずつ
  } else if (ev.t === 'pair_done') {
    w.pair = null
    closeSas()
    $.ui.toast(`Web 版: 「${String(ev.name ?? 'ブラウザ')}」を登録しました`)
  } else if (ev.t === 'pair_rejected') {
    w.pair = null
    closeSas()
    $.ui.toast('Web 版: 6桁が違うので登録しませんでした。番号は捨てました（心当たりがなければ、番号を人に見せていないか確かめてください）')
  } else if (ev.t === 'pair_expired') {
    w.pair = null
    closeSas()
  } else if (ev.t === 'sas_timeout') {
    closeSas()
    $.ui.toast('Web 版: 見比べの返事がなかったので、登録しませんでした')
  } else if (ev.t === 'fatal') {
    const reason = String(ev.reason ?? '')
    w.blocked =
      reason === 'node_too_old'
        ? WEB_NO_NODE
        : reason === 'no_config' || reason === 'bad_config'
          ? 'config/web.json（中継の接続設定）が読めません'
          : `橋渡しを起動できません（${reason}）`
  }
  await setWebLine($)
}

// 橋渡しを子プロセスとして起こす。8790 を持っている会話（phase が running）でだけ呼ぶ
async function startBridge($: EngineInterface) {
  const w = mem.web
  if (w.starting || w.running || !w.enabled || mem.phase !== 'running' || mem.outdated !== null) return
  w.starting = true
  try {
    if (w.node === null) w.node = await findNode($)
    if (w.node === null) {
      w.blocked = WEB_NO_NODE
      await setWebLine($)
      return
    }
    w.token = crypto.randomUUID() + crypto.randomUUID()
    w.port = null
    const child = $.process.spawn({
      argv: [...w.node, `${$.plugin.root}/bridge/bridge.mjs`, '--config', `${$.plugin.root}/config/web.json`, '--server', BASE],
      env: { MYAI_WEB_CTL_TOKEN: w.token, MYAI_WEB_ORIGIN_KEY: mem.webKey, MYAI_WEB_HISTORY: w.history ? '1' : '0' },
    })
    w.running = true // ready が来るまでは制御窓口が無い（port が null）
    w.closeIter = () => void child.return({ code: null, signal: 'SIGTERM' }).catch(() => {})
    w.pid = null
    w.stopping = false
    w.killStage = 0
    const killed = new Promise<'kill'>(resolve => {
      w.killNow = () => resolve('kill')
    })
    let buf = ''
    let tail = ''
    try {
      // 流れを for await で読むと、出力が無いあいだは抜けられない。止めるときは killNow で輪を抜ける
      while (true) {
        const nextP = child.next()
        nextP.catch(() => {})
        const got = await Promise.race([nextP, killed])
        if (got === 'kill' || got.done === true) break
        const piece = got.value
        if (piece.stream === 'stderr') {
          tail = (tail + piece.text).slice(-400)
          $.ui.log(`my-ai-assistant(web): ${piece.text.trimEnd()}`, { to: 'debug' })
          continue
        }
        buf += piece.text
        for (let i = buf.indexOf('\n'); i >= 0; i = buf.indexOf('\n')) {
          const line = buf.slice(0, i).trim()
          buf = buf.slice(i + 1)
          if (line === '') continue
          try {
            await onBridgeEvent($, JSON.parse(line) as Record<string, unknown>)
          } catch {
            $.ui.log('my-ai-assistant(web): 読めない行を捨てました', { to: 'debug' })
          }
        }
      }
      void child.return({ code: null, signal: null }).catch(() => {}) // 流れを閉じる（型の説明: 閉じると子プロセスも止まる）
    } catch (err) {
      $.ui.log(`my-ai-assistant(web): 橋渡しを起動できませんでした (${String(err)})`, { to: 'debug' })
    }
    $.ui.log(`my-ai-assistant(web): 橋渡しが止まりました ${tail.trim().split('\n').pop() ?? ''}`.trim(), { to: 'debug' })
  } finally {
    const wasStopping = w.stopping
    w.running = false
    w.port = null
    w.starting = false
    w.pair = null
    closeSas()
    w.sas = null
    w.lastState = null
    w.closeIter = null
    w.killNow = null
    w.pid = null
    w.stopping = false
    w.killStage = 0
    // 会話（環境）が閉じたあとに橋渡しの流れが終わることがある。そのときは時計も画面も使えないので、後片付けは黙ってやめる
    try {
      w.retryAt = (await $.clock.now()) + WEB_RETRY_MS
      await setWebLine($)
      if (!w.enabled) await dropWebJobs($) // 止まる間際に届いた Web の依頼も捨てる
      if (wasStopping) $.ui.toast('Web 版: 橋渡しを止めました')
    } catch {
      w.retryAt = Date.now() + WEB_RETRY_MS
    }
  }
}

// 橋渡しを止める。1) 制御窓口に quit を送る（1回だけ） 2) WEB_STOP_WAIT_MS 待っても動いていたら、流れを閉じて子プロセスに kill -TERM
// 3) さらに待っても動いていたら kill -KILL。2・3 は syncWeb（1 秒ごと）が進める
async function stopBridge($: EngineInterface) {
  const w = mem.web
  if (!w.running || w.stopping) return
  w.stopping = true
  w.stopAt = await $.clock.now()
  w.killStage = 0
  await setWebLine($)
  await webCtl($, { cmd: 'quit' }) // 橋渡しが自分で終わる（子プロセスのループも終わる）
}

async function forceStopBridge($: EngineInterface) {
  const w = mem.web
  const stage = w.killStage + 1
  if (stage > 2) return
  w.killStage = stage
  w.stopAt = await $.clock.now()
  $.ui.log(`my-ai-assistant(web): 橋渡しが止まらないので${stage === 1 ? '止めにかかります' : '強制終了します'}`, { to: 'debug' })
  if (stage === 1) w.closeIter?.() // 流れを閉じる（型の説明: 閉じると子プロセスも止まる）。それでも終わらなければ 2 段目で輪を抜ける
  const pid = w.pid
  if (stage === 2) w.killNow?.() // 輪を抜けて、動いていない扱いにする（kill -KILL も送る）
  if (pid !== null && pid > 1) {
    const argv = mem.platform === 'windows' ? ['taskkill', '/PID', String(pid), '/T', '/F'] : ['kill', stage === 1 ? '-TERM' : '-KILL', String(pid)]
    await $.process.run(argv, { timeoutMs: 10000 }).catch(() => null)
  }
}

// 1 秒ごと（poll から）。使う設定で、この会話が画面を持っていれば橋渡しを起こす。そうでなければ止める
async function syncWeb($: EngineInterface) {
  const w = mem.web
  if (!w.loaded) return
  const owner = mem.phase === 'running' && mem.outdated === null
  const now = await $.clock.now()
  if (w.enabled && owner && !w.running && !w.starting && w.blocked === null && now >= w.retryAt) void startBridge($)
  if ((!w.enabled || !owner) && w.running && !w.stopping) void stopBridge($)
  // 止めると決めたあとは、連絡（status）を送らない。止まらなければ段階を上げて子プロセスを止める
  if (w.running && w.stopping) {
    if (now - w.stopAt >= WEB_STOP_WAIT_MS) void forceStopBridge($)
    await setWebLine($)
    return
  }
  if (!w.enabled || !owner) {
    await setWebLine($)
    return
  }
  if (w.running && w.port !== null && !w.isRefreshing && now - w.lastStatus >= WEB_STATUS_MS) {
    w.isRefreshing = true
    w.lastStatus = now
    try {
      const st = await webCtl($, { cmd: 'status' })
      w.lastState = st !== null && st.ok === true ? { state: String(st.state), browsers: Array.isArray(st.browsers) ? (st.browsers as unknown[]).map(String) : [] } : null
      await setWebLine($)
    } finally {
      w.isRefreshing = false
    }
  } else {
    await setWebLine($)
  }
}

const fmtTime = (iso: string | number) => {
  const d = new Date(iso)
  return Number.isNaN(d.getTime()) || d.getTime() === 0 ? '—' : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

// /my-ai-assistant web-… の実行。返す文はそのまま画面に出る
async function runWebCommand($: EngineInterface, sub: string, rest: string): Promise<string> {
  const w = mem.web
  await loadWeb($)
  if (sub === 'web-on') {
    await saveWebEnabled($, true)
    w.blocked = null
    w.node = null
    if (mem.phase !== 'running') {
      await setWebLine($)
      return 'Web 版を「使う」にしました。この会話は画面（8790）を持っていないので、橋渡しは画面を持っている会話で動きます。'
    }
    void startBridge($)
    await setWebLine($)
    return 'Web 版を「使う」にしました。橋渡しを起動します（node 22 以降が要ります）。次は /my-ai-assistant web-pair でブラウザを登録します。'
  }
  if (sub === 'web-off') {
    await saveWebEnabled($, false)
    const was = w.running
    await stopBridge($)
    w.pair = null
    closeSas()
    const d = await dropWebJobs($)
    await setWebLine($)
    return `Web 版を切りました（設定を「使わない」にし、橋渡しを止めています${was ? '。数秒で止まらなければ強制的に止めます。止まるとペインに出ます' : ''}）。${dropNote(d)}登録したブラウザは残っています。完全に外すなら web-revoke で取り消してください。`
  }
  if (sub === 'web-ok' || sub === 'web-ng') {
    const cur = w.sas
    if (cur === null || cur.expiresAt <= (await $.clock.now())) return '確認中のペアリングはありません。'
    cur.settle(sub === 'web-ok', false)
    return sub === 'web-ok'
      ? `6桁（${cur.code}）が同じと答えました。「${cur.name}」を登録します。`
      : '6桁が違うと答えました。登録せず、番号は捨てます。心当たりがなければ、番号を人に見せていないか確かめてください。'
  }
  if (sub === 'web-history') {
    const arg = rest.trim().toLowerCase()
    if (arg !== 'on' && arg !== 'off') return `Web から会話の履歴を読めるか: ${w.history ? '読める' : '読めない（既定）'}。変えるには /my-ai-assistant web-history on または off。on にすると、登録したブラウザから過去の会話の検索・閲覧ができます。`
    await saveWebHistory($, arg === 'on')
    if (w.running && w.port !== null) await webCtl($, { cmd: 'history', on: w.history })
    await setWebLine($)
    return w.history
      ? 'Web から会話の履歴を読めるようにしました。登録したブラウザから、過去の会話の検索・閲覧ができます。やめるなら /my-ai-assistant web-history off。'
      : 'Web から会話の履歴を読めないようにしました（既定）。'
  }
  if (!w.enabled) return 'Web 版は「使わない」設定です。使うなら先に /my-ai-assistant web-on を打ってください。'
  if (w.blocked !== null) return `Web 版を動かせません: ${w.blocked}`
  if (mem.phase !== 'running') return 'この会話は画面（8790）を持っていません。Web 版は、画面を持っている会話で操作してください。'
  if (!w.running || w.port === null) {
    void startBridge($)
    return '橋渡しを起動中です。数秒たってから、もう一度打ってください。'
  }
  if (sub === 'web-pair') {
    const r = await webCtl($, { cmd: 'pair' })
    if (r === null || r.ok !== true || typeof r.code !== 'string') return '番号を作れませんでした。数秒たってから、もう一度打ってください。'
    w.pair = { code: r.code, expiresAt: typeof r.expiresAt === 'number' ? r.expiresAt : (await $.clock.now()) + 300000 }
    await setWebLine($)
    mem.paneOpen = true
    void $.ui.open({ id: PANE, title: shownName() })
    return [
      `ペアリングの番号: ${fmtPairCode(r.code)}（12桁・5分で失効・1回きり）`,
      '1. Web の画面で「ペアリング」を開き、この番号を入れる（ハイフンは入れても入れなくても構いません）',
      '2. ブラウザに6桁が出たら、Claude の画面に出る質問「ブラウザに出ている6桁は …… ですか？」か、ペインの「確認用の6桁」と見比べる',
      '3. 同じなら「一致（登録する）」か /my-ai-assistant web-ok、違えば「違う（登録しない）」か /my-ai-assistant web-ng（違うと番号は捨てられます。先に答えた方を使います）',
      'コマンドは Claude の会話の入力欄に打ちます（画面の「▶ 実行」やターミナルではありません）。',
    ].join('\n')
  }
  if (sub === 'web-list') {
    const r = await webCtl($, { cmd: 'list' })
    if (r === null || !Array.isArray(r.browsers)) return '一覧を取れませんでした。'
    const bs = r.browsers as { name: string; fp: string; registeredAt: string; lastSeen: number }[]
    if (bs.length === 0) return '登録したブラウザはありません。'
    return ['登録したブラウザ:', ...bs.map(b => `- ${b.name}（指紋 ${b.fp.slice(0, 8)}・登録 ${fmtTime(b.registeredAt)}・最後 ${fmtTime(b.lastSeen)}）`)].join('\n')
  }
  if (sub === 'web-revoke') {
    const name = rest.trim()
    if (name === '') return '取り消す名前を付けてください（例: /my-ai-assistant web-revoke ノートのChrome）。名前は web-list で見られます。'
    const r = await webCtl($, { cmd: 'revoke', name })
    if (r === null) return '取り消せませんでした（橋渡しに届きません）。'
    if (r.ok === true) {
      const d = await dropWebJobs($, typeof r.fp === 'string' ? r.fp : undefined)
      return `取り消しました: ${String(r.name)}（このブラウザの依頼はもう通りません）。${dropNote(d)}`
    }
    if (r.error === 'not_found') return `「${name}」という登録は見つかりません。web-list で名前を確かめてください。`
    if (r.error === 'ambiguous') {
      const ms = r.matches as { name: string; fp: string }[]
      return `同じ名前が複数あります: ${ms.map(x => `${x.name}（指紋 ${x.fp}）`).join('、')}。指紋の先頭（8文字）を指定して、もう一度打ってください（例: web-revoke ${ms[0]?.fp ?? ''}）。`
    }
    return '取り消せませんでした。'
  }
  return WEB_HELP
}

export const register: Register = on => {
  on('session.start', async ($, e, next) => {
    const started = await next(e)
    mem.suggestTimes = []
    await $.command.register({
      name: 'my-ai-assistant',
      description: 'アシスタントの画面を出す（Web 版: web-on / web-pair / web-ok / web-ng / web-list / web-revoke 名前 / web-history on|off / web-off。会話の入力欄に打つ）',
      argumentHint: '[web-on|web-pair|web-ok|web-ng|web-list|web-revoke <名前>|web-history on|off|web-off]',
    })
    await loadSettings($) // 表示名を、ペインを開く前に読む
    await loadWeb($) // Web 版を使うか（既定は使わない）
    void startServer($)
    void registerDepartments($)
    void registerTools($)
    $.clock.every(POLL_MS, () => void poll($))
    if (e.isInteractive) {
      mem.paneOpen = true
      void $.ui.open({ id: PANE, title: shownName() })
    }

    return started
  })

  on('command.run', { command: 'my-ai-assistant' }, async ($, e) => {
    const [sub = '', ...restWords] = e.args.trim().split(/\s+/)
    if (sub.startsWith('web-')) return { text: await runWebCommand($, sub, restWords.join(' ')) }
    await loadSettings($)
    mem.paneOpen = true
    await $.ui.open({ id: PANE, title: shownName() })
    if (mem.phase === 'stopped' || mem.phase === 'failed') void startServer($)
    const now = await read($, status)

    return { text: `${shownName()}（試作）v${VERSION}: ${now.message}\n画面: ${BASE}/` }
  })

  // 執行役の土台：system prompt に汎用の SYSTEM 文（と部署の一覧）を1節足す。
  // prompt.section は「あるセクションの中身の書き換え」しかできず、新しい節は足せないので、
  // 節の一覧を扱う prompt.compose で末尾（session 側）に足す。
  on('prompt.compose', async ($, e, next) => {
    const base = await next(e)
    const text = executiveText(mem.extra, mem.depts) // 設定を変えたら、次の組み立て（次の turn）から新しい指示になる

    return { sections: [...base.sections, { id: EXEC_SECTION, text, scope: 'session' as const }] }
  })

  // 足した節の中身は prompt.section でも返す。この答えはキャッシュされ、設定を変えたときに
  // $.ui.invalidate('prompt.section') で捨てると、次の turn から新しい指示になる
  on('prompt.section', { name: EXEC_SECTION }, async () => ({ text: executiveText(mem.extra, mem.depts) }))

  // 設定で消した部署は、登録（$.agent.register）を取り消せないので、執行役の一覧と呼び出しから外す（開き直すと登録も無くなる）
  on('agent.offer', async ($, e, next) => {
    const result = await next(e)
    if (mem.orgDone && e.agent.startsWith(DEPT_PREFIX) && !mem.depts.some(d => `${DEPT_PREFIX}${d.name}` === e.agent)) return { isOffered: false }
    return result
  })

  // 止めるボタンで止めたことを、次に会話へ入る発言（画面の依頼・Code タブで打った発言・内部の依頼）に context で添える。添えたら控えを消す
  on('prompt.submit', async ($, e, next) => {
    if (e.command !== undefined || mem.stopNotes.length === 0) return next(e)
    const notes = mem.stopNotes.splice(0)
    const result = await next({ ...e, context: [...(e.context ?? []), notes.join('\n')] })
    if (result.drop !== undefined) mem.stopNotes.unshift(...notes) // 入らなかったときは、次の発言に回す
    return result
  })

  // 履歴検索の道具の呼び出し：サーバーの /api/history/* を呼んで、その文を結果として返す（権限の確認は engine が先に通す）
  for (const t of HISTORY_TOOLS) {
    on('tool.call', { tool: `${TOOL_PREFIX}${t.name}` }, async ($, e) => {
      const args = e as unknown as Record<string, unknown>
      return { result: await runHistoryTool($, t.name, args) }
    })
  }

  // 自分が頼んだ仕事で始まった turn を結び付ける
  //   agent モード: サブエージェントの最初の turn（e.agentId あり）を依頼文で突き合わせる
  //   chat  モード: 会話に入れた直後の最初の本会話 turn。入れるのは1件ずつなので、取り違えない
  on('turn.start', async ($, e, next) => {
    if (e.agentId !== undefined) {
      for (const [jobId, text] of mem.agentPending) {
        if (lf(e.text).includes(lf(text))) {
          mem.agentJobs.set(e.agentId, jobId)
          mem.agentPending.delete(jobId)
          break
        }
      }
      await trackStart($, e.agentId, e.text)
    } else {
      const active = mem.chatActive
      if (active !== null && active.turnId === undefined && lf(e.text).includes(lf(active.job.text))) {
        active.turnId = e.turnId
      }
      mem.mainTurnId = e.turnId
      mem.busySince = new Date(await $.clock.now()).toISOString()
      void pushState($, true)
    }

    return next(e)
  })

  // 本会話の途中経過（道具の動き）。送りすぎないよう 2 秒に 1 回まで
  on('turn.step', async function* ($, e, next) {
    if (e.agentId === undefined) {
      mem.model = e.model
      void pushState($, false)
    } else {
      void trackStep($, e.agentId, e.model)
    }

    return yield* next(e)
  })

  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    const ok = e.reason === 'answer'
    if (e.agentId !== undefined) {
      await trackComplete($, e.agentId, e.reason, e.answer)
      const jobId = mem.agentJobs.get(e.agentId)
      if (jobId !== undefined) {
        mem.agentJobs.delete(e.agentId)
        await sendResult($, jobId, ok, ok ? e.answer : `終わり方: ${e.reason}。${AGENT_DENIED_HINT}`)
      }
    } else {
      if (mem.mainTurnId === e.turnId) mem.mainTurnId = undefined
      await pushState($, true)
      if (mem.chatActive !== null && mem.chatActive.turnId === e.turnId) {
        await finishChat($, ok ? e.answer : e.reason === 'aborted' ? '止めました' : `終わり方: ${e.reason}`, ok)
        void pumpChat($)
      }
    }

    return result
  })

  // ---- ペイン：版の番号＋ボタン1つ ----
  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text, Button, Markdown } = $.ui.resolve(e)
    const now = await read($, status)
    const count = await read($, handled)
    const lastAnswer = await read($, last)
    const org = await read($, orgAtom)
    const name = await read($, nameAtom)
    const web = await read($, webAtom)

    return (
      <Box flexDirection="column">
        {/* 6桁の確認中は、ペインが狭くても見えるように、いちばん上に出す */}
        {web.sas !== null && (
          <Box flexDirection="column">
            <Text bold>確認用の6桁: {web.sas.code}</Text>
            <Text dimColor>ブラウザの画面と同じなら「一致」、違えば「違う」（質問が出ているときは、そちらでも答えられます。先に答えた方を使います）</Text>
            <Button key="web-sas-ok" variant="primary" label="一致（登録する）" onPress={() => void runWebCommand($, 'web-ok', '')} />
            <Button key="web-sas-ng" label="違う（登録しない）" onPress={() => void runWebCommand($, 'web-ng', '')} />
          </Box>
        )}
        <Text bold>{name}（試作） v{VERSION}</Text>
        <Text dimColor={now.phase !== 'running'}>
          {now.message}
        </Text>
        <Text dimColor>{org}</Text>
        <Markdown text={`画面: [${BASE}/](${BASE}/)`} />
        <Text dimColor>
          こなした依頼: {String(count)} 件{lastAnswer ? ` ・ 最後: ${lastAnswer}` : ''}
        </Text>
        <Text dimColor={web.line === 'Web: 使わない'}>{web.line}</Text>
        {web.line !== 'Web: 使わない' && <Text dimColor>Web から履歴: {web.history ? '読める（/my-ai-assistant web-history off で止める）' : '読めない（既定。読ませるなら /my-ai-assistant web-history on）'}</Text>}
        {web.note !== null && <Text bold>{web.note}</Text>}
        {web.pair !== null && (
          <Text>
            ペアリングの番号: {fmtPairCode(web.pair.code)}（12桁・5分で失効。Web の画面に入れたあと、6桁を見比べる）
          </Text>
        )}
        <Button key="open" variant="primary" label="画面を開く" onPress={() => void openScreen($)} />
        {mem.web.enabled && <Button key="web-off" label="Web をすぐ切る" onPress={() => void runWebCommand($, 'web-off', '')} />}
      </Box>
    )
  })
}
