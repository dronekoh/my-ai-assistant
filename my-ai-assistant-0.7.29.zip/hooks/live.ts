// 途中の文字（作業中に、本会話の返事を断片のまま画面へ流す）。ここは文字の控えと送る形だけで、通信はしない（hooks/register.tsx が送る）。
// 画面に出すのは本会話の見える文字（text の断片）だけ。考え中の文字（thinking）・部署の文字は入れない。
// 流れた文字と完成した発言が二重にならないよう、画面は「読み終えた塊（done）で、完成した発言に含まれるもの」を隠す。
// 塊はモデルの1回の応答（step）の中の1ブロックごと。切り捨てるときは末尾を残す（末尾も完成した発言の一部なので、見比べられる）
export const LIVE_MIN_MS = 250 // 手元のサーバーへ送る間隔の下限（まとめて送る。最初の文字は待たずに送る）
export const LIVE_PART_MAX = 8000 // 1塊の文字数
export const LIVE_TOTAL_MAX = 16000 // 1回に送る文字数の合計
export const LIVE_PARTS_MAX = 8 // 1回に送る塊の数

export type LivePart = { key: string; step: number; text: string; done: boolean }
export type LivePartView = { key: string; text: string; done: boolean; cut: boolean }
type Chunk = { kind: string; index?: number; text?: string }

// 断片を1つ控える。見える文字が増えた・塊が読み終わったときだけ true（送る内容が変わった）
export function addLiveChunk(parts: LivePart[], step: number, chunk: Chunk): boolean {
  if (chunk.kind === 'text' && typeof chunk.text === 'string' && chunk.text !== '') {
    const key = `${step}.${chunk.index ?? 0}`
    const part = parts.find(p => p.key === key)
    if (part !== undefined) part.text += chunk.text
    else parts.push({ key, step, text: chunk.text, done: false })
    return true
  }
  return chunk.kind === 'stop' ? endLiveStep(parts, step) : false
}

// モデルの1回の応答が終わった：その応答の塊は、もう増えない
function endLiveStep(parts: LivePart[], step: number): boolean {
  let changed = false
  for (const p of parts) {
    if (p.step === step && !p.done) {
      p.done = true
      changed = true
    }
  }
  return changed
}

// 送る形。新しい塊から順に、合計の上限まで（古い塊は完成した発言として state で先に届いている）
export function liveView(parts: LivePart[]): LivePartView[] {
  const out: LivePartView[] = []
  let room = LIVE_TOTAL_MAX
  for (let i = parts.length - 1; i >= 0 && out.length < LIVE_PARTS_MAX && room > 0; i--) {
    const p = parts[i]
    if (p === undefined) continue
    const max = Math.min(LIVE_PART_MAX, room)
    const cut = p.text.length > max
    const text = cut ? p.text.slice(-max) : p.text
    room -= text.length
    out.unshift({ key: p.key, text, done: p.done, cut })
  }
  return out
}
