// 画面（8790）をどの会話が出すかを、利用者が選べるようにする部品（決め方は純粋な関数。読み書きは register.tsx）。
//
// 置き場所（同じパソコンの会話どうしで共有する。中身は会話の題名・作業フォルダ・版・時刻だけ。会話の本文は入れない）
//   <データ>/sessions/<会話の id>.json : 会話ごとの「生きている」印。5 秒に 1 回、自分の分だけ書き直す
//   <データ>/screen.json                : { pin: 画面を出す会話, move: 最後に移ったときの記録 }
//   <データ> は MYAI_DATA_DIR があればそれ、無ければ ~/.my-ai-assistant（server.py と同じ）
//
// 決まり
//   1) 画面を出す会話（pin）がある間は、ほかの会話は 8790 が空いても取らない（版の更新・再起動で一度手放しても、同じ会話が取り直す）
//   2) pin の会話が本当に終わった（印が SCREEN_DEAD_MS 書き直されない・終わりの印を残した）ときだけ、ほかの会話が取る
//   3) 取った会話は pin を自分にし、前の pin と違えば move に「〇〇 から △△ に移った（理由）」を残す（画面がはっきり出す）
//   4) 画面で別の会話を選ぶと、持ち主が pin をその会話にして手放す。選ばれた会話が SCREEN_GIVEBACK_MS 待っても出せなければ、
//      手放した会話が取り直し、その旨を move に残す（画面が消えたままにしない）
//   5) pin の会話は、新しい版が入っても画面を手放さない（次の発言・開き直しで、その会話のまま新しい版になる）

export const SCREEN_BEAT_MS = 5000 // 生きている印を書き直す間隔
export const SCREEN_DEAD_MS = 45000 // これだけ書き直されなければ、その会話は終わったとみなす
export const SCREEN_GIVEBACK_MS = 30000 // 画面を渡した相手が出せないとき、取り戻すまでの待ち
export const SCREEN_TITLE_MS = 60000 // 会話の題名を読み直す間隔
export const SCREEN_TITLE_MAX = 80
export const SCREEN_PEERS_MAX = 20
export const SESSION_ID_RE = /^[A-Za-z0-9-]{8,64}$/

export type Peer = {
  id: string
  title: string // 会話の題名（Claude アプリで付いた名前）。無ければ空
  cwd: string | null
  root: string | null
  version: string
  startedAt: string | null
  at: number // 最後に印を書いた時刻（ms）。0 は「終わった」
  phase: string // running / port-busy / no-python など
  owner: boolean // いま画面を出しているか
}
export type Pin = { id: string; title: string; by: 'user' | 'auto'; at: number }
export type MoveEnd = { id: string; title: string }
export type Move = { from: MoveEnd | null; to: MoveEnd; reason: string; at: number }
export type ScreenFile = { pin: Pin | null; move: Move | null }
// 画面へ送る1件（server.py の clean_screen が読む形）
export type PeerView = { id: string; title: string; cwd: string | null; version: string; startedAt: string | null; owner: boolean; phase: string; self: boolean; pinned: boolean }
export type ScreenView = { self: string; sessions: PeerView[]; pin: { id: string; title: string; by: 'user' | 'auto'; at: string } | null; move: { from: MoveEnd | null; to: MoveEnd; reason: string; at: string } | null; newer: string | null }

const oneLine = (s: string) => s.replace(/[\u0000-\u001f\u007f\u2028\u2029]/g, ' ').replace(/\s+/g, ' ').trim()
const str = (v: unknown, max: number): string => (typeof v === 'string' ? oneLine(v).slice(0, max) : '')
const strOrNull = (v: unknown, max: number): string | null => {
  const s = typeof v === 'string' ? v.slice(0, max) : ''
  return s === '' ? null : s
}
const num = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : 0)

export function cleanPeer(raw: unknown): Peer | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null
  const r = raw as Record<string, unknown>
  if (typeof r.id !== 'string' || !SESSION_ID_RE.test(r.id)) return null
  return {
    id: r.id,
    title: str(r.title, SCREEN_TITLE_MAX),
    cwd: strOrNull(r.cwd, 1000),
    root: strOrNull(r.root, 1000),
    version: str(r.version, 20),
    startedAt: strOrNull(r.startedAt, 40),
    at: num(r.at),
    phase: str(r.phase, 20),
    owner: r.owner === true,
  }
}
function cleanEnd(raw: unknown): MoveEnd | null {
  if (!raw || typeof raw !== 'object') return null
  const r = raw as Record<string, unknown>
  if (typeof r.id !== 'string' || !SESSION_ID_RE.test(r.id)) return null
  return { id: r.id, title: str(r.title, SCREEN_TITLE_MAX) }
}
export function cleanScreenFile(raw: unknown): ScreenFile {
  const out: ScreenFile = { pin: null, move: null }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out
  const r = raw as Record<string, unknown>
  const p = r.pin as Record<string, unknown> | undefined
  if (p && typeof p === 'object' && typeof p.id === 'string' && SESSION_ID_RE.test(p.id)) {
    out.pin = { id: p.id, title: str(p.title, SCREEN_TITLE_MAX), by: p.by === 'user' ? 'user' : 'auto', at: num(p.at) }
  }
  const m = r.move as Record<string, unknown> | undefined
  if (m && typeof m === 'object') {
    const to = cleanEnd(m.to)
    if (to !== null) out.move = { from: cleanEnd(m.from), to, reason: str(m.reason, 200), at: num(m.at) }
  }
  return out
}

export const isAlive = (p: Peer | undefined, now: number): boolean => p !== undefined && p.at > 0 && now - p.at < SCREEN_DEAD_MS

// 利用者が見分けられる名前：題名 → 作業フォルダの名前 → id の先頭
export function peerLabel(p: { id: string; title?: string; cwd?: string | null; root?: string | null } | null | undefined): string {
  if (!p) return '前の会話'
  if (p.title) return p.title
  const dir = (p.cwd || p.root || '').replace(/[\\/]+$/, '')
  const base = dir.split(/[\\/]/).pop() || ''
  return base !== '' ? `${base} の会話` : `会話 ${p.id.slice(0, 8)}`
}

// 8790 が空いているとき、この会話が取ってよいか
//   self: この会話の id / pin: 画面を出す会話 / peers: 生きている印 / newer: 入っている新しい版（無ければ null）
//   released: この会話が画面を渡した相手と時刻（渡していなければ null）
export type TakeDecision = { take: boolean; reason: 'free' | 'pinned-self' | 'pin-gone' | 'giveback' | 'wait-pin' | 'outdated'; pin: Pin | null }
export function decideTake(a: { self: string; pin: Pin | null; peers: readonly Peer[]; now: number; newer: string | null; released: { to: string; at: number } | null }): TakeDecision {
  const { self, pin, now } = a
  if (pin !== null && pin.id === self) return { take: true, reason: 'pinned-self', pin }
  if (pin !== null && isAlive(a.peers.find(p => p.id === pin.id), now)) {
    if (a.released !== null && a.released.to === pin.id && now - a.released.at >= SCREEN_GIVEBACK_MS) return { take: true, reason: 'giveback', pin }
    return { take: false, reason: 'wait-pin', pin }
  }
  if (a.newer !== null) return { take: false, reason: 'outdated', pin }
  return { take: true, reason: pin === null ? 'free' : 'pin-gone', pin }
}

// 画面を取ったとき、screen.json をどう書き直すか（変えなくてよければ null）
export function claimScreen(prev: ScreenFile, me: MoveEnd, reason: TakeDecision['reason'], now: number): ScreenFile | null {
  const pin = prev.pin
  if (pin !== null && pin.id === me.id) {
    if (pin.title === me.title || me.title === '') return null
    return { pin: { ...pin, title: me.title }, move: prev.move } // 題名が変わっただけ
  }
  const nextPin: Pin = { id: me.id, title: me.title, by: 'auto', at: now }
  if (pin === null) return { pin: nextPin, move: prev.move }
  const from: MoveEnd = { id: pin.id, title: pin.title }
  const why =
    reason === 'giveback'
      ? `「${pin.title || '選んだ会話'}」が画面を出せなかったので、元の会話に戻しました`
      : `「${pin.title || '前の会話'}」が終わったので、この会話が画面を引き継ぎました`
  return { pin: nextPin, move: { from, to: me, reason: why, at: now } }
}

// 画面で別の会話を選んだとき
export function chooseScreen(me: MoveEnd, target: MoveEnd, now: number): ScreenFile {
  return { pin: { id: target.id, title: target.title, by: 'user', at: now }, move: { from: me, to: target, reason: '画面で選びました', at: now } }
}

// 画面へ送る形（生きている会話だけ・画面を出している会話を先頭に・新しく始まった順）
export function screenView(self: string, peers: readonly Peer[], file: ScreenFile, now: number, newer: string | null): ScreenView {
  const alive = peers.filter(p => isAlive(p, now))
  alive.sort((x, y) => Number(y.owner) - Number(x.owner) || (y.startedAt ?? '').localeCompare(x.startedAt ?? ''))
  const iso = (ms: number) => new Date(ms).toISOString()
  return {
    self,
    sessions: alive.slice(0, SCREEN_PEERS_MAX).map(p => ({
      id: p.id,
      title: peerLabel(p),
      cwd: p.cwd,
      version: p.version,
      startedAt: p.startedAt,
      owner: p.owner,
      phase: p.phase,
      self: p.id === self,
      pinned: file.pin?.id === p.id,
    })),
    pin: file.pin === null ? null : { id: file.pin.id, title: file.pin.title, by: file.pin.by, at: iso(file.pin.at) },
    move: file.move === null ? null : { from: file.move.from, to: file.move.to, reason: file.move.reason, at: iso(file.move.at) },
    newer,
  }
}

// 会話の記録（jsonl）の置き場所の名前：絶対パスの英数字以外を - にしたもの（Claude Code と同じ）
export const projectSlug = (dir: string): string => dir.replace(/[^A-Za-z0-9]/g, '-')

// grep -o で抜いた "customTitle":"…" の行から、最後の題名を取り出す
export function parseTitle(out: string): string {
  const lines = out.split('\n').map(l => l.trim()).filter(Boolean)
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const v = (JSON.parse(`{${lines[i]}}`) as { customTitle?: unknown }).customTitle
      if (typeof v === 'string' && v.trim() !== '') return oneLine(v).slice(0, SCREEN_TITLE_MAX)
    } catch {
      // 壊れた行は飛ばす
    }
  }
  return ''
}
