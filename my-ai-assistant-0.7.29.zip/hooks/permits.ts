// 許可待ち（Claude アプリの「Claude がこのコマンドを実行することを許可しますか？」で止まっている呼び出し）を知って、画面と執行役に伝える。
//
// 知る: classic.PermissionRequest（確認の画面を出す直前にエンジンが鳴らす。tool_name・tool_input・agent_id がある）を
//       見るだけで、答えは何も変えずに next(e) を返す（d.ts の PermissionRequestHookInput / ClassicResultFields）。
// 消す: 同じ呼び出しの classic.PostToolUse / classic.PostToolUseFailure / classic.PermissionDenied、
//       同じ部署（agentId。本会話は無し）の次の turn.step・turn.complete（答えが出るまで、その部署の流れは進まない）、
//       PERMIT_TTL_MS を過ぎたもの。
// 答える: しない。画面から許可を出す仕組みは入れない（docs/migration-plan.md の「承認カード」の決まり）。
//        画面は「Claude アプリで答えてください」と出し、パソコンの画面だけ「チャットを開く」を出す。
import type { Dept } from './register'

export type Permit = {
  id: string
  agentId: string | null // 本会話（執行役）は null
  tool: string
  key: string // tool と input を並べた比べ用の文字列（PostToolUse などと突き合わせる）
  summary: string // 何を（コマンドの中身・ファイル名など。1行・短く）
  since: number // 知った時刻（ms）
  sessionId: string | null // この会話の id（Claude アプリの会話を開くのに使う。サーバーが local_ の id に直す）
}
// 画面へ送る1件（server.py の clean_permits が読む形）
export type PermitView = { id: string; agentId: string | null; department: string; tool: string; summary: string; since: string; sessionId: string | null }

export const PERMIT_MAX = 20
export const PERMIT_TTL_MS = 60 * 60 * 1000 // 1時間たっても消えないものは、取りこぼした印として出さない
export const PERMIT_SUMMARY_MAX = 200
export const PERMIT_NOTE_HEAD = '（画面の控え：許可待ちが'

const oneLine = (s: string) => s.replace(/\s+/g, ' ').trim()
const cut = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s)

export function permitKey(tool: unknown, input: unknown): string {
  let s = ''
  try {
    s = JSON.stringify(input ?? null) ?? ''
  } catch {
    s = String(input)
  }
  return `${String(tool)}\u0000${s}`
}

// 何の許可か（Bash はコマンド、ファイルの道具はファイル、Web はアドレス。ほかは引数を短く）
export function permitSummary(tool: string, input: unknown): string {
  const o = input !== null && typeof input === 'object' ? (input as Record<string, unknown>) : {}
  const pick = (k: string) => (typeof o[k] === 'string' && o[k] !== '' ? (o[k] as string) : null)
  const main = pick('command') ?? pick('file_path') ?? pick('notebook_path') ?? pick('url') ?? pick('path') ?? pick('pattern') ?? pick('description')
  let text = main
  if (text === null) {
    try {
      text = JSON.stringify(input ?? {}) ?? ''
    } catch {
      text = ''
    }
  }
  return cut(oneLine(text), PERMIT_SUMMARY_MAX)
}

export function addPermit(list: Permit[], p: Omit<Permit, 'key' | 'summary'> & { input: unknown }): Permit {
  const rec: Permit = { id: p.id, agentId: p.agentId, tool: p.tool, key: permitKey(p.tool, p.input), summary: permitSummary(p.tool, p.input), since: p.since, sessionId: p.sessionId }
  list.push(rec)
  if (list.length > PERMIT_MAX) list.splice(0, list.length - PERMIT_MAX)
  return rec
}

// 呼び出しが動いた・断られた：同じ部署の同じ呼び出しを1件消す（同じものが並んでいれば古い方から）
export function clearPermitCall(list: Permit[], agentId: string | null, tool: unknown, input: unknown): boolean {
  const key = permitKey(tool, input)
  const i = list.findIndex(p => p.agentId === agentId && p.key === key)
  if (i < 0) return false
  list.splice(i, 1)
  return true
}

// その部署の流れが先へ進んだ（次の turn.step・turn.complete）：その部署の分を全部消す
export function clearPermitAgent(list: Permit[], agentId: string | null): boolean {
  const before = list.length
  for (let i = list.length - 1; i >= 0; i--) if (list[i]!.agentId === agentId) list.splice(i, 1)
  return list.length !== before
}

export function dropOldPermits(list: Permit[], now: number): boolean {
  const before = list.length
  for (let i = list.length - 1; i >= 0; i--) if (now - list[i]!.since > PERMIT_TTL_MS) list.splice(i, 1)
  return list.length !== before
}

// 部署の表示名（仕事一覧の部署の id → 設定の表示名）。本会話は「執行役」
export function permitDept(agentId: string | null, taskDept: (id: string) => string | null, depts: readonly Dept[]): string {
  if (agentId === null) return '執行役'
  const d = taskDept(agentId)
  if (d === null) return '部署'
  const hit = depts.find(x => x.name === d)
  return hit ? (hit.label ?? hit.name) : d
}

export function permitViews(list: readonly Permit[], dept: (agentId: string | null) => string): PermitView[] {
  return list.map(p => ({ id: p.id, agentId: p.agentId, department: dept(p.agentId), tool: p.tool, summary: p.summary, since: new Date(p.since).toISOString(), sessionId: p.sessionId }))
}

// 執行役に添える1行（次に会話へ入る発言の末尾・context）。無ければ null。
// 「（画面の」で始めて「）」で終える1行なので、画面の表示では userText が外す
export function permitNote(views: readonly PermitView[]): string | null {
  if (views.length === 0) return null
  const items = views.slice(0, 5).map(v => `${v.department}が ${v.tool}『${cut(v.summary.replace(/[（）]/g, ' '), 80)}』`)
  const more = views.length > 5 ? ` ほか${views.length - 5}件` : ''
  return `${PERMIT_NOTE_HEAD}${views.length}件あります。${items.join('、')}${more} の実行の許可を、Claude アプリの確認の画面で待っています。進み具合を聞かれたら「作業中」とだけ答えず、このことを先に伝えてください）`
}
