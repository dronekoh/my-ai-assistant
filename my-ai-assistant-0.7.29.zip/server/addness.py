"""Addness の「やること」一覧（A1: 一覧の表示・済み・取り消し）。

設定は利用者の手元だけに置く: <データ置き場>/addness.json（無ければ Addness の機能は出さない）。
組織・メンバー・ゴールの ID や人の名前は、配布物には入れない（ひな形は config/addness.example.json）。

  todoFile       やることの一覧（JSON）。定期タスクや「今すぐ更新」（A2）が書く。既定 <データ置き場>/addness/addness-todo.json
  doneFile       済みにしたものの記録（JSON・{"items": [...]}）。一覧を作る側が、ここにあるものを外す。既定 同じフォルダの done.json
  delegateLabel  一覧の項目に delegate（または旧名 murai）の印だけがあって、誰が対応中か（delegate_to）が無いときに出す札
                 （例「代理の人が対応中」）。delegate_to があれば「<その人>対応中」と出す（名前は一覧を作る側が Addness を見て決める）
  dryRunOnly     true と書いたときだけ、送信OK を投稿せずに流れだけ確かめる（ドライラン）。書いていなければ本当に投稿する
                 （外へ出るのは、利用者が下書きの「送信OK」を押したときだけ。関所が下書きと同じ宛先・本文の1回だけを通す）
                 旧名 dryRun は読まない（古いひな形が true を書いていたため。それで送れないままになる人を出さない）
  A2〜A4（addness_chat.py が使う）:
  refreshSkill   「今すぐ更新」の手順書のパス（無ければ config/addness-refresh.example.md）
  stateFile      更新のたびに {"last_checked_at": …} を書くファイル（任意。定期タスクと前回の時刻を分け合うとき）
  refreshModel / consultModel  更新係・相談役のモデル（既定 sonnet）
  orgs           {名前: {id, aliases, members: [{id, name, note}]}}（下書きの宛先を確かめる・投稿先の組織）
  defaultOrg     いつもの組織（名前か ID）。更新・投稿のあと、ここへ戻す
  selfNames      自分の表示名（下書きの宛先から外す）
  consultExtra / delegateNote  相談役への追加の決まり・代理の人の扱い（社内の言い回しはここに書く）
  todoHtml       「今すぐ更新」で更新係が書いてよい一覧のページ（任意。手順書が HTML も作るとき）
  workDir        更新係・相談役（claude -p）を動かすフォルダ。相談役はここのファイルを読める（任意。既定 <データ置き場>/addness/work）
  consultTools   相談役に足す読む道具の名前（任意。mcp__… の完全な名前。書き込み系の Addness の道具は足せない）

取り消しの控えは <データ置き場>/addness/_done.json（ほかの道具とは分ける）。
"""
from __future__ import annotations

import json
import os
import re
import threading
from datetime import datetime
from pathlib import Path

DONE_METHOD = "My AI Assistant で済み"
DEFAULT_DELEGATE_LABEL = "代理の人が対応中"
MAX_UNDO = 200

_lock = threading.Lock()
_data_dir: Path | None = None


def configure(data_dir: Path) -> None:
    global _data_dir
    _data_dir = Path(data_dir)


def _dir() -> Path:
    return (_data_dir or (Path.home() / ".my-ai-assistant")) / "addness"


def config_path() -> Path:
    return (_data_dir or (Path.home() / ".my-ai-assistant")) / "addness.json"


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (FileNotFoundError, NotADirectoryError):
        return default
    except (ValueError, UnicodeDecodeError, OSError):
        return default


def _write_json(p: Path, data, indent=2) -> None:
    """途中で切れたファイルを残さないよう、隣に書いてから置き換える"""
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + f".tmp-{os.getpid()}")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=indent) + "\n", encoding="utf-8")
    os.replace(tmp, p)


def _path(v, default: Path) -> Path:
    if isinstance(v, str) and v.strip():
        return Path(os.path.expanduser(v.strip()))
    return default


def load_config() -> dict | None:
    """設定（無い・壊れているときは None＝Addness の機能を出さない）"""
    cfg = _read_json(config_path(), None)
    if not isinstance(cfg, dict) or cfg.get("enabled") is False:
        return None
    d = _dir()
    label = cfg.get("delegateLabel")
    orgs = _orgs(cfg.get("orgs"))
    return {
        "todoFile": _path(cfg.get("todoFile"), d / "addness-todo.json"),
        "doneFile": _path(cfg.get("doneFile"), d / "done.json"),
        "delegateLabel": label.strip()[:40] if isinstance(label, str) and label.strip() else DEFAULT_DELEGATE_LABEL,
        # 既定は本当に投稿する（送信OK を押したときだけ）。ドライランは dryRunOnly: true と書いた人だけ。
        # 旧名 dryRun は読まない：0.7.26 までのひな形が "dryRun": true を入れていて、写した人が送れないままになるため
        "dryRun": cfg.get("dryRunOnly") is True,
        # A2〜A4
        "refreshSkill": _path(cfg.get("refreshSkill"), Path()) if _str(cfg.get("refreshSkill"), 1000) else None,
        "stateFile": _path(cfg.get("stateFile"), Path()) if _str(cfg.get("stateFile"), 1000) else None,
        "refreshModel": _model(cfg.get("refreshModel"), "sonnet"),
        "consultModel": _model(cfg.get("consultModel"), "sonnet"),
        "orgs": orgs,
        "defaultOrgId": _org_id(orgs, cfg.get("defaultOrg")),
        "selfNames": [s.strip()[:60] for s in (cfg.get("selfNames") or []) if isinstance(s, str) and s.strip()][:10],
        "consultExtra": _str(cfg.get("consultExtra"), 8000),
        "todoHtml": _path(cfg.get("todoHtml"), Path()) if _str(cfg.get("todoHtml"), 1000) else None,
        "workDir": _path(cfg.get("workDir"), d / "work"),
        "consultTools": [t.strip() for t in (cfg.get("consultTools") or []) if isinstance(t, str) and TOOL_RE.match(t.strip())][:50],
        "delegateNote": _str(cfg.get("delegateNote"), 2000),
    }


UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
TOOL_RE = re.compile(r"^mcp__[A-Za-z0-9_.-]{1,80}__[A-Za-z0-9_-]{1,80}$")
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")


def _str(v, n: int) -> str:
    return v.strip()[:n] if isinstance(v, str) else ""


def _model(v, default: str) -> str:
    return v.strip() if isinstance(v, str) and MODEL_RE.match(v.strip()) else default


def _orgs(raw) -> dict:
    """組織の一覧 {名前: {id, aliases, members: [{id, name, note}]}}。形の違うものは捨てる"""
    out = {}
    if not isinstance(raw, dict):
        return out
    for name, o in list(raw.items())[:20]:
        if not isinstance(name, str) or not name.strip() or not isinstance(o, dict):
            continue
        oid = str(o.get("id") or "").strip().lower()
        if not UUID_RE.match(oid):
            continue
        mem = []
        for m in (o.get("members") or [])[:500]:
            if isinstance(m, dict) and UUID_RE.match(str(m.get("id") or "").strip()) and _str(m.get("name"), 80):
                mem.append({"id": str(m["id"]).strip().lower(), "name": _str(m.get("name"), 80), "note": _str(m.get("note"), 200)})
        aliases = [a.strip()[:80] for a in (o.get("aliases") or []) if isinstance(a, str) and a.strip()][:10]
        out[name.strip()[:80]] = {"id": oid, "aliases": aliases, "members": mem}
    return out


def _org_id(orgs: dict, v) -> str | None:
    """既定の組織（名前か ID）を ID にする"""
    s = _str(v, 100)
    if not s:
        return None
    if s in orgs:
        return orgs[s]["id"]
    return s.lower() if UUID_RE.match(s) else None


def enabled() -> bool:
    return load_config() is not None


def _undo_file() -> Path:
    return _dir() / "_done.json"


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _done_entry(item: dict) -> dict:
    # 「済み」＝利用者の手からボールが離れた印（案件全体の完了ではない）。済んだ時刻より後に他の人から
    # 新しいコメントが来たら、一覧を作る側が reopened: true を付けて同じ id で載せ直す（done_hides を見る）
    return {"id": item.get("id"), "goal_id": item.get("goal_id"), "comment_id": item.get("comment_id"),
            "依頼": f"{item.get('requester') or ''}：{item.get('title') or ''}".strip("："),
            "済んだ方法": DONE_METHOD, "記録日": datetime.now().strftime("%Y-%m-%d"), "済んだ時刻": _now()}


def done_hides(it: dict, e: dict) -> bool:
    """済みの記録 e が、一覧の項目 it を隠すか。

    - 同じゴールの同じ返信先（comment_id）なら隠す（新しいコメントは来ていない）
    - 同じ id なら隠す。ただし、済みのあとに他の人から新しいコメントが来て載せ直されたもの
      （reopened: true で、返信先が済んだときと違う）は隠さない＝また一覧に出る"""
    if not isinstance(it, dict) or not isinstance(e, dict) or not e.get("goal_id"):
        return False
    if str(e.get("goal_id")) != str(it.get("goal_id")):
        return False
    if e.get("comment_id") and str(e.get("comment_id")) == str(it.get("comment_id")):
        return True
    if isinstance(e.get("id"), str) and e.get("id") == it.get("id"):
        return it.get("reopened") is not True
    return False


def _same_done(a: dict, b: dict) -> bool:
    # 同じ依頼は更新しても同じ id のまま（返信先のコメントは変わることがある）。id が無い古い記録は中身で見る
    if b.get("済んだ方法") != DONE_METHOD or a.get("goal_id") != b.get("goal_id"):
        return False
    if a.get("id") and a.get("id") == b.get("id"):
        return True
    return a.get("comment_id") == b.get("comment_id") and a.get("依頼") == b.get("依頼")


def _local_done() -> list[dict]:
    return [u for u in ((_read_json(_undo_file(), {}) or {}).get("items") or []) if isinstance(u, dict)]


def delegate_who(it: dict) -> str:
    """誰が対応中か（delegate_to。例「吉澤さん」）。無ければ空。名前は一覧を作る側が Addness を見て決める"""
    w = it.get("delegate_to") if isinstance(it, dict) else None
    if not isinstance(w, str):
        return ""
    w = re.sub(r"[\x00-\x1f\x7f]", "", w).strip()
    w = re.sub(r"\s*対応中$", "", w).strip()
    return w[:30]


def delegate_text(it: dict, label: str) -> str:
    """一覧・相談に出す札。delegate_to があれば「<その人>対応中」、印だけなら設定の札、無ければ空"""
    who = delegate_who(it)
    if who:
        return f"{who}対応中"
    return label if (it.get("delegate") or it.get("murai")) else ""


def _clean_item(it: dict, label: str = DEFAULT_DELEGATE_LABEL) -> dict:
    """画面に渡す形。代理の印は delegate に揃える（古い一覧の murai も受ける）。誰が対応中かは delegateText に"""
    out = dict(it)
    if "murai" in out:
        out["delegate"] = bool(out.pop("murai")) or bool(out.get("delegate"))
    who = delegate_who(out)
    if who:
        out["delegate"] = True
        out["delegate_to"] = who
    else:
        out.pop("delegate_to", None)
    out["delegate"] = bool(out.get("delegate"))
    text = delegate_text(out, label)
    if text:
        out["delegateText"] = text
    return out


def items_view() -> dict:
    """画面の Addness タブ用。設定が無ければ enabled: False、一覧がまだ無ければ exists: False"""
    cfg = load_config()
    if not cfg:
        return {"enabled": False}
    base = {"enabled": True, "dryRun": cfg["dryRun"], "delegateLabel": cfg["delegateLabel"]}
    try:
        st = cfg["todoFile"].stat()
    except (FileNotFoundError, NotADirectoryError):
        return {**base, "exists": False}
    except OSError:
        return {**base, "exists": False, "broken": True}
    data = _read_json(cfg["todoFile"], None)
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        return {**base, "exists": False, "broken": True}
    done_here = [d.get("entry") or {} for d in _local_done()]
    items = [_clean_item(it, cfg["delegateLabel"]) for it in data["items"] if isinstance(it, dict) and it.get("id")
             and not any(done_hides(it, e) for e in done_here)]
    ids = {it["id"] for it in items}
    nxt = [n for n in (data.get("next") or []) if isinstance(n, dict) and (not n.get("item_id") or n.get("item_id") in ids)]
    return {**base, "exists": True, "mtime": st.st_mtime,
            "updatedAt": datetime.fromtimestamp(st.st_mtime).astimezone().isoformat(timespec="seconds"),
            "data": {**data, "items": items, "next": nxt},
            "doneLocal": [{"id": d.get("id"), "title": (d.get("item") or {}).get("title"),
                           "requester": (d.get("item") or {}).get("requester"), "at": d.get("at")}
                          for d in _local_done()][-20:]}


def mark_done(item_id: str) -> dict:
    """「済み」: done の記録に1件足し、一覧から外す（取り消しの控えを残す）"""
    cfg = load_config()
    if not cfg:
        raise ValueError("Addness の設定がありません")
    with _lock:
        data = _read_json(cfg["todoFile"], None)
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            raise ValueError("やることの一覧が読めません")
        items = data["items"]
        pos = next((i for i, it in enumerate(items) if isinstance(it, dict) and it.get("id") == item_id), None)
        if pos is None:
            raise ValueError("そのやることは一覧にありません（もう済みにしたか、一覧が作り直された可能性）")
        item = items[pos]
        entry = _done_entry(item)
        done = _read_json(cfg["doneFile"], {"items": []})
        if not isinstance(done, dict) or not isinstance(done.get("items", []), list):
            raise ValueError("済みの記録が読めません（書き換えずに止めました）")
        done.setdefault("items", [])
        same = [i for i, e in enumerate(done["items"]) if isinstance(e, dict) and _same_done(entry, e)]
        if not same:
            done["items"].append(entry)
            _write_json(cfg["doneFile"], done)
        elif any(str(done["items"][i].get("comment_id")) != str(entry["comment_id"]) for i in same):
            # 載せ直された依頼をもう一度済みにした: 返信先と時刻を今のものにする（古い返信先のままだと、また出てしまう）
            for i in same:
                done["items"][i] = {**done["items"][i], **entry}
            _write_json(cfg["doneFile"], done)
        data["items"] = items[:pos] + items[pos + 1:]
        _write_json(cfg["todoFile"], data)
        undo = _read_json(_undo_file(), {}) or {}
        rest = [u for u in (undo.get("items") or []) if isinstance(u, dict) and u.get("id") != item_id]
        undo["items"] = (rest + [{"id": item_id, "item": item, "entry": entry, "position": pos, "at": _now()}])[-MAX_UNDO:]
        _write_json(_undo_file(), undo, indent=1)
        return {"ok": True}


def undo_done(item_id: str) -> dict:
    """「元に戻す」: 済みの記録から外し、一覧の元の位置に戻す"""
    cfg = load_config()
    if not cfg:
        raise ValueError("Addness の設定がありません")
    with _lock:
        undo = _read_json(_undo_file(), {}) or {}
        recs = [u for u in (undo.get("items") or []) if isinstance(u, dict)]
        rec = next((u for u in reversed(recs) if u.get("id") == item_id), None)
        if not rec:
            raise ValueError("取り消せる記録がありません")
        done = _read_json(cfg["doneFile"], {"items": []})
        if not isinstance(done, dict):
            raise ValueError("済みの記録が読めません（書き換えずに止めました）")
        before = len(done.get("items") or [])
        done["items"] = [e for e in (done.get("items") or []) if not (isinstance(e, dict) and _same_done(rec.get("entry") or {}, e))]
        if len(done["items"]) != before:
            _write_json(cfg["doneFile"], done)
        data = _read_json(cfg["todoFile"], None)
        if isinstance(data, dict) and isinstance(data.get("items"), list) and isinstance(rec.get("item"), dict):
            items = data["items"]
            ri = rec["item"]
            if not any(isinstance(it, dict) and (it.get("id") == item_id or (it.get("goal_id") == ri.get("goal_id")
                       and it.get("comment_id") == ri.get("comment_id"))) for it in items):
                pos = max(0, min(int(rec.get("position") or 0), len(items)))
                data["items"] = items[:pos] + [rec["item"]] + items[pos:]
                _write_json(cfg["todoFile"], data)
        undo["items"] = [u for u in recs if u is not rec]
        _write_json(_undo_file(), undo, indent=1)
        return {"ok": True}
