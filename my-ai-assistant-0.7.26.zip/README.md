# My AI Assistant（my-ai-assistant プラグイン・試作）

自分の Claude の Code タブの会話を「執行役」にして、ブラウザの画面から頼んだり、部署（企画・調査・プログラマーなど）に仕事を任せたりするプラグインです。

- 画面から文を送ると、いま開いている Claude の会話に入り、執行役が答えます（使用量は自分のプランから引かれます）。
- 執行役は、必要なら部署に仕事を任せます。任せた仕事は画面の仕事一覧に出ます。1つだけ止める・全部止めることもできます。
- `claude -p` を別に動かしません。会話を閉じると、画面も止まります。

## 前提

- Claude Code 2.1.275 以降（Claude アプリの Code タブ、またはターミナルの Claude Code）
- Python 3.8 以上
- （Web 版を使うときだけ）node 22 以降
  - Mac: ターミナルで `xcode-select --install`（すでに入っていれば不要）。python.org の公式インストーラ、または Homebrew（`brew install python`）でもよい
  - Windows: python.org の公式インストーラで入れる（「Add python.exe to PATH」にチェック）。`py` ランチャー（`py -3`）が入っていれば、プラグインが自動で見つける

## 入れる

### 招待なしで入れる（Web に置いた marketplace.json の URL から）

git も GitHub のアカウントも要りません（Claude Code 2.1.224 以降）。Claude Code の中で次の2行を打ちます。置き場所は配布者の GitHub Pages（https://dronekoh.github.io/my-ai-assistant/）です。

```
/plugin marketplace add https://dronekoh.github.io/my-ai-assistant/marketplace.json
/plugin install my-ai-assistant@my-ai-assistant-marketplace
```

ターミナルから直接なら `claude plugin marketplace add https://dronekoh.github.io/my-ai-assistant/marketplace.json` のあと `claude plugin install my-ai-assistant@my-ai-assistant-marketplace` です。入れたら新しい会話を開きます。

### 開発者・招待された人向け（GitHub から入れる）

1. ターミナル、または Claude Code の中で、次の1行を打つ。

   ```
   /plugin install my-ai-assistant --marketplace dronekoh/koh-assistant-plugin
   ```

   ターミナルから直接なら `claude plugin install my-ai-assistant --marketplace dronekoh/koh-assistant-plugin` です。
2. 新しい会話を開く。

### 旧名（koh-assistant）から移る（v0.2.0 で名前が変わりました）

名前が変わったので、`claude plugin update` では移れません。入れ直します。次の順に打ちます。入れ方（`--scope`）は、旧版を入れたときと同じにしてください（下は local の例）。

```
claude plugin uninstall koh-assistant@koh-assistant-marketplace --scope local
claude plugin marketplace remove koh-assistant-marketplace
claude plugin marketplace add dronekoh/koh-assistant-plugin
claude plugin install my-ai-assistant@my-ai-assistant-marketplace
```

入れ直したら、新しい会話を開きます。

- 履歴の索引と添付（`~/.koh-assistant/`）は、新しい版の画面サーバーが最初に起動したとき、`~/.my-ai-assistant/` へ**コピー**されます。元のフォルダは消しません。不要になったら自分で消してください。
- 画面の設定（テーマ・キャラの選択など）は、画面を開いたときに旧い設定から写されます。
- 設定「アシスタント」の保存（表示名・部署の追加など）は引き継がれません。開いて入れ直してください。

GitHub から入れる場合、リポジトリが非公開の間は、そのリポジトリを読める権限が要ります。次のどちらか一方でかまいません。

- `gh auth login` のあとに `gh auth setup-git` を実行する
- SSH 鍵を GitHub に登録する（鍵が無い人は `CLAUDE_CODE_PLUGIN_PREFER_HTTPS=1` を設定する）

## 自動で新しい版にする（おすすめ）

配布者が配る棚（marketplace）は、自動更新が最初は切れています。一度だけ入れます。

1. Claude Code で `/plugin` を開く。
2. Marketplaces → `my-ai-assistant-marketplace` を選ぶ。
3. Enable auto-update を選ぶ。

入れなかった人は、次のどちらかで手で更新します。

```
claude plugin update my-ai-assistant@my-ai-assistant-marketplace
```

または Claude Code の中で `/plugin marketplace update my-ai-assistant-marketplace`。

新しい版は、自動更新を入れた人には次の会話の最初のあと（最大10分ほど）に取り込まれ、「Run /reload-plugins to apply」と出ます。`/reload-plugins` を打つか、次に起動したときから新しい版になります。

- **自動更新の入り切りは、パソコンごとです。** 別のパソコンに入れたら、そのパソコンでも上の3手順をやります（棚の側から最初からオンにする方法は、Claude Code にはありません）。
- `/plugin` の画面を使わずに入れるときは、そのパソコンの `~/.claude/settings.json` に次を足します（`source` は、そのパソコンで棚を足したときの入れ方に合わせます。URL で足したなら下の形、GitHub から足したなら `{ "source": "github", "repo": "dronekoh/koh-assistant-plugin" }`）。

  ```json
  {
    "extraKnownMarketplaces": {
      "my-ai-assistant-marketplace": {
        "source": { "source": "url", "url": "https://dronekoh.github.io/my-ai-assistant/marketplace.json" },
        "autoUpdate": true
      }
    }
  }
  ```
- 環境変数 `DISABLE_AUTOUPDATER=1`（または `DISABLE_UPDATES=1`・`CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1`）が入っていると、自動更新は動かず、`/plugin` に Enable auto-update も出ません。プラグインだけ自動で上げたいときは `FORCE_AUTOUPDATE_PLUGINS=1` を足します。
- Web 版の画面（ブラウザ・スマホ）は、新しい版が置かれると自分で読み直します（開いたとき・画面に戻ったとき・数分おきに確かめる）。書きかけ・添付・送信中のときは読み直さず、下に「新しい版があります（読み直す）」と出ます。画面の右上の版が「パソコンは古い版」と出たら、パソコン側の自動更新を確かめてください。

## 使い方

1. Code タブで新しい会話を開く。
2. 「My AI Assistant」のペインが出る（出ないときは `/my-ai-assistant` と打つ）。
3. ペインの「画面を開く」を押す。ブラウザで http://127.0.0.1:8790/ が開く。
4. 入力欄に頼みを書いて送る。執行役が答えます。ファイルや画像は、ボタン・ドラッグ・貼り付けで添えられます。
5. 部署に任せた仕事は、画面の仕事一覧（☰）で見る。止めたい仕事の「この仕事を止める」、または「全部止める」を押す。

画面から頼むときは、会話にそのまま入れる形（chat モード）が標準です。執行役が自分で判断して部署に任せます。

### 設定（「アシスタント」タブ）

画面の右上の設定 → 「アシスタント」タブで、次を変えられます。保存すると次の発言から使われます。

- 表示名（空にすると既定に戻る）
- 執行役への追加の指示（口調・得意分野など。空にすると何も足さない）
- 部署（追加・削除・編集。「既定の部署に戻す」→ 保存で、プラグインに入っている既定に戻る）

### Web 版（外出先のブラウザやスマホから使う。既定はオフ）

自分のパソコンで開いている Claude Code の会話を、別の場所のブラウザやスマホから使う機能です。画面は Web にあり、頼みごとは自分のパソコンの Claude Code に届いて、自分の Claude の契約で動きます。依頼も答えもブラウザとパソコンの間で暗号化され、間に入る中継（Supabase のプロジェクト）は中身を読めません。**ペアリングしたブラウザだけ**が使えます。

**できること**
- 会話に依頼を送って、答えを見る（3D オフィス・仕事一覧・設定も手元の画面と同じ）
- 仕事を止める（1つだけ・全部）
- 設定を変える（表示名・追加の指示・部署）
- 過去の会話の検索・閲覧（既定はオフ。下の「安全について」）

**前提**
- パソコンに **node 22 以降**（Web 版を使うときだけ。18 や 20 では動きません）
- パソコンで Claude Code の会話が開いていること（閉じると、Web の画面は「つながっていない」になります）
- ブラウザは新しめの Chrome / Edge / Safari / Firefox（スマホの Safari・Chrome も可）

**始め方**（最初の1回）。Web の画面の URL は https://my-migiude.vercel.app/ です（0.5.1 までの https://dronekoh.github.io/my-ai-assistant/app/ から移りました。前の URL で登録したブラウザは、新しい URL でペアリングし直してください）。
1. パソコンの会話の**入力欄**に `/my-ai-assistant web-on` を打つ（ターミナルや「▶ 実行」ではありません）。
2. 続けて `/my-ai-assistant web-pair` を打つ。ペインに12桁の番号が出る（5分で失効・1回きり）。
3. ブラウザで上の URL を開き、12桁の番号を入れて「つなぐ」を押す。
4. ブラウザに6桁が出る。パソコン側の6桁と**必ず見比べる**。
5. 同じなら、パソコンのペインで「一致（登録する）」を押す（`/my-ai-assistant web-ok` でも可）。違えば「違う（登録しない）」（`web-ng`）。

2回目からは番号は要りません。画面の上に「パソコン: つながっている」が出ます。

**パスキーで端末を足す**（2台目から。番号も6桁の見比べも要りません）
1. ペアリングしたブラウザで、つながった直後の「パスキーを作る」か、画面の上の「パソコン:」→「パスキーを作る」を押し、Face ID などで確かめる。
2. 足したい端末で Web の画面を開き、「パスキーでつなぐ」を押して Face ID などで確かめる。同じ Apple ID・Google アカウントの端末ならそのまま、ほかの端末は出てくる QR をスマホで読む。
3. パソコンの Claude Code に「パスキーで端末『…』を登録しました」と通知が出ます。覚えがなければ、通知にある `web-revoke` で取り消してください。

- パスキーは、作った Web の画面の URL でしか使えません（偽のサイトでは使えない）。URL が変わったら、ペアリングからやり直します。
- パスキーで足せるのは1時間に3台までです。`web-list` にパスキーと「パスキーで」足した端末が出て、`web-revoke` でどちらも取り消せます。
- パスキーは Apple ID などのアカウントに保存されます。そのアカウントが乗っ取られると端末を足されうるので、アカウントの2ステップ確認を入れてください。

**やめ方**
- すぐ切る: ペインの「Web をすぐ切る」、または `/my-ai-assistant web-off`。橋渡しを止め、Web から来てまだ会話に入っていない依頼を捨てます。登録したブラウザは残ります。すでに会話に入って動いている依頼は止めないので、止めるなら画面の「止める」か Claude の会話で止めてください。
- 取り消し: `/my-ai-assistant web-list` で一覧を見て、`/my-ai-assistant web-revoke 名前` で消す（同じ名前が複数なら、指紋の先頭8文字で指定）。ブラウザ側は「パソコン:」の表示から「このブラウザの登録を消す」。

**安全について**
- **ペアリングの6桁は必ず見比べてください。** 番号（12桁）は秘密ではなく、守りは6桁の見比べです。違ったら「違う」と答えれば、登録されずに番号も捨てられます。
- 入力欄からの「実行」の依頼を Web で断る仕組みは、表示を整理するためのものです。**守りの本体は Claude Code の権限確認**で、言い換えた依頼（「次の bash を走らせて」など）は通ります。Web から使うときは、権限を自動で許可する設定（bypass や広い許可パターン）を避けてください。
- 過去の会話の履歴は、既定では Web から読めません。読ませるなら `/my-ai-assistant web-history on`、やめるなら `off`。
- Web の画面は専用のドメイン（`my-migiude.vercel.app`）にあり、ほかのサイトとは保存データ（登録の鍵）を分け合いません。ほかのサイトの枠に埋め込まれないようにもしてあります。それでも、使わない端末の登録は取り消してください。
- Web からの操作は、ペインに「Web から操作中」と出て、手元の記録 `~/.my-ai-assistant/web/log.jsonl` に残ります（時刻・ブラウザ名・操作の種類・大きさ。依頼の本文は書きません）。

**Web から、パソコンで動かせること（守りつき）**
- Finder で表示: 会話に出たファイル・書類だけ。置き場所を見せるだけで、ファイルは開きません。
- パソコンで開く: 会話に出たファイルを、パソコンのアプリで開きます。開けるのは PDF・Excel（.xlsx .xls）・Word（.docx .doc）・PowerPoint（.pptx）・.csv .txt .md・画像（.png .jpg .jpeg）だけです。マクロ付き（.xlsm など）・実行できる形（.app .command .sh .pkg .dmg）・.html .svg・.zip・拡張子の無いものは、Web からは開きません（リンクは実体の拡張子で見ます）。今までどおり「開く」（ファイルを受け取ってこのブラウザで開く）も使えます。
- 送り直し: 会話に届かなかった発言（お知らせに「同じ発言をもう一度送る」が出ます）を、もう一度送ります。Web から渡すのは発言の id だけで、送るのはパソコンに残っている元の発言そのままです（中身は変えられません）。送信と同じ決まり（先頭が `/` `!` `#` の発言・「実行」の依頼は断る）を通り、1つの発言につき1回だけです。
- 「▶ 実行」: 押すと、パソコンの会話に「次のコマンドを実行してください」の依頼が入ります（前に「Web から ▶ 実行 が押されました」の印が付きます）。Web から渡すのは執行役の発言の id と何番目のブロックかだけで、コマンドの文はパソコンが会話から取り出します。その場では実行しません。実行は会話の Claude の Bash で、**パソコン側のいつもの許可の確認**（Claude アプリの確認の画面）を通ります。確認には Web からは答えられません。許可を自動で出す道・確認を外す道はありません。権限を自動で許可する設定（bypass や広い許可パターン）にしていると、確認の画面が出ずに動くので、Web から使うときは避けてください。
- チャットを開く: パソコンの Claude アプリで、その会話を開きます。Web から渡せるのは会話の id（`local_…`）だけで、アプリのフォルダに実在する会話に限ります。

**Web からできないこと**
- 入力欄に「次のコマンドを実行してください」と打って送ること（▶ 実行のボタンを使います）
- 先頭が `/` `!` `#`（全角も）の依頼
- 添付は5件・合計 約640KBまで（Web からは1日あたり合計50MBまで）

置き方・作り方は `docs/release.md` の「4c」、設計は `docs/web-plan.md` です。

### Addness のやること（Addness を使う人向け。既定は出ない）

Addness のやることの一覧を、画面の「Addness」タブに出します。Web 版とスマホからも使えます。
- 出し方: `config/addness.example.json` を、データ置き場（ふつうは `~/.my-ai-assistant`）に `addness.json` という名前で写し、中身を自分用に直します。このファイルが無い人には、タブは出ません。
- 一覧（`todoFile`）は、定期タスクなどが書く JSON です。画面は読んで並べるだけです。
- 「済み」を押すと、済みの記録（`doneFile`）に残して一覧から外します。「元に戻す」で戻せます。
- 組織・メンバー・ゴールの ID や人の名前は、自分の `addness.json` と一覧のファイルにだけあります。プラグインには入りません。
- 相談チャット・下書きの投稿・「今すぐ更新」は、これから足します（`docs/addness-plan.md`）。

### 「使うフォルダ」を足す

執行役や部署が、いまの作業フォルダの外のフォルダも読み書きするには、Claude Code 側で足します。プラグインからは足せません。

- 会話の中で `/add-dir <フォルダのパス>` を打つ。
- ターミナルから起動するときは `claude --add-dir <フォルダのパス>` を付ける。

## データと安全

- 画面は 127.0.0.1 だけで待ち受けます。同じネットワークの別の機械からは届きません。
- 履歴検索の索引と添付ファイルは、自分の PC の `~/.my-ai-assistant/`（Windows はホームフォルダの `.my-ai-assistant`）に置きます。外には送りません。
- 画面の「▶ 実行」は、その場でコマンドを実行しません。「次を実行して」という頼みを会話に入れ、Claude 側の確認（Bash の許可）を通して実行します。
- 許可を自動で出す仕組みはありません。確認は Claude 側の画面に出ます。

## できないこと

- 会話の分岐（`< 1/2 >`）。やり直したいときは Claude アプリの巻き戻し（ターミナルでは Esc を2回）を使う。画面の「編集」は、下書きを入力欄に戻すだけです。
- 画面から許可を出すこと。許可は Claude 側の確認で出す。画面は「Claude 側で確認待ちかもしれません」と知らせるだけです。
- ほかの会話の一覧（Code タブの会話・Cowork・定期タスク）を出すこと。

## よくある詰まり

- **Python が無い**: ペインに python.org の案内が出る。上の「前提」のとおり入れて、新しい会話を開き直す。
- **8790 を別のプログラムが使っている**: ペインにエラーが出る。そのプログラムを止めて、新しい会話を開き直す。
- **別の会話が画面を持っている**: ペインに「別のセッションがすでに 8790 で画面を出しています」と出る。同じ画面を使えます（頼みは、画面を持つ会話に入る）。持っている会話を閉じると、このセッションが引き継ぎます。
- **古い版の会話が残っている**: 更新したあと、開いたままの古い会話は数秒で新しい版に切り替わる。切り替わらなければ `/reload-plugins` を打つか、会話を開き直す。

## 開発者向け

自分の PC で、入れずに試す。

```
claude --plugin-dir <このフォルダのパス>
```

その会話の間だけ有効で、普段の設定には何も残りません。

テストと確認（このフォルダで実行）:

```
claude plugin validate .
claude plugin test .
npx -y -p typescript tsc --noEmit -p .
python3 tests/check_server.py 8791
node tests/bridge.test.mjs        # Web 版の橋渡し（本物の Supabase の Broadcast を使う。node 22 以降が要る）
node tests/web.test.mjs           # Web の画面（dist/web を build し、ペアリングから依頼まで通す。8791・8802 を使う）
node tests/passkey.test.mjs       # パスキーで端末を足す（偽のパスキーで、作る・つなぐ・断るものを確かめる。本物の Supabase の Broadcast を使う）
```

- `claude plugin test .` と `tsc` には、`.claude-plugin/types`（Claude Code の型定義）が要ります。無いときは、型定義のあるフォルダへのリンクを張ります（`ln -s <型定義のフォルダ> .claude-plugin/types`）。`.gitignore` に入っているので commit されません。
- `tests/check_server.py` は別ポート（8791）でサーバーを起動して確かめます。8790 と 8787 は使いません。
- 版を上げる手順は `docs/release.md`、もう1台の PC での確認表は `docs/checklist.md` を見る。

## 中身

```
.claude-plugin/plugin.json       プラグインの名前と版（version）
.claude-plugin/marketplace.json  配布用の棚（このリポジトリ自体が棚になる）
hooks/hooks.json                 本体の場所
hooks/register.tsx               本体（サーバーの起動・依頼の受け渡し・ペイン・部署）
config/org.json                  部署と表示名の既定
server/server.py                 画面のサーバー（Python 標準ライブラリだけ・127.0.0.1:8790）
server/index.html                画面
server/history.py                履歴検索
bridge/                          Web 版の橋渡し（node。暗号化・ペアリング・許可リスト）
web/                             Web の画面の追加部分（ペアリング画面・中継の窓口・つながりの表示）。画面本体は server/index.html から作る
web-proto/lib/                   暗号と中継の部品（ブラウザと node で共通）
config/web.json                  Web 版の中継の接続設定（Supabase の URL と公開用キー）
tests/                           自動テスト
scripts/build_release.py         Web に置く版（zip と marketplace.json）を dist/ に作る
scripts/build_web.py             Web の画面（静的ファイル）を dist/web/ に作る
docs/                            手順書と確認表
```
