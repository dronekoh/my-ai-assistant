"""関所・過去の会話の MCP サーバー（標準入出力・JSON-RPC）の共通部分。依存はなし（標準ライブラリのみ）"""
from __future__ import annotations

import json
import sys


def reply(mid, result=None, error=None):
    msg = {"jsonrpc": "2.0", "id": mid}
    if error is not None:
        msg["error"] = error
    else:
        msg["result"] = result
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def serve(name: str, tools: list[dict], call) -> None:
    """tools/call は call(道具の名前, 引数) → 文 で答える"""
    for stream in (sys.stdin, sys.stdout):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    names = {t["name"] for t in tools}
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(msg, dict):
            continue
        method, mid = msg.get("method"), msg.get("id")
        if mid is None:
            continue
        if method == "initialize":
            ver = (msg.get("params") or {}).get("protocolVersion") or "2024-11-05"
            reply(mid, {"protocolVersion": ver, "capabilities": {"tools": {}}, "serverInfo": {"name": name, "version": "1.0"}})
        elif method == "tools/list":
            reply(mid, {"tools": tools})
        elif method == "tools/call":
            p = msg.get("params") or {}
            if p.get("name") not in names:
                reply(mid, error={"code": -32602, "message": "unknown tool"})
                continue
            args = p.get("arguments") if isinstance(p.get("arguments"), dict) else {}
            reply(mid, {"content": [{"type": "text", "text": call(p["name"], args)}]})
        elif method == "ping":
            reply(mid, {})
        else:
            reply(mid, error={"code": -32601, "message": f"method not found: {method}"})
