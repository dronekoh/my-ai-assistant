#!/usr/bin/env python3
"""Addness 投稿の関所（MCP サーバー・標準入出力）。以前の手元の版の関所と同じ決まり。

「送信OK」で起動する投稿係（claude -p）に --permission-prompt-tool として渡す。
投稿係が道具を使おうとすると Claude Code 本体がこの関所の `check` を呼び、ここが許可した時だけ実行される。

- 許可するのは mcp__addness__add_comment だけ。しかも利用者が承認した下書きと
  ゴール・返信先・本文・宛先が一字一句同じ時に限り、1回だけ。
- それ以外の道具・中身の違う投稿・2回目の投稿はすべて却下する。
- ドライラン（spec の mode が "dry"）のときは、中身が合っていても却下し、
  「投稿する予定だった内容」を記録だけする（実際には何も投稿されない）。
- 判断はすべて log（jsonl）に残す。サーバーはそれを見て、投稿されたかどうかを決める。

環境変数: MYAI_GUARD_SPEC（承認された投稿の JSON ファイルのパス）
"""
from __future__ import annotations

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _mcp_stdio import serve  # noqa: E402

SPEC_PATH = os.environ.get("MYAI_GUARD_SPEC", "")
POST_TOOL = "mcp__addness__add_comment"


def _spec() -> dict:
    with open(SPEC_PATH, encoding="utf-8") as f:
        return json.load(f)


def _log(spec: dict, entry: dict):
    entry = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **entry}
    with open(spec["log"], "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _allowed_before(spec: dict) -> bool:
    """この下書きで、すでに投稿を許可したことがあるか（2回目は通さない）"""
    try:
        with open(spec["log"], encoding="utf-8") as f:
            for line in f:
                try:
                    if json.loads(line).get("decision") == "allow":
                        return True
                except ValueError:
                    continue
    except FileNotFoundError:
        pass
    return False


def _ids(s) -> list[str]:
    return sorted(x.strip().lower() for x in str(s or "").split(",") if x.strip())


def _diff(expected: dict, got: dict) -> list[str]:
    """承認された投稿と違うところ（日本語で）。空なら同じ"""
    bad = []
    if str(got.get("goal_id") or "").lower() != str(expected.get("goal_id") or "").lower():
        bad.append("ゴールが承認されたものと違う")
    if str(got.get("parent_id") or "").lower() != str(expected.get("parent_id") or "").lower():
        bad.append("返信先のコメントが承認されたものと違う")
    # 本文は一字一句同じであること（末尾の改行だけは見ない）
    if str(got.get("content") or "").rstrip("\n") != str(expected.get("content") or "").rstrip("\n"):
        bad.append("本文が承認されたものと違う（一字も変えずに使うこと）")
    if _ids(got.get("mentions")) != _ids(expected.get("mentions")):
        bad.append("宛先（mentions）が承認されたものと違う")
    if got.get("template_node_id") or got.get("mentioned_tag_ids"):
        bad.append("承認されていない項目（template_node_id / mentioned_tag_ids）がある")
    return bad


def decide(tool_name: str, tool_input: dict) -> dict:
    try:
        spec = _spec()
    except (OSError, ValueError) as e:
        return {"behavior": "deny", "message": f"関所の設定が読めないため実行しない: {e}"}
    if tool_name != POST_TOOL:
        _log(spec, {"decision": "deny", "tool": tool_name, "reason": "投稿以外の道具"})
        return {"behavior": "deny", "message": f"{tool_name} は使えない。使えるのは add_comment（承認された下書きの投稿）だけ"}
    expected = spec.get("input") or {}
    bad = _diff(expected, tool_input or {})
    if bad:
        _log(spec, {"decision": "deny", "tool": tool_name, "reason": "／".join(bad), "input": tool_input})
        return {"behavior": "deny", "message": "承認された下書きと違うため投稿しない: " + "／".join(bad)}
    if _allowed_before(spec):
        _log(spec, {"decision": "deny", "tool": tool_name, "reason": "2回目の投稿", "input": tool_input})
        return {"behavior": "deny", "message": "この下書きはもう投稿を通した。2回目は投稿しない。結果を報告して終わること"}
    if spec.get("mode") == "dry":
        _log(spec, {"decision": "dry", "tool": tool_name, "input": tool_input})
        return {"behavior": "deny", "message": "ドライラン：投稿はしていない（投稿する予定の内容は記録した）。"
                                                "これ以上は何もせず、{\"ok\": true, \"dry_run\": true, \"comment_id\": null} を出力して終わること"}
    _log(spec, {"decision": "allow", "tool": tool_name, "input": tool_input})
    return {"behavior": "allow", "updatedInput": tool_input}


TOOL = {
    "name": "check",
    "description": "Addness への投稿が、利用者が承認した下書きと同じかを確かめる関所",
    "inputSchema": {"type": "object",
                    "properties": {"tool_name": {"type": "string"}, "input": {"type": "object"}, "tool_use_id": {"type": "string"}},
                    "required": ["tool_name", "input"]},
}


def _call(_name: str, args: dict) -> str:
    return json.dumps(decide(str(args.get("tool_name") or ""), args.get("input") or {}), ensure_ascii=False)


if __name__ == "__main__":
    serve("myai_post_guard", [TOOL], _call)
