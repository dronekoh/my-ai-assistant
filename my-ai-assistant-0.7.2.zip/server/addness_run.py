"""Addness の「今すぐ更新」・相談・送信OK で、別の Claude（claude -p）を起動する部分。

以前の手元の版と同じやり方: 画面サーバーが仕事ごとに claude -p を起動し、使える道具を決めて渡す。
- 開いている会話（自動モード）の外で動くので、自動モードの安全確認には止められない
- 使える道具は --allowedTools / --disallowedTools で決める。確認が要る操作は関所（--permission-prompt-tool）が決める
  - 今すぐ更新: addness_refresh_guard.py（決まったファイルへの書き込みだけ通す）
  - 送信OK:     addness_post_guard.py（承認した下書きと一字一句同じ投稿を1回だけ通す。ドライランは止めて記録だけ）
- 起動した claude では、このプラグインを切る（--settings で enabledPlugins を false。画面サーバーを二重に起こさない）
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLUGIN_KEY = "my-ai-assistant@my-ai-assistant-marketplace"
REFRESH_GUARD = HERE / "addness_refresh_guard.py"
POST_GUARD = HERE / "addness_post_guard.py"
HISTORY_MCP = HERE / "history_mcp.py"

# Addness を読む道具（相談役・更新係が使える）
ADDNESS_READ = [f"mcp__addness__{x}" for x in (
    "list_comments", "get_goal", "read_goal_detail", "get_goal_context", "list_goal_memories", "search_goals",
    "get_goal_tree", "list_todays_goals", "read_chat_messages", "list_chat_rooms", "list_notifications",
    "list_members", "get_member_profile", "search_knowledge", "get_knowledge", "read_comment_attachment",
    "list_organizations", "get_activity", "list_assignments", "list_deliverables", "get_deliverable",
    "search_drive", "get_drive_resource", "get_drive_tree", "man")]
SWITCH = "mcp__addness__switch_organization"
POST = "mcp__addness__add_comment"
# 書き込み・送信・状態を変える Addness の道具（設定で許可されていても、ここに書いたものは必ず止める）
ADDNESS_WRITE = [f"mcp__addness__{x}" for x in (
    "add_comment", "update_comment", "delete_comment", "resolve_comment", "switch_organization",
    "send_chat_message", "edit_chat_message", "delete_chat_message", "send_agent_message", "send_agent_image",
    "create_goal", "update_goal", "complete_goal", "delete_goal", "move_goal", "restore_goal", "edit_goal_detail",
    "write_goal_detail", "append_goal_memory", "revoke_goal_memory", "assign_member", "unassign_member",
    "mark_notifications_read", "mark_request_received", "write_knowledge", "link_knowledge", "create_today_todo",
    "update_today_todo", "delete_today_todo", "create_chat_group", "invite_chat_group_members", "change_owner",
    "transfer_owner", "set_permission", "share_resource", "update_member", "remove_member", "update_visibility",
    "create_network_reply", "delete_network_reply", "execute", "create_file_upload", "complete_file_upload",
    "create_drive_resource", "trash_drive_resource", "move_drive_resource", "create_deliverable",
    "update_deliverable", "delete_deliverable", "report_goal_agent_activity", "report_product_feedback",
    "record_crm_activities", "upsert_crm_customers", "set_tags", "link_to_goal", "unlink_from_goal",
    "add_reaction", "delete_knowledge", "delete_database_records", "upsert_database_records")]
BASE_DENY = ["Bash", "Edit", "Write", "MultiEdit", "NotebookEdit", "Agent", "Task", "Monitor", "AskUserQuestion",
             "WebFetch", "TaskStop", "TaskOutput", "Skill"]
HISTORY_TOOLS = ["mcp__myai_history__search_history", "mcp__myai_history__read_session", "mcp__myai_history__list_memory"]


def claude_bin() -> str | None:
    """claude コマンドの場所（MYAI_CLAUDE_BIN → PATH → よくある置き場所）。見つからなければ None"""
    home = Path.home()
    cands = [os.environ.get("MYAI_CLAUDE_BIN"), shutil.which("claude"),
             home / ".local/bin/claude", home / ".claude/local/claude", "/opt/homebrew/bin/claude", "/usr/local/bin/claude",
             home / ".local/bin/claude.exe", home / "AppData/Roaming/npm/claude.cmd"]
    for c in cands:
        if c and Path(c).is_file() and os.access(str(c), os.X_OK):
            return str(c)
    return None


def need_claude() -> str:
    b = claude_bin()
    if not b:
        raise ValueError("claude コマンドが見つかりません（Claude Code を入れるか、MYAI_CLAUDE_BIN に場所を書いてください）")
    return b


def child_env() -> dict:
    """起動する claude に渡す環境変数（この会話の印・プラグインの合言葉は渡さない）"""
    drop = ("CLAUDECODE", "CLAUDE_CODE_ENTRYPOINT", "MYAI_BRIDGE_TOKEN", "MYAI_WEB_ORIGIN_KEY", "MYAI_WEB_CTL_TOKEN")
    return {k: v for k, v in os.environ.items() if k not in drop}


def no_plugin() -> list[str]:
    """起動する claude でこのプラグインを切る"""
    return ["--settings", json.dumps({"enabledPlugins": {PLUGIN_KEY: False}})]


def history_server(db: Path) -> dict:
    """過去の会話を読む MCP（history_mcp.py・読むだけ）"""
    return {"command": sys.executable, "args": [str(HISTORY_MCP)], "env": {"MYAI_HISTORY_DB": str(db)}}


def guard_server(script: Path, env: dict) -> dict:
    return {"command": sys.executable, "args": [str(script)], "env": env}


def rule_path(p: Path) -> str:
    """許可ルールに書く絶対パス（// で始める）"""
    s = str(p).replace("\\", "/")
    return "/" + s if s.startswith("/") else "//" + s


def tool_line(b: dict) -> str:
    """道具の呼び出しを、画面に出す1行にする"""
    name = str(b.get("name") or "")
    inp = b.get("input") if isinstance(b.get("input"), dict) else {}
    short = name.replace("mcp__addness__", "Addness: ").replace("mcp__myai_history__", "過去の会話: ")
    detail = inp.get("query") or inp.get("goal_id") or inp.get("file_path") or inp.get("pattern") or inp.get("organization_id") or ""
    return f"{short} {str(detail)[:60]}".strip()


def tool_result_text(c: dict) -> str:
    txt = c.get("content")
    if isinstance(txt, list):
        txt = "\n".join(x.get("text", "") for x in txt if isinstance(x, dict))
    return str(txt or "")


class Run:
    """claude -p を1つ動かす。stream-json を1行ずつ on_event に渡し、終わったら result（最後の結果）を持つ"""

    def __init__(self, cmd: list[str], prompt: str, cwd: Path, timeout: int, log: Path | None = None):
        self.cmd, self.prompt, self.cwd, self.timeout, self.log = cmd, prompt, cwd, timeout, log
        self.proc: subprocess.Popen | None = None
        self.result: dict = {}
        self.err = ""
        self.killed = ""   # 止めた理由（止めるボタン・道具を断られた など）
        self.lines: list[str] = []

    def kill(self, why: str) -> None:
        if not self.killed:
            self.killed = why
        p = self.proc
        if p and p.poll() is None:
            try:
                p.kill()
            except OSError:
                pass

    def run(self, on_event=None) -> "Run":
        try:
            Path(self.cwd).mkdir(parents=True, exist_ok=True)
            self.proc = subprocess.Popen(self.cmd, cwd=str(self.cwd), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", env=child_env())
        except OSError as e:
            self.err = f"AI を起動できませんでした: {e}"
            return self
        proc = self.proc

        def feed():
            try:
                proc.stdin.write(self.prompt)
                proc.stdin.close()
            except OSError:
                pass

        def read_out():
            for line in proc.stdout:
                self.lines.append(line)
                try:
                    ev = json.loads(line)
                except ValueError:
                    continue
                if not isinstance(ev, dict):
                    continue
                if ev.get("type") == "result":
                    self.result = ev
                if on_event:
                    try:
                        on_event(ev, self)
                    except Exception:   # 表示用の処理の失敗で、動いている claude を止めない
                        pass

        errs: list[str] = []
        threads = [threading.Thread(target=feed, daemon=True), threading.Thread(target=read_out, daemon=True),
                   threading.Thread(target=lambda: errs.append(proc.stderr.read()), daemon=True)]
        for t in threads:
            t.start()
        try:
            proc.wait(timeout=self.timeout)
        except subprocess.TimeoutExpired:
            self.kill(f"{self.timeout // 60}分で打ち切りました")
            proc.wait()
        for t in threads:
            t.join(10)
        stderr = "".join(errs)
        if self.log:
            try:
                self.log.parent.mkdir(parents=True, exist_ok=True)
                self.log.write_text(f"[exit {proc.returncode}]\n{''.join(self.lines)}\n--- stderr\n{stderr}", encoding="utf-8")
            except OSError:
                pass
        self.stderr = stderr
        if self.killed:
            self.err = self.killed
        elif not self.result:
            tail = stderr.strip()[-300:]
            self.err = f"AI が止まりました（終了コード {proc.returncode}）{(' ' + tail) if tail else ''}"
        return self

    def error(self, max_turns: int) -> str:
        """失敗の理由（成功なら空）"""
        if self.err:
            return self.err
        if self.result.get("is_error"):
            sub = str(self.result.get("subtype") or "")
            if sub == "error_max_turns":
                return f"手数の上限（{max_turns}回）に達して止まりました"
            return f"AI の返事でエラー：{str(self.result.get('result') or sub)[:300]}"
        return ""

    def denials(self) -> list[str]:
        """断られた道具の名前（result の permission_denials）"""
        out = []
        for d in self.result.get("permission_denials") or []:
            if isinstance(d, dict) and d.get("tool_name"):
                out.append(str(d["tool_name"]))
        return out


def switch_org(org_id: str, cwd: Path, log: Path | None = None) -> bool:
    """組織を切り替えるだけの claude -p（更新係・投稿係が戻し忘れたとき）。戻せたら True"""
    try:
        b = need_claude()
    except ValueError:
        return False
    cmd = [b, "-p", "--output-format", "json", "--permission-mode", "dontAsk",
           "--allowedTools", SWITCH, "--disallowedTools", *BASE_DENY, *[x for x in ADDNESS_WRITE if x != SWITCH],
           "--max-turns", "3", "--model", "sonnet", "--effort", "low", *no_plugin()]
    prompt = f'{SWITCH} を organization_id "{org_id}" で1回呼び、結果を一言で返す。'
    try:
        Path(cwd).mkdir(parents=True, exist_ok=True)
        r = subprocess.run(cmd, input=prompt, cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=120, env=child_env())
    except (OSError, subprocess.SubprocessError):
        return False
    if log:
        try:
            log.write_text(f"[exit {r.returncode}]\n{r.stdout}\n--- stderr\n{r.stderr}", encoding="utf-8")
        except OSError:
            pass
    try:
        res = json.loads(r.stdout)
    except ValueError:
        res = {}
    denied = any(isinstance(d, dict) and d.get("tool_name") == SWITCH for d in res.get("permission_denials") or [])
    return r.returncode == 0 and not res.get("is_error") and not denied and org_id in (r.stdout or "")
