// Claude アプリの一覧（A5）: Code タブの会話・Cowork・定期タスク。GET /api/apps を読んで、左に一覧・右に中身を出す。
// 画面本体（index.html）の部品を使う: F・esc・cut・hhmm・ago・mdPlain・mdBlocks・COLORS・LABEL・stt・taskDetailHtml・promptOpen。
// 読むだけ（アプリのファイルは書かない）。Web では会話の本文・手順・ファイルの場所は来ない（サーバーと中継が外す）。
(function(){
  const css=`
.apv{display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap}
.apv-side{flex:1 1 380px;min-width:0;max-width:560px;display:flex;flex-direction:column;gap:8px}
.apv-main{flex:2 1 420px;min-width:0;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:9px;box-shadow:var(--shadow)}
.apv-head{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;font:700 14px 'M PLUS Rounded 1c',sans-serif}
.apv-filter{display:flex;gap:6px;flex-wrap:wrap}
.apv-filter button{border:1px solid var(--line);background:var(--card);color:inherit;border-radius:999px;padding:4px 12px;font:700 12px 'Noto Sans JP',sans-serif;cursor:pointer}
.apv-filter button.on{background:#3b4a6b;border-color:#3b4a6b;color:#fff}
.apv-grp{font:700 11px 'JetBrains Mono',monospace;color:var(--mute2);letter-spacing:.1em;margin:10px 2px 2px}
.apv-row{display:flex;gap:10px;align-items:center;width:100%;text-align:left;border:1px solid var(--line);background:var(--card);color:inherit;border-radius:12px;padding:8px 10px;cursor:pointer;font-family:inherit;min-width:0}
.apv-row:hover{background:var(--bg2)}
.apv-row.sel{outline:2px solid var(--done);outline-offset:-1px}
.apv-row i{width:9px;height:9px;border-radius:50%;flex-shrink:0}
.apv-row .tx{min-width:0;flex:1}
.apv-row .t{font-size:13.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.apv-row .s{font-size:12px;color:var(--mute);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.apv-row .s.w{color:#b26a00}
.apv-row .r{display:flex;flex-direction:column;align-items:flex-end;gap:3px;flex-shrink:0}
.apv-tag{font:11px 'JetBrains Mono',monospace;color:var(--mute);background:var(--bg2);border:1px solid var(--line);border-radius:999px;padding:1px 8px;white-space:nowrap}
.apv-made{font:700 10px 'Noto Sans JP',sans-serif;color:var(--mute);border:1px solid var(--line);border-radius:6px;padding:0 5px;margin-left:6px;vertical-align:1px}
.apv-badge{display:inline-block;min-width:18px;padding:0 5px;margin-left:6px;border-radius:999px;background:var(--waiting);color:#fff;font:700 11px/18px 'Noto Sans JP',sans-serif;text-align:center}
.apv-main h2{margin:0;font:800 16px 'M PLUS Rounded 1c',sans-serif;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.apv-main .stt{font:700 11px 'Noto Sans JP';padding:3px 10px;border-radius:999px;color:#fff;white-space:nowrap}
html[data-theme=dark] .apv-row .s.w{color:#f1d58e}
html[data-theme=dark] .apv-filter button.on{background:#e6e5e1;border-color:#e6e5e1;color:#151515}
@media (max-width:720px){.apv-side,.apv-main{flex-basis:100%;max-width:none}}`;
  const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

  const web=!!window.WebRelay;
  const SRCL={code:'Code',cowork:'Cowork'};
  const WSRC={rule:'返事の言い回しから',model:'返事を要約',fallback:'返事の最後の段落'};
  const A={data:null,sel:null,filter:'all',busy:false,err:'',lastHtml:'',lastSide:''};
  const el=id=>document.getElementById(id);
  const visible=()=>{const v=el('appsView');return !!v&&!v.hidden};

  function sub(s){
    if(s.status==='waiting')return {cls:' w',text:s.ask?`質問：${mdPlain(s.ask)}`:(s.waitFor?`待っていること：${s.waitFor}`:'返事を待っています')};
    if(s.status==='working')return {cls:'',text:s.lastTool?`いま：${s.lastTool}`:'作業中'};
    return {cls:'',text:mdPlain(s.recap||s.lastText||'')};
  }
  function rowS(s){
    const x=sub(s);
    return `<button type="button" class="apv-row${A.sel==='s:'+s.id?' sel':''}" data-apsel="s:${esc(s.id)}"><i style="background:${COLORS[s.status]}"></i>
<span class="tx"><div class="t">${esc(s.title)}${s.titleMade?'<span class="apv-made" title="題名が無いので、最初の依頼から作りました">要約</span>':''}</div><div class="s${x.cls}">${esc(cut(String(x.text).replace(/\s+/g,' '),90))}</div></span>
<span class="r"><span class="apv-tag">${esc(SRCL[s.source]||s.source)}</span><span class="k" style="color:${COLORS[s.status]};font-weight:700">${LABEL[s.status]} · ${ago(s.lastActivityAt)}</span></span></button>`;
  }
  function rowT(t){
    const [c,l]=TSTATE[t.state]||['off',t.stateLabel||'不明'];
    const last=t.lastRun?`前回 ${dayHm(t.lastRun.at)} ${t.lastRun.status}`:'まだ実行なし';
    return `<button type="button" class="apv-row${A.sel==='t:'+t.id?' sel':''}" data-apsel="t:${esc(t.id)}"><i style="background:${c==='on'?COLORS.working:COLORS.idle}"></i>
<span class="tx"><div class="t">${esc(t.name)}</div><div class="s${t.missed?' w':''}">${esc(t.repeat||'')}・${esc(last)}${t.missed?`・抜けた回 ${t.missed}`:''}</div></span>
<span class="r"><span class="apv-tag">${esc(l)}</span><span class="k">${t.nextRunAt?'次回 '+esc(dayHm(t.nextRunAt)):''}</span></span></button>`;
  }
  function side(){
    const d=A.data||{};const ss=(d.sessions||[]).filter(s=>A.filter==='all'||A.filter===s.source);const ts=d.tasks||[];
    const c=d.counts||{};
    let h=`<div class="apv-head"><b>Claude アプリ</b><span class="k">${d.generatedAt?'更新 '+esc(hhmm(d.generatedAt)):''}${A.err?' ・'+esc(A.err):''}</span></div>`;
    h+=`<div class="apv-filter">${[['all','すべて'],['code','Code タブ'],['cowork','Cowork'],['task',`定期タスク ${ts.length}`]].map(([k,l])=>`<button type="button" data-apf="${k}" class="${A.filter===k?'on':''}">${esc(l)}</button>`).join('')}</div>`;
    if(A.filter!=='task'){
      const g=(label,list)=>list.length?`<div class="apv-grp">${esc(label)}（${list.length}）</div>`+list.map(rowS).join(''):'';
      h+=g('返答待ち',ss.filter(s=>s.status==='waiting'))+g('作業中',ss.filter(s=>s.status==='working'))+g('24時間以内に動いたもの',ss.filter(s=>s.status==='done'||s.status==='idle'));
      if(!ss.length)h+=`<div class="empty">24時間以内に動いた会話はありません。</div>`;
    }
    if(A.filter==='all'||A.filter==='task'){
      h+=`<div class="apv-grp">定期タスク（${ts.length}${c.missed?`・抜けた回 ${c.missed}`:''}）</div>`+(ts.length?ts.map(rowT).join(''):`<div class="empty">定期タスクはありません。</div>`);
    }
    return h;
  }
  function detailS(s){
    const r=[];
    r.push(`<h2>${esc(s.title)}${stt(s.status)}</h2>`);
    if(s.titleMade)r.push(`<div class="k">題名が無い会話なので、最初の依頼から題名を作りました</div>`);
    r.push(`<div class="k">種別</div><div class="v">${esc(SRCL[s.source]||s.source)}${s.model?` · ${esc(s.model)}`:''}${s.pr?` · PR #${esc(s.pr)}`:''}</div>`);
    if(s.ask)r.push(`<div class="k">あなたへの質問</div><div class="ask">${mdBlocks(s.ask)}</div>`);
    else if(s.status==='waiting'&&s.waitFor)r.push(`<div class="k">待っていること<span class="k">（${esc(WSRC[s.waitSource]||'')}）</span></div><div class="ask">${esc(s.waitFor)}</div>`);
    if(s.recap)r.push(`<div class="k">直近の報告</div><div class="v">${mdBlocks(s.recap)}</div>`);
    else if(s.lastText)r.push(`<div class="k">直近の発言</div><div class="v">${mdBlocks(s.lastText)}</div>`);
    if(s.lastTool)r.push(`<div class="k">最後に使った道具</div><div class="v mono">${esc(s.lastTool)}</div>`);
    if(s.cwd)r.push(`<div class="k">作業フォルダ</div><div class="v mono">${esc(s.cwd)}</div>`);
    if(s.lastActivityAt)r.push(`<div class="k">最終更新</div><div class="v">${hhmm(s.lastActivityAt)}（${ago(s.lastActivityAt)}）</div>`);
    if(s.link&&!web)r.push(`<a class="open" href="${esc(s.link)}">Claude で開く →</a>`);
    return r.join('');
  }
  function detailT(t){
    return `<h2>${esc(t.name)}<span class="apv-tag">${t.source==='cowork'?'Cowork':'Code'}</span></h2>`+taskDetailHtml('ap:'+t.id,t);
  }
  function main(){
    const d=A.data||{};
    const [k,id]=(A.sel||'').split(/:(.*)/s);
    if(k==='s'){const s=(d.sessions||[]).find(x=>x.id===id);if(s)return detailS(s)}
    if(k==='t'){const t=(d.tasks||[]).find(x=>x.id===id);if(t)return detailT(t)}
    return `<h2>左の一覧から選ぶ</h2><div class="empty">Claude アプリ（Code タブ・Cowork）の会話と、定期タスクの中身がここに出ます。読むだけです（アプリの設定は変えません）。</div>`;
  }
  function paint(){
    if(!el('apvSide'))return;
    const hs=side(),hm=main();
    if(hs!==A.lastSide){const b=el('apvSide'),top=b.scrollTop;b.innerHTML=hs;A.lastSide=hs;b.scrollTop=top}
    if(hm!==A.lastHtml){el('apvMain').innerHTML=hm;A.lastHtml=hm}
  }
  function badge(){
    const b=document.querySelector('.vbtn[data-view="apps"]');if(!b)return;
    const n=((A.data||{}).counts||{}).waiting||0;
    b.innerHTML=`Claude アプリ${n?`<span class="apv-badge" title="返事を待っている会話">${n}</span>`:''}`;
  }
  async function load(){
    if(A.busy||typeof F!=='function'||!F('apps'))return;
    A.busy=true;
    try{const r=await fetch('/api/apps');const j=await r.json();if(!r.ok)throw new Error(j&&j.error||('HTTP '+r.status));A.data=j;A.err=''}
    catch(e){A.err='読めませんでした: '+e.message}
    finally{A.busy=false}
    badge();if(visible())paint();
  }
  // 見ているときは 5 秒（Web は 15 秒）ごと、見ていないときは返答待ちの数だけ 60 秒ごとに取り直す
  let n=0;
  setInterval(()=>{n++;if(visible()?(n%(web?3:1)===0):(n%12===0))load()},5000);
  setTimeout(load,1500);

  document.addEventListener('click',e=>{
    if(!visible())return;
    const f=e.target.closest('[data-apf]');if(f){A.filter=f.dataset.apf;paint();return}
    const s=e.target.closest('[data-apsel]');if(s){A.sel=s.dataset.apsel;paint()}
  });
  document.addEventListener('toggle',e=>{const d=e.target;if(d.tagName==='DETAILS'&&d.dataset&&d.dataset.prompt&&el('apvMain')&&el('apvMain').contains(d)){d.open?promptOpen.add(d.dataset.prompt):promptOpen.delete(d.dataset.prompt)}},true);
  window.AppsView={load:()=>{paint();return load()},data:()=>A.data};
})();
