#!/usr/bin/env python3
"""「今すぐ更新」の関所（MCP サーバー・標準入出力）。以前の手元の版の関所と同じ決まり。

更新係（claude -p）に --permission-prompt-tool として渡す。確認が要る操作はここに来て、
書き込んでよいファイル（MYAI_REFRESH_FILES）への Write / Edit だけを通す。それ以外はすべて却下する。
- ~/.claude/ の下は Claude Code が守っている場所で、許可ルールだけでは書けない。そのため関所で通す
- 判断は MYAI_REFRESH_GUARD_LOG（jsonl）に残す
"""
from __future__ import annotations

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _mcp_stdio import serve  # noqa: E402

FILES = {os.path.realpath(x) for x in os.environ.get("MYAI_REFRESH_FILES", "").split(os.pathsep) if x}
LOG = os.environ.get("MYAI_REFRESH_GUARD_LOG", "")
WRITE_TOOLS = {"Write", "Edit", "MultiEdit"}


def _log(entry: dict):
    if not LOG:
        return
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"), **entry}, ensure_ascii=False) + "\n")
    except OSError:
        pass


def decide(tool_name: str, tool_input: dict) -> dict:
    fp = str((tool_input or {}).get("file_path") or "")
    if tool_name in WRITE_TOOLS and fp and os.path.realpath(fp) in FILES:
        _log({"decision": "allow", "tool": tool_name, "file": fp})
        return {"behavior": "allow", "updatedInput": tool_input}
    _log({"decision": "deny", "tool": tool_name, "file": fp or None})
    names = "・".join(os.path.basename(x) for x in sorted(FILES)) or "なし"
    return {"behavior": "deny", "message": f"{tool_name} は使えない。書けるファイルは {names} だけ"}


TOOL = {
    "name": "check",
    "description": "「今すぐ更新」で書いてよいファイルかを確かめる関所",
    "inputSchema": {"type": "object",
                    "properties": {"tool_name": {"type": "string"}, "input": {"type": "object"}, "tool_use_id": {"type": "string"}},
                    "required": ["tool_name", "input"]},
}


def _call(_name: str, args: dict) -> str:
    return json.dumps(decide(str(args.get("tool_name") or ""), args.get("input") or {}), ensure_ascii=False)


if __name__ == "__main__":
    serve("myai_refresh_guard", [TOOL], _call)
