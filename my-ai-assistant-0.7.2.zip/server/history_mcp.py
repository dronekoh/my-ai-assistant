#!/usr/bin/env python3
"""過去の会話を読む MCP サーバー（標準入出力・読むだけ）。Addness の相談役（claude -p）に渡す。

道具: search_history（全期間の検索）・read_session（1つの会話を読む）・list_memory（メモリの索引）
索引は画面サーバーが作る history.db（MYAI_HISTORY_DB）。ここは読むだけで、取り込みはしない。
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import history  # noqa: E402
from _mcp_stdio import serve  # noqa: E402

TOOLS = [
    {"name": "search_history", "description": "これまでの会話（全期間）を語で検索する。空白区切りの語はすべて含むもの",
     "inputSchema": {"type": "object", "properties": {"query": {"type": "string"}, "limit": {"type": "integer"},
                                                      "source": {"type": "string"}, "since": {"type": "string"}},
                     "required": ["query"]}},
    {"name": "read_session", "description": "search_history で見つけた会話（session_id）を読む",
     "inputSchema": {"type": "object", "properties": {"session_id": {"type": "string"}, "offset": {"type": "integer"},
                                                      "limit": {"type": "integer"}, "roles": {"type": "string"}},
                     "required": ["session_id"]}},
    {"name": "list_memory", "description": "メモリ（覚えていること）の索引を読む", "inputSchema": {"type": "object", "properties": {}}},
]


def _int(v, dflt: int, lo: int, hi: int) -> int:
    try:
        n = int(v)
    except (TypeError, ValueError):
        n = dflt
    return max(lo, min(n, hi))


def format_search(groups: list) -> str:
    if not groups:
        return "見つかりませんでした。語を短くする・言い換える・空白で区切る、を試してください。"
    lines = []
    for g in groups:
        lines.append(f"■ [{g['sourceJa']}] {g['title']}（最終 {(g.get('lastTs') or '')[:10]}） session_id={g['sid']}")
        for h in g["hits"]:
            lines.append(f"   {(h.get('ts') or '')[:16]} {h['role']}: {h['snippet']}")
    return "\n".join(lines)


def format_session(s: dict, roles: str) -> str:
    want = {r.strip() for r in roles.split(",") if r.strip()}
    msgs = s["messages"]
    head = f"[{s['sourceJa']}] {s['title']}  発言 {s['n']} 件中 {s['offset']}〜{s['offset'] + len(msgs) - 1}"
    body = [f"--- #{m['seq']} {(m.get('ts') or '')[:16]} {m['role']}\n{m['text']}" for m in msgs if not want or m["role"] in want]
    nxt = s["offset"] + len(msgs)
    return head + "\n" + "\n".join(body) + (f"\n（続きあり：offset={nxt}）" if nxt < s["n"] else "")


def call(name: str, a: dict) -> str:
    try:
        if name == "search_history":
            q = str(a.get("query") or "").strip()[:500]
            if not q:
                return "query が空です。検索語を入れてください。"
            res = history.search(q, source=str(a.get("source") or "") or None, since=str(a.get("since") or "") or None,
                                 limit=_int(a.get("limit"), 10, 1, 30), per_session=3)
            return format_search(res)
        if name == "read_session":
            sid = str(a.get("session_id") or "")
            if not sid:
                return "session_id が空です。"
            s = history.get_session(sid, offset=_int(a.get("offset"), 0, 0, 10_000_000), limit=_int(a.get("limit"), 60, 1, 200))
            return format_session(s, str(a.get("roles") or "")) if s else "その session_id の会話はありません。"
        text = history.memory_index()
        return text or "メモリの索引が見つかりません。"
    except Exception as e:   # 読めなくても、相談役には文で返す
        return f"エラー: 過去の会話を読めませんでした（{e.__class__.__name__}）"


if __name__ == "__main__":
    history.configure(os.environ.get("MYAI_HISTORY_DB") or "")
    serve("myai_history", TOOLS, call)
