export type MyAiAssistantPhase = 'starting' | 'running' | 'no-python' | 'port-busy' | 'stopped' | 'failed'

export type MyAiAssistantStatus = {
  phase: MyAiAssistantPhase
  message: string
}

declare module 'claude-code' {
  interface PluginState {
    'my-ai-assistant': {
      status: MyAiAssistantStatus
      handled: number
      last: string | null
      org: string
      name: string
      web: { line: string; pair: { code: string; expiresAt: number } | null; sas: { code: string; name: string } | null; history: boolean; note: string | null }
    }
  }
}
