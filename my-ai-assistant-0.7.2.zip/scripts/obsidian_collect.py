#!/usr/bin/env python3
"""Obsidian への毎晩の書き出し（1）: 集める道具（標準ライブラリだけ・読むだけ）。

指定した日（既定は前日と今日）の会話を集めて、日ごとに JSON と番号つきの文字に並べる。要約はしない
（要約は定期タスクの Claude 自身がする。手順は config/obsidian-task.example.md）。

設定: <データ置き場>/obsidian.json（無い・vault が空・enabled が false なら何もしない）
  vault            書き出し先の保管庫（絶対パス。ここより外には書かない）
  folder           保管庫の中のフォルダ（相対。既定は保管庫の直下）
  folders          この作業フォルダ（とその下）の Code タブの会話を執行役の会話として集める（既定 []）
  pluginSessions   このプラグインの部署（my-ai-assistant:*）を使った会話も集める（既定 true）
  excludeSessions  集めない会話の sessionId（既定 []）
  addnessThreads   Addness の相談の記録のフォルダ（既定 <データ置き場>/addness/threads。無ければ飛ばす）
  ほかの項目（source・tags・projects・relatedNotes・selfNames・model）は書き出す道具が使う

集めるもの:
  M  執行役との会話（利用者の発言と、執行役の返事の文字だけ。道具の記録は入れない）
  T  執行役が部署に任せた仕事（Agent/Task の呼び出しと、部署の報告）
  A  Addness の相談の記録（<addnessThreads>/<id>.json。形が決まっていないので messages 系の配列を広めに読む）
定期タスクの会話（書き出し自身を含む）は集めない。

書くもの（データ置き場の中だけ）:
  <データ置き場>/obsidian/work/<日>.json  集めた中身（書き出す道具が読む）
  <データ置き場>/obsidian/work/<日>.txt   番号つきの文字（定期タスクの Claude が読む）
状態 <データ置き場>/obsidian/state.json（書き出す道具が書く）と比べ、前回の書き出しから変わっていない日は飛ばす。

使い方:
  python3 obsidian_collect.py                     前日と今日
  python3 obsidian_collect.py --date 2026-10-28   日付指定（何度でも）
  python3 obsidian_collect.py --force             変わっていなくても出す
標準出力に、日ごとの要約（status: new / changed / unchanged / empty と件数・ファイルの場所）を JSON で出す。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

PLUGIN_PREFIX = "my-ai-assistant:"
TASK_MARKER = "my-ai-assistant-obsidian-task"   # 書き出しの定期タスクの手順書に入れる目印（その会話は集めない）
MSG_MAX = 20000          # 1発言あたりの最大文字数
PROMPT_MAX = 6000
SUMMARY_MAX = 12000
ADDNESS_KEYS = ("messages", "chat", "history", "turns")
ROLE_JA = {"user": "私", "assistant": "執行役", "report": "部署の報告", "note": "記録"}


# ---------------------------------------------------------------- 共通

def data_dir(arg: str | None = None) -> Path:
    return Path(arg or os.environ.get("MYAI_DATA_DIR") or (Path.home() / ".my-ai-assistant"))


def claude_dir() -> Path:
    return Path(os.environ.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude"))


def app_dir() -> Path:
    return Path.home() / "Library" / "Application Support" / "Claude"


def load_json(p: Path, default: Any) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def save_json(p: Path, data: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(p.parent, 0o700)
    tmp = p.with_name(p.name + f".tmp-{os.getpid()}")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)   # 会話の中身が入るので本人だけ
    os.replace(tmp, p)


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def local_tz():
    return datetime.now().astimezone().tzinfo


def to_local(ts: Any) -> datetime | None:
    if not ts:
        return None
    try:
        if isinstance(ts, (int, float)):
            return datetime.fromtimestamp(ts / 1000 if ts > 1e11 else ts, local_tz())
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=local_tz())
        return dt.astimezone(local_tz())
    except (ValueError, OverflowError, OSError):
        return None


def on_day(ts: Any, day: date) -> bool:
    dt = to_local(ts)
    return bool(dt and dt.date() == day)


def hhmm(ts: Any) -> str:
    dt = to_local(ts)
    return dt.strftime("%H:%M") if dt else "--:--"


def cut(text: str, n: int) -> str:
    text = text or ""
    return text if len(text) <= n else text[:n] + f"…（以下 {len(text) - n} 字略）"


def expand(p: str) -> Path:
    return Path(os.path.expanduser(p))


def dept_labels() -> dict[str, str]:
    """部署の登録名 → 表示名（プラグインの config/org.json。無ければ空）"""
    org = load_json(Path(__file__).resolve().parent.parent / "config" / "org.json", {})
    out = {}
    for d in org.get("departments", []) if isinstance(org, dict) else []:
        if isinstance(d, dict) and d.get("name") and d.get("label"):
            out[str(d["name"])] = str(d["label"])
    return out


def load_config(ddir: Path) -> dict | None:
    """設定が使えるときだけ dict。無い・切・vault が空なら None"""
    cfg = load_json(ddir / "obsidian.json", None)
    if not isinstance(cfg, dict) or cfg.get("enabled") is False:
        return None
    vault = cfg.get("vault")
    if not isinstance(vault, str) or not vault.strip():
        return None
    return cfg


def state_path(ddir: Path) -> Path:
    return ddir / "obsidian" / "state.json"


def work_dir(ddir: Path) -> Path:
    return ddir / "obsidian" / "work"


# ---------------------------------------------------------------- 会話を選ぶ

def scheduled_sessions() -> set[str]:
    """デスクトップアプリの記録で、定期タスクの会話の sessionId（Mac だけ。無ければ空）"""
    out = set()
    try:
        files = list(app_dir().glob("claude-code-sessions/*/*/local_*.json"))
    except OSError:
        return out
    for p in files:
        d = load_json(p, None)
        if isinstance(d, dict) and d.get("cliSessionId") and d.get("scheduledTaskId"):
            out.add(d["cliSessionId"])
    return out


def under(path: str | None, folders: list[Path]) -> bool:
    if not path:
        return False
    p = os.path.normpath(path)
    for f in folders:
        fs = os.path.normpath(str(f))
        if p == fs or p.startswith(fs.rstrip(os.sep) + os.sep):
            return True
    return False


def read_lines(path: Path):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                if isinstance(d, dict):
                    yield d
    except OSError:
        return


def first_cwd(path: Path) -> str | None:
    for d in read_lines(path):
        if d.get("cwd"):
            return d["cwd"]
    return None


def candidate_transcripts(earliest: date) -> list[Path]:
    """mtime が集める最初の日より前のものは中身を読まない（速さのため）"""
    start = datetime.combine(earliest, datetime.min.time(), local_tz()).timestamp()
    out = []
    try:
        paths = sorted(claude_dir().glob("projects/*/*.jsonl"))
    except OSError:
        return out
    for p in paths:
        try:
            if p.stat().st_mtime >= start:
                out.append(p)
        except OSError:
            pass
    return out


# ---------------------------------------------------------------- 1つの会話を読む

_STOP_TAIL = re.compile(r"(\r?\n\r?\n（画面の[^\r\n]*）)+\s*$")
_AGENT_MSG = re.compile(r"<agent-message from=\"([^\"]+)\">\s*(.*?)</agent-message>", re.S)


_PLUGIN_SENT = re.compile(r"^The [\w.-]+ plugin sent a message:\n(.*?)\n\nThis is how Claude Code surfaces a prompt[^\n]*$", re.S)
_SYSTEM_TAG = re.compile(r"^<[a-z][a-z0-9-]*[\s>]")
_SKIP_HEADS = ("[Image:", "This session is being continued from a previous conversation")


def clean_user_text(s: str) -> str:
    """画面（手元・Web）から送った文は中身だけにし、会話の仕組みが入れた文は空にする"""
    m = _PLUGIN_SENT.match(s.strip())
    if m:
        s = m.group(1)
    elif _SYSTEM_TAG.match(s.lstrip()) or s.lstrip().startswith(_SKIP_HEADS):
        return ""
    s = _STOP_TAIL.sub("", s)
    s = re.sub(r"<system-reminder>.*?</system-reminder>", "", s, flags=re.S)
    return s.strip()


def report_body(raw: str) -> str:
    """部署の報告（hand-back）の本文だけ。前置きの説明を外し、字下げを戻す"""
    m = _AGENT_MSG.search(raw)
    body = m.group(2) if m else raw
    if "The report follows:" in body:
        body = body.split("The report follows:", 1)[1]
    lines = body.strip("\n").splitlines()
    return "\n".join(ln[2:] if ln.startswith("  ") else ln for ln in lines).strip()


def tool_result_text(c: Any) -> str:
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return "\n".join(str(x.get("text", "")) for x in c if isinstance(x, dict) and x.get("type") == "text")
    return ""


def parse_session(path: Path) -> dict:
    """発言（全日分）と部署の仕事を取り出す"""
    msgs: list[dict] = []
    tasks: dict[str, dict] = {}          # tool_use_id → task
    by_agent: dict[str, dict] = {}       # agentId → task
    marker = False
    plugin = False
    title = None
    cwd = None
    for d in read_lines(path):
        if d.get("isSidechain"):
            continue
        t = d.get("type")
        ts = d.get("timestamp")
        if t == "custom-title" and d.get("customTitle"):
            title = d["customTitle"]
        if d.get("cwd") and not cwd:
            cwd = d["cwd"]
        cont = (d.get("message") or {}).get("content")
        origin = d.get("origin") if isinstance(d.get("origin"), dict) else {}
        if t == "user":
            if isinstance(cont, str):
                if TASK_MARKER in cont:
                    marker = True
                if origin.get("kind") == "peer" or cont.lstrip().startswith("Another Claude session sent a message"):
                    m = _AGENT_MSG.search(cont)
                    aid = origin.get("from") or (m.group(1) if m else None)
                    body = report_body(cont)
                    task = by_agent.get(aid or "")
                    if task is not None:
                        task["summary"] = body
                        task["finishedAt"] = ts
                        task["status"] = "完了"
                    elif body:
                        msgs.append({"role": "report", "ts": ts, "text": body})
                    continue
                if cont.lstrip().startswith("<task-notification"):
                    tid = re.search(r"<task-id>([^<]+)</task-id>", cont)
                    task = by_agent.get(tid.group(1)) if tid else None
                    if task is not None:
                        st = re.search(r"<status>([^<]+)</status>", cont)
                        res = re.search(r"<result>(.*?)</result>", cont, re.S)
                        if st and st.group(1) != "completed":
                            task["status"] = st.group(1)
                        if res and "delivered to you as a message" not in res.group(1) and not task.get("summary"):
                            task["summary"] = res.group(1).strip()
                            task["finishedAt"] = ts
                            task["status"] = "完了"
                    continue
                if d.get("isMeta"):
                    continue
                s = clean_user_text(cont)
                if not s or s.startswith(("[Image:", "<command-", "<local-command")):
                    continue
                msgs.append({"role": "user", "ts": ts, "text": s})
            elif isinstance(cont, list):
                for b in cont:
                    if not isinstance(b, dict):
                        continue
                    if b.get("type") == "tool_result" and b.get("tool_use_id") in tasks:
                        task = tasks[b["tool_use_id"]]
                        tur = d.get("toolUseResult") if isinstance(d.get("toolUseResult"), dict) else {}
                        if tur.get("agentId"):
                            task["taskId"] = tur["agentId"]
                            by_agent[tur["agentId"]] = task
                        if tur.get("isAsync") or tur.get("status") == "async_launched":
                            task["status"] = "実行中"
                            continue
                        txt = tool_result_text(b.get("content")).strip()
                        if txt:
                            task["summary"] = re.sub(r"\nagentId: .*$", "", txt, flags=re.S).strip()
                            task["finishedAt"] = ts
                            task["status"] = "失敗" if b.get("is_error") else "完了"
                    elif b.get("type") == "text" and not d.get("isMeta"):
                        if TASK_MARKER in str(b.get("text")):
                            marker = True
                        s = clean_user_text(str(b.get("text") or ""))
                        if s and not s.startswith(("[Image:", "<task-notification", "<command-")):
                            msgs.append({"role": "user", "ts": ts, "text": s})
        elif t == "assistant" and isinstance(cont, list):
            txt = "\n".join(str(b.get("text", "")) for b in cont
                            if isinstance(b, dict) and b.get("type") == "text").strip()
            if txt:
                msgs.append({"role": "assistant", "ts": ts, "text": txt})
            for b in cont:
                if not (isinstance(b, dict) and b.get("type") == "tool_use" and b.get("name") in ("Agent", "Task")):
                    continue
                inp = b.get("input") or {}
                sub = str(inp.get("subagent_type") or "")
                if not sub.startswith(PLUGIN_PREFIX):
                    continue
                plugin = True
                tasks[b.get("id") or f"t{len(tasks)}"] = {
                    "dept": sub[len(PLUGIN_PREFIX):], "title": str(inp.get("description") or ""),
                    "status": "依頼", "startedAt": ts, "finishedAt": None,
                    "prompt": str(inp.get("prompt") or ""), "summary": "", "taskId": ""}
    return {"messages": msgs, "tasks": list(tasks.values()), "marker": marker, "plugin": plugin,
            "title": title, "cwd": cwd}


# ---------------------------------------------------------------- Addness の相談の記録

def addness_threads(folder: Path, day: date) -> list[dict]:
    out: list[dict] = []
    if not folder.is_dir():
        return out
    for p in sorted(folder.glob("*.json")):
        if p.name.startswith("_"):
            continue
        d = load_json(p, None)
        if not isinstance(d, dict):
            continue
        msgs = next((d[k] for k in ADDNESS_KEYS if isinstance(d.get(k), list)), None)
        if not msgs:
            continue
        picked = []
        for m in msgs:
            if not isinstance(m, dict):
                continue
            ts = m.get("ts") or m.get("time") or m.get("createdAt") or m.get("timestamp") or m.get("at")
            text = m.get("text") or m.get("content") or m.get("body") or ""
            if not isinstance(text, str) or not text.strip() or not on_day(ts, day):
                continue
            role = str(m.get("role") or m.get("from") or "")
            if role not in ("user", "assistant"):
                role = "user" if role in ("human", "me", "self") else ("assistant" if role else "note")
            picked.append({"role": role, "ts": ts, "text": cut(text.strip(), MSG_MAX)})
        if picked:
            goal = d.get("goal") if isinstance(d.get("goal"), dict) else {}
            item = d.get("item") if isinstance(d.get("item"), dict) else {}
            title = d.get("title") or d.get("goalTitle") or goal.get("title") or item.get("title") or d.get("name") or p.stem
            out.append({"file": str(p), "thread": p.stem, "title": str(title),
                        "sessionId": d.get("sessionId"), "messages": picked})
    return out


# ---------------------------------------------------------------- 1日分を集める

def collect_day(day: date, cfg: dict, ddir: Path, parsed: dict[Path, dict], sched: set[str]) -> dict:
    folders = [expand(f) for f in cfg.get("folders") or [] if isinstance(f, str) and f.strip()]
    plugin_ok = cfg.get("pluginSessions", True) is not False
    exclude = {str(s) for s in cfg.get("excludeSessions") or []}
    messages: list[dict] = []
    tasks: list[dict] = []
    sessions: dict[str, dict] = {}
    labels = dept_labels()
    for path, ses in parsed.items():
        sid = path.stem
        if sid in exclude or sid in sched or ses["marker"]:
            continue
        if not (under(ses["cwd"], folders) or (plugin_ok and ses["plugin"])):
            continue
        got = [m for m in ses["messages"] if on_day(m["ts"], day)]
        tk = [t for t in ses["tasks"] if on_day(t["startedAt"], day) or on_day(t["finishedAt"], day)]
        if not got and not tk:
            continue
        for m in got:
            messages.append({**m, "text": cut(m["text"], MSG_MAX), "sid": sid})
        for t in tk:
            sub = path.with_suffix("") / "subagents" / f"agent-{t['taskId']}.jsonl" if t["taskId"] else None
            tasks.append({**t, "dept": labels.get(t["dept"], t["dept"]), "prompt": cut(t["prompt"], PROMPT_MAX), "summary": cut(t["summary"], SUMMARY_MAX),
                          "sid": sid, "subagent_jsonl": str(sub) if sub and sub.exists() else None})
        sessions[sid] = {"jsonl": str(path), "cwd": ses["cwd"], "title": ses["title"],
                         "times": sorted(hhmm(m["ts"]) for m in got)}
    key = lambda x: to_local(x) or datetime.min.replace(tzinfo=local_tz())  # noqa: E731
    messages.sort(key=lambda m: key(m["ts"]))
    tasks.sort(key=lambda t: key(t["startedAt"]))
    adir = expand(cfg["addnessThreads"]) if isinstance(cfg.get("addnessThreads"), str) else ddir / "addness" / "threads"
    addness = addness_threads(adir, day)
    for i, m in enumerate(messages, 1):
        m["id"] = f"M{i}"
    for i, t in enumerate(tasks, 1):
        t["id"] = f"T{i}"
    for i, a in enumerate(addness, 1):
        a["id"] = f"A{i}"
    return {"day": day.isoformat(), "messages": messages, "tasks": tasks, "addness": addness, "sessions": sessions}


def source_hash(src: dict) -> str:
    core = {"m": [(m["role"], m["ts"], m["text"]) for m in src["messages"]],
            "t": [(t["title"], t["status"], t["summary"]) for t in src["tasks"]],
            "a": [(a["thread"], [(m["ts"], m["text"]) for m in a["messages"]]) for a in src["addness"]]}
    return sha(json.dumps(core, ensure_ascii=False, sort_keys=True))


def has_content(src: dict) -> bool:
    return any(m["role"] == "user" for m in src["messages"]) or bool(src["tasks"]) or bool(src["addness"])


def render_text(src: dict, prev_titles: list[str]) -> str:
    """定期タスクの Claude が読む形。M=執行役との会話 / T=部署の仕事 / A=Addness の相談"""
    out = [f"# {src['day']} の会話の記録（M=執行役との会話 / T=執行役が部署に任せた仕事 / A=Addness の相談）", ""]
    if prev_titles:
        out += ["前回この日を書き出したときの題名（同じ話題なら同じ題名をそのまま使う）:"]
        out += [f"- {t}" for t in prev_titles] + [""]
    for m in src["messages"]:
        out.append(f"[{m['id']}] {hhmm(m['ts'])} {ROLE_JA.get(m['role'], m['role'])}: {m['text']}")
        out.append("")
    for t in src["tasks"]:
        out.append(f"[{t['id']}] 部署の仕事「{t['title']}」（{t['dept']}・状態 {t['status']}・"
                   f"{hhmm(t['startedAt'])}〜{hhmm(t['finishedAt']) if t['finishedAt'] else ''}）")
        out.append(f"  執行役からの指示: {t['prompt']}")
        out.append(f"  部署の報告: {t['summary'] or '（まだ無い）'}")
        out.append("")
    for a in src["addness"]:
        out.append(f"[{a['id']}] Addness の相談「{a['title']}」")
        out += [f"  {hhmm(m['ts'])} {ROLE_JA.get(m['role'], m['role'])}: {m['text']}" for m in a["messages"]]
        out.append("")
    return "\n".join(out).rstrip() + "\n"


def default_days(today: date) -> list[date]:
    return [today - timedelta(days=1), today]


def run(days: list[date], ddir: Path, force: bool = False) -> dict:
    cfg = load_config(ddir)
    if cfg is None:
        return {"enabled": False, "note": f"{ddir / 'obsidian.json'} が無い・切・vault が空なので何もしません", "days": []}
    st = load_json(state_path(ddir), {"version": 1, "dates": {}})
    dates = st.get("dates") if isinstance(st.get("dates"), dict) else {}
    sched = scheduled_sessions()
    parsed = {p: parse_session(p) for p in candidate_transcripts(min(days))}
    out = []
    for day in days:
        src = collect_day(day, cfg, ddir, parsed, sched)
        h = source_hash(src)
        prev = dates.get(day.isoformat()) or {}
        src["sourceHash"] = h
        src["previousTitles"] = [n.get("title", "") for n in prev.get("notes", []) if isinstance(n, dict)]
        counts = {"user": sum(1 for m in src["messages"] if m["role"] == "user"),
                  "assistant": sum(1 for m in src["messages"] if m["role"] == "assistant"),
                  "tasks": len(src["tasks"]), "addness": len(src["addness"])}
        info = {"day": day.isoformat(), "counts": counts, "sourceHash": h}
        if not has_content(src):
            info["status"] = "empty"
        elif prev.get("sourceHash") == h and not force:
            info["status"] = "unchanged"
        else:
            info["status"] = "changed" if prev else "new"
            wd = work_dir(ddir)
            wd.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(wd.parent, 0o700)
            save_json(wd / f"{day.isoformat()}.json", src)
            txt = wd / f"{day.isoformat()}.txt"
            txt.write_text(render_text(src, src["previousTitles"]), encoding="utf-8")
            os.chmod(txt, 0o600)
            info["text"] = str(txt)
            info["json"] = str(wd / f"{day.isoformat()}.json")
            info["notesFile"] = str(wd / f"{day.isoformat()}.notes.json")
            info["previousTitles"] = src["previousTitles"]
        out.append(info)
    return {"enabled": True, "days": out}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Obsidian へ書き出す会話を集める（読むだけ・要約しない）")
    ap.add_argument("--date", action="append", help="YYYY-MM-DD（何度でも。省略時は前日と今日）")
    ap.add_argument("--force", action="store_true", help="前回から変わっていなくても出す")
    ap.add_argument("--data-dir", help="データ置き場（既定は MYAI_DATA_DIR か ~/.my-ai-assistant）")
    a = ap.parse_args(argv)
    try:
        days = sorted({date.fromisoformat(d) for d in a.date}) if a.date else default_days(datetime.now().astimezone().date())
    except ValueError:
        print(json.dumps({"error": "日付は YYYY-MM-DD で"}, ensure_ascii=False))
        return 2
    print(json.dumps(run(days, data_dir(a.data_dir), a.force), ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
