#!/usr/bin/env python3
"""Obsidian への毎晩の書き出し（2）: 書き出す道具（標準ライブラリだけ）。

定期タスクの Claude が要約した JSON（<日>.notes.json）を受けて、保管庫に会話ノート（1話題＝1ノート）を書き、
状態 <データ置き場>/obsidian/state.json を更新する。集める道具（obsidian_collect.py）が作った <日>.json を一緒に読む。

要約の JSON の形:
  {"day": "2026-10-28", "sourceHash": "<集めたときの値>",
   "notes": [{"title": "題名", "items": ["M1", "M2", "T1"], "project": "…", "status": "完了|続きあり|判断待ち",
              "tags": ["語", "語"], "body": "# 題名\\n\\n## 一言でいうと\\n…（決まった6つの見出し）"}]}

守ること:
  - 書くのは <vault>/<folder> の中だけ（パスを確かめる。外を指す名前・リンクは断る）
  - 同時に2つ動かない（ロック <データ置き場>/obsidian/write.lock）
  - 前回自分が書いたもの以外の同じ名前のファイルは上書きしない（_2 などを付ける）
  - 手で直された形跡のある前のノートは、上書きの前に控えを <データ置き場>/obsidian/backup に残す
  - 前回あって今回なくなった題名のノートは、消さずに控えへ移す（手で直されていたら残す）
  - 集めた後に中身が変わっていたら（sourceHash が違う）書かない。同じ中身をもう書いてあれば飛ばす（--force で出し直し）

使い方:
  python3 obsidian_write.py --notes <データ置き場>/obsidian/work/2026-10-28.notes.json
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import obsidian_collect as oc  # noqa: E402

SECTIONS = ["一言でいうと", "決めたこと", "私が出した指示・修正・却下", "分かったこと（事実・数字・仕様）",
            "未決・宿題", "成果物の所在"]
STATUS_CHOICES = ["完了", "続きあり", "判断待ち"]
DEFAULT_SOURCE = "my-ai-assistant"
DEFAULT_TAGS = ["claude会話"]
DEFAULT_PROJECTS = ["その他"]


class WriteError(Exception):
    pass


# ---------------------------------------------------------------- 場所

def target_dir(cfg: dict) -> tuple[Path, Path]:
    """(保管庫, 書き出し先)。書き出し先が保管庫の外になる設定は断る"""
    vault = oc.expand(cfg["vault"])
    if not vault.is_absolute():
        raise WriteError("vault は絶対パスで書いてください")
    if not vault.is_dir():
        raise WriteError(f"保管庫が見つかりません: {vault}")
    vroot = vault.resolve()
    folder = str(cfg.get("folder") or "").strip()
    if folder and (Path(folder).is_absolute() or ".." in Path(folder).parts):
        raise WriteError("folder は保管庫の中の相対パスで書いてください（.. は使えません）")
    dest = (vroot / folder) if folder else vroot
    # 途中にリンクがあって外を指していないか（まだ無いフォルダは、できる手前まで）
    probe = dest
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    if not inside(probe.resolve(), vroot):
        raise WriteError(f"書き出し先が保管庫の外を指しています: {dest}")
    return vroot, dest


def inside(p: Path, root: Path) -> bool:
    try:
        p.relative_to(root)
        return True
    except ValueError:
        return False


def safe_file(dest: Path, vroot: Path, name: str) -> Path:
    if not name or name != Path(name).name or name in (".", "..") or "/" in name or "\\" in name:
        raise WriteError(f"ファイル名が使えません: {name!r}")
    p = dest / name
    real = p.resolve()   # すでにあるリンクは、その先を確かめる
    if not inside(real, vroot) or real.parent != dest.resolve():
        raise WriteError(f"保管庫の外へは書きません: {p}")
    return p


# ---------------------------------------------------------------- ノートを組み立てる

def clean_title(t: str) -> str:
    t = re.sub(r'[/\\:*?"<>|\n\r\t\[\]#^]', "・", str(t or "")).strip(" .・")
    return t[:40]


def valid_body(body: str) -> bool:
    return all(f"## {s}" in body for s in SECTIONS)


def norm_tags(raw: Any, base: list[str]) -> str:
    if isinstance(raw, str):
        raw = raw.strip().strip("[]").split(",")
    tags = [re.sub(r"[\s（）()\[\],]", "", str(t).strip().strip("'\"")) for t in (raw or [])]
    tags = [t for t in tags if t and not t.startswith("中身")]
    out = base + [t for t in tags if t not in base]
    return "[" + ", ".join(out[:max(7, len(base))]) + "]"


def to_self(body: str, names: list[str]) -> str:
    for n in names:
        if isinstance(n, str) and n.strip():
            body = re.sub(re.escape(n.strip()) + r"(?![ _-]?AI|[A-Za-z0-9_/.-])\s?(さん)?", "私", body)
    return body


def source_section(src: dict, items: list[str], script: Path, model: str) -> str:
    lines = ["## 元の記録"]
    msgs = {m["id"]: m for m in src["messages"]}
    by_sid: dict[str, list] = {}
    for i in items:
        m = msgs.get(i)
        if m and m.get("sid"):
            by_sid.setdefault(m["sid"], []).append(m["ts"])
    for sid, tss in by_sid.items():
        info = src["sessions"].get(sid, {})
        times = sorted({oc.hhmm(x) for x in tss})
        shown = "・".join(times[:15]) + ("…" if len(times) > 15 else "")
        lines.append(f"- 執行役との会話（この話題の発言: {shown}）")
        lines.append(f"  - sessionId: `{sid}`")
        if info.get("jsonl"):
            lines.append(f"  - 本体の記録: `{info['jsonl']}`")
    tasks = {t["id"]: t for t in src["tasks"]}
    adds = {a["id"]: a for a in src["addness"]}
    for i in items:
        if i in tasks:
            t = tasks[i]
            lines.append(f"- 部署の仕事「{t['title']}」（{t['dept']}・taskId `{t['taskId']}`）")
            if t.get("subagent_jsonl"):
                lines.append(f"  - 作業の記録: `{t['subagent_jsonl']}`")
            elif t.get("sid"):
                lines.append(f"  - 執行役の会話 `{t['sid']}` の中")
        elif i in adds:
            a = adds[i]
            lines.append(f"- Addness の相談「{a['title']}」: `{a['file']}`")
            if a.get("sessionId"):
                lines.append(f"  - sessionId: `{a['sessionId']}`")
    lines.append(f"- 書き出し: `{script}`（{datetime.now().strftime('%Y-%m-%d %H:%M')}・要約 {model}）")
    return "\n".join(lines)


def build_note(cfg: dict, src: dict, note: dict, siblings: list[str]) -> str:
    source = str(cfg.get("source") or DEFAULT_SOURCE)
    base = [str(t) for t in (cfg.get("tags") or DEFAULT_TAGS)] + [source]
    projects = [str(p) for p in (cfg.get("projects") or DEFAULT_PROJECTS)]
    project = next((p for p in projects if p == str(note.get("project") or "")), None) \
        or next((p for p in projects if p in str(note.get("project") or "")), projects[0])
    status = next((s for s in STATUS_CHOICES if s in str(note.get("status") or "")), "続きあり")
    body = str(note["body"]).strip()
    body = re.sub(r"^```(?:markdown|md)?\s*|\s*```$", "", body)
    body = re.sub(r"^---\s*\n.*?\n---\s*\n", "", body, flags=re.S).strip()   # モデルが付けたメタデータは落とす
    body = re.sub(r"^#\s+.*$", f"# {note['title']}", body, count=1, flags=re.M)
    if not body.startswith("# "):
        body = f"# {note['title']}\n\n" + body
    body = re.split(r"\n## (?:関連ノート|元の記録)\s*\n", body)[0].rstrip()
    body = to_self(body, list(cfg.get("selfNames") or []))
    related = ["## 関連ノート"] + [f"- [[{r}]]" for r in (cfg.get("relatedNotes") or [])] + [f"- [[{s}]]" for s in siblings]
    if len(related) == 1:
        related.append("- なし")
    model = str(cfg.get("model") or "定期タスクの Claude")
    return (f"---\ndate: {src['day']}\nsource: {source}\nproject: {project}\ntags: {norm_tags(note.get('tags'), base)}\n"
            f"status: {status}\n---\n\n{body}\n\n" + "\n".join(related) + "\n\n"
            + source_section(src, note["items"], Path(__file__).resolve(), model) + "\n")


# ---------------------------------------------------------------- 書く

def file_sha(p: Path) -> str | None:
    try:
        return oc.sha(p.read_text(encoding="utf-8"))
    except OSError:
        return None


def is_ours(p: Path, source: str) -> bool:
    try:
        head = p.read_text(encoding="utf-8")[:400]
    except OSError:
        return False
    return f"\nsource: {source}\n" in head


def stash(p: Path, ddir: Path, why: str, log: list) -> None:
    bdir = ddir / "obsidian" / "backup"
    bdir.mkdir(parents=True, exist_ok=True)
    dst = bdir / f"{datetime.now().strftime('%Y%m%d-%H%M%S')}_{p.name}"
    shutil.copy2(p, dst)
    log.append(f"{why}: 控え {dst}")


def write_atomic(p: Path, text: str) -> None:
    tmp = p.with_name(f".{p.name}.tmp-{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, p)


def check_notes(data: dict, src: dict) -> list[dict]:
    ids = {m["id"] for m in src["messages"]} | {t["id"] for t in src["tasks"]} | {a["id"] for a in src["addness"]}
    notes = data.get("notes")
    if not isinstance(notes, list) or not notes:
        raise WriteError("notes が空です")
    out, used, errs = [], set(), []
    for k, n in enumerate(notes, 1):
        if not isinstance(n, dict):
            errs.append(f"{k}件目: 形が違います")
            continue
        title = clean_title(n.get("title"))
        items = [i for i in n.get("items") or [] if i in ids and i not in used]
        used.update(items)
        body = str(n.get("body") or "")
        if not title:
            errs.append(f"{k}件目: 題名が空です")
        elif not valid_body(body):
            errs.append(f"「{title}」: 見出しが足りません（{'・'.join(s for s in SECTIONS if f'## {s}' not in body)}）")
        out.append({**n, "title": title, "items": items, "body": body})
    if errs:
        raise WriteError("要約の形が崩れています。直してからもう一度: " + " / ".join(errs))
    left = sorted(ids - used)
    if left and out:
        out[-1]["items"] += left   # 取りこぼしは最後の話題へ（元の記録に出すため）
    return out


def write_day(ddir: Path, data: dict, force: bool = False) -> dict:
    cfg = oc.load_config(ddir)
    if cfg is None:
        return {"ok": True, "skipped": "設定が無い・切なので何もしません", "written": []}
    day = str(data.get("day") or "")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", day):
        raise WriteError("day は YYYY-MM-DD で")
    src = oc.load_json(oc.work_dir(ddir) / f"{day}.json", None)
    if not isinstance(src, dict):
        raise WriteError(f"集めた中身がありません。先に obsidian_collect.py --date {day} を")
    if data.get("sourceHash") != src.get("sourceHash"):
        raise WriteError("集めた中身と要約の sourceHash が違います。集め直してから要約し直してください")
    notes = check_notes(data, src)
    vroot, dest = target_dir(cfg)
    source = str(cfg.get("source") or DEFAULT_SOURCE)

    sp = oc.state_path(ddir)
    st = oc.load_json(sp, {"version": 1, "dates": {}})
    if not isinstance(st.get("dates"), dict):
        st = {"version": 1, "dates": {}}
    prev = st["dates"].get(day) or {}
    if prev.get("sourceHash") == src["sourceHash"] and not force:
        return {"ok": True, "skipped": f"{day} は同じ中身をもう書き出しています", "written": []}
    prev_notes = [n for n in prev.get("notes", []) if isinstance(n, dict) and n.get("file")]
    prev_files = {n["file"]: n for n in prev_notes}

    # ファイル名（前に自分が書いたもの以外とはぶつけない）
    taken: set[str] = set()
    for n in notes:
        base = f"{day}_{n['title']}"
        name, k = f"{base}.md", 2
        while name in taken or ((dest / name).exists() and name not in prev_files):
            name, k = f"{base}_{k}.md", k + 1
        taken.add(name)
        n["file"] = name
        safe_file(dest, vroot, name)
    log: list[str] = []
    dest.mkdir(parents=True, exist_ok=True)
    if not inside(dest.resolve(), vroot):
        raise WriteError(f"書き出し先が保管庫の外を指しています: {dest}")
    written, new_notes = [], []
    for n in notes:
        siblings = [Path(o["file"]).stem for o in notes if o is not n]
        text = build_note(cfg, src, n, siblings)
        p = safe_file(dest, vroot, n["file"])
        if p.exists():
            rec = prev_files.get(n["file"])
            if rec is None or not is_ours(p, source):
                raise WriteError(f"自分が書いたものではないので上書きしません: {p}")
            if file_sha(p) != rec.get("sha256"):
                stash(p, ddir, f"手で直された形跡があるので上書きの前に控え（{p.name}）", log)
        write_atomic(p, text)
        written.append(str(p))
        new_notes.append({"file": n["file"], "title": n["title"], "sha256": oc.sha(text), "items": n["items"]})
    # 前回あって今回なくなったノートは控えへ移す（手で直されていたら残す）
    for n in prev_notes:
        if n["file"] in taken:
            continue
        try:
            p = safe_file(dest, vroot, n["file"])
        except WriteError:
            continue
        if not p.exists():
            continue
        if file_sha(p) == n.get("sha256") and is_ours(p, source):
            stash(p, ddir, f"題名が変わったので前のノートを片付け（{p.name}）", log)
            p.unlink()
        else:
            log.append(f"前のノートが手で直されているので残しました: {p}")
    st["dates"][day] = {"exportedAt": datetime.now().astimezone().isoformat(timespec="seconds"),
                        "sourceHash": src["sourceHash"], "notes": new_notes}
    oc.save_json(sp, st)
    return {"ok": True, "day": day, "written": written, "log": log}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="要約済みの JSON を Obsidian の保管庫へ書き出す")
    ap.add_argument("--notes", required=True, help="要約の JSON（<日>.notes.json）")
    ap.add_argument("--force", action="store_true", help="同じ中身をもう書いていても出し直す")
    ap.add_argument("--data-dir", help="データ置き場（既定は MYAI_DATA_DIR か ~/.my-ai-assistant）")
    a = ap.parse_args(argv)
    ddir = oc.data_dir(a.data_dir)
    lock = ddir / "obsidian" / "write.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    with lock.open("w") as lk:
        try:
            fcntl.flock(lk, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            print(json.dumps({"ok": False, "error": "別の書き出しが動いているので終わります"}, ensure_ascii=False))
            return 3
        try:
            data = json.loads(Path(a.notes).read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise WriteError("要約の JSON の形が違います")
            res = write_day(ddir, data, a.force)
        except (WriteError, OSError, ValueError) as e:
            print(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False))
            return 1
    print(json.dumps(res, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
