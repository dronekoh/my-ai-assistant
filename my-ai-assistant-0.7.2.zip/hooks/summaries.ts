// 「待っていること」と会話タイトルの要約（A5）。register.tsx の startJob から呼ぶ。
// サーバー（server/apps.py）が、決まった言い回しで拾えなかったものだけを1件1回、待ち行列に積む（mode: summary）。
// ここでは $.model.complete（haiku・effort low・短い max）で1行を作って返すだけ。結果を覚えるのはサーバー（summaries.json）。
// 使用量に響くので、1時間に SUMMARY_MAX_PER_HOUR 回まで（サーバー側にも上限がある）。会話には入れない。
import type { EngineInterface } from 'claude-code'

export const SUMMARY_MODE = 'summary'
export const SUMMARY_MODEL = 'haiku'
export const SUMMARY_MAX_PER_HOUR = 20
export const SUMMARY_MAX_TOKENS = 120
export const SUMMARY_MATERIAL_MAX = 2500 // 材料の長さ（末尾）
export const SUMMARY_CAP_TEXT = '1時間の回数の上限です' // サーバーはこの言葉（回数の上限）を見て、覚えずにあとで頼み直す
export const WAIT_MAX = 80
export const TITLE_MAX = 18

export const WAIT_SYSTEM = [
  'あなたは、Claude との会話で「いま利用者が何をすればよいか」を1行にまとめる係です。渡されるのは、Claude の最後の返事です。',
  '- 利用者にしてほしいこと（答える・選ぶ・確かめる・手で作業して知らせる など）を、全角60字以内の1文で出す',
  '- 「〜して『〜』と送る」「〜を選ぶ（A／B）」のように、利用者がやる動作で終える（です・ます・ください は付けない）',
  '- 人名・案件名・画面名・数字など、何の話か分かる固有名詞は残す。返事に書かれていないことは足さない',
  '- 求めていることが読み取れなければ「なし」とだけ出す',
  '- 説明・前置き・かぎかっこでの囲み・記号の飾りは付けない',
].join('\n')

export const TITLE_SYSTEM = [
  'あなたは、会話を一覧に出す短いタイトルに要約する係です。渡されるのは、利用者の最初の依頼（古い順）です。',
  '- 全角18字以内の名詞句を1つだけ出力する（説明・かっこ書き・記号の飾り・句点は付けない）',
  '- いちばん中心の用件を選ぶ。「いまどう？」のような様子見や合いの手は用件として扱わない',
  '- 人名・案件名・ファイル名など、あとで探す手がかりになる固有名詞は残す',
].join('\n')

// サーバーが積む依頼の形（server.py の enqueue_summary）
export type SummaryJob = {
  id: string
  mode?: string
  summaryKind?: string
  material?: string
}

export type SummaryAsk = { system: string; prompt: string }

// 依頼から、モデルに渡す指示と本文を作る。形がおかしければ null
export function summaryAsk(job: SummaryJob): SummaryAsk | null {
  const m = typeof job.material === 'string' ? job.material.trim() : ''
  if (m === '') return null
  const body = m.length > SUMMARY_MATERIAL_MAX ? `（前略）\n${m.slice(-SUMMARY_MATERIAL_MAX)}` : m
  if (job.summaryKind === 'wait') return { system: WAIT_SYSTEM, prompt: `Claude の最後の返事:\n${body}\n\n利用者がすること:` }
  if (job.summaryKind === 'title') return { system: TITLE_SYSTEM, prompt: `利用者の最初の依頼:\n${body}\n\nタイトル:` }
  return null
}

// モデルの答えを1行に整える（1行目だけ・かぎかっこ・句点・Markdown の記号を外す・「なし」は空・長さの上限）
export function cleanSummary(kind: string | undefined, text: string): string {
  const first = (text.trim().split(/\r?\n/)[0] ?? '').trim()
  const line = first
    .replace(/^[\s「『"'*#>`-]+|[\s」』"'。*`]+$/g, '')
    .replace(/\*\*|__|`/g, '')
    .replace(/\s+/g, ' ')
    .trim()
  if (line === '' || line === 'なし') return ''
  const max = kind === 'title' ? TITLE_MAX : WAIT_MAX
  return [...line].slice(0, max).join('')
}

// 作った時刻（1時間の上限）。セッションごとに数え直す
const times: number[] = []
export function resetSummaryTimes(): void {
  times.length = 0
}

// 1件作って send(ok, text) で返す（send は register.tsx の sendResult。「こなした依頼」には数えない）
export async function runSummary($: EngineInterface, job: SummaryJob, send: (ok: boolean, text: string) => Promise<unknown>): Promise<void> {
  const ask = summaryAsk(job)
  if (ask === null) {
    await send(false, '要約の材料がありません')
    return
  }
  const now = await $.clock.now()
  while (times.length > 0 && now - (times[0] ?? 0) >= 3_600_000) times.shift()
  if (times.length >= SUMMARY_MAX_PER_HOUR) {
    await send(false, SUMMARY_CAP_TEXT)
    return
  }
  times.push(now)
  try {
    const r = await $.model.complete({
      model: SUMMARY_MODEL,
      system: ask.system,
      prompt: ask.prompt,
      maxTokens: SUMMARY_MAX_TOKENS,
      effort: 'low',
      timeoutMs: 20_000,
    })
    if (r.isAnswered) await send(true, cleanSummary(job.summaryKind, r.text))
    else await send(false, `作れませんでした: ${r.reason}`)
  } catch (err) {
    await send(false, `作れませんでした: ${String(err).slice(0, 80)}`)
  }
}
