// ops.mjs の型（プラグインの試験が読む）
export const WEB_LIMITS: { sendText: number; attachFiles: number; attachBase64Chars: number; settingsBody: number; queryChars: number; respBytes: number; timeoutMs: number }
export function isRunRequest(text: string): boolean
export function classify(method: string, pathname: string): { kind: string; check?: (body: unknown) => unknown } | null
export function makeHandlers(o: { base: string; log: { write: (r: { browser: unknown; kind: string; bytes: number; result: string }) => unknown }; fetchImpl?: (u: string, init?: unknown) => Promise<{ status: number; arrayBuffer: () => Promise<ArrayBufferLike> }> }): {
  api: (args: unknown, ctx?: { browser?: { name?: string }; bytes?: number }) => Promise<{ status: number; body: unknown }>
}
