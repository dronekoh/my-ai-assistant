# My AI Assistant（my-ai-assistant プラグイン・試作）

自分の Claude の Code タブの会話を「執行役」にして、ブラウザの画面から頼んだり、部署（企画・調査・プログラマーなど）に仕事を任せたりするプラグインです。

- 画面から文を送ると、いま開いている Claude の会話に入り、執行役が答えます（使用量は自分のプランから引かれます）。
- 執行役は、必要なら部署に仕事を任せます。任せた仕事は画面の仕事一覧に出ます。1つだけ止める・全部止めることもできます。
- `claude -p` を別に動かしません。会話を閉じると、画面も止まります。

## 前提

- Claude Code 2.1.275 以降（Claude アプリの Code タブ、またはターミナルの Claude Code）
- Python 3.8 以上
- （Web 版を使うときだけ）node 22 以降
  - Mac: ターミナルで `xcode-select --install`（すでに入っていれば不要）。python.org の公式インストーラ、または Homebrew（`brew install python`）でもよい
  - Windows: python.org の公式インストーラで入れる（「Add python.exe to PATH」にチェック）。`py` ランチャー（`py -3`）が入っていれば、プラグインが自動で見つける

## 入れる

### 招待なしで入れる（Web に置いた marketplace.json の URL から）

git も GitHub のアカウントも要りません（Claude Code 2.1.224 以降）。Claude Code の中で次の2行を打ちます。置き場所は配布者の GitHub Pages（https://dronekoh.github.io/my-ai-assistant/）です。

```
/plugin marketplace add https://dronekoh.github.io/my-ai-assistant/marketplace.json
/plugin install my-ai-assistant@my-ai-assistant-marketplace
```

ターミナルから直接なら `claude plugin marketplace add https://dronekoh.github.io/my-ai-assistant/marketplace.json` のあと `claude plugin install my-ai-assistant@my-ai-assistant-marketplace` です。入れたら新しい会話を開きます。

### 開発者・招待された人向け（GitHub から入れる）

1. ターミナル、または Claude Code の中で、次の1行を打つ。

   ```
   /plugin install my-ai-assistant --marketplace dronekoh/koh-assistant-plugin
   ```

   ターミナルから直接なら `claude plugin install my-ai-assistant --marketplace dronekoh/koh-assistant-plugin` です。
2. 新しい会話を開く。

### 旧名（koh-assistant）から移る（v0.2.0 で名前が変わりました）

名前が変わったので、`claude plugin update` では移れません。入れ直します。次の順に打ちます。入れ方（`--scope`）は、旧版を入れたときと同じにしてください（下は local の例）。

```
claude plugin uninstall koh-assistant@koh-assistant-marketplace --scope local
claude plugin marketplace remove koh-assistant-marketplace
claude plugin marketplace add dronekoh/koh-assistant-plugin
claude plugin install my-ai-assistant@my-ai-assistant-marketplace
```

入れ直したら、新しい会話を開きます。

- 履歴の索引と添付（`~/.koh-assistant/`）は、新しい版の画面サーバーが最初に起動したとき、`~/.my-ai-assistant/` へ**コピー**されます。元のフォルダは消しません。不要になったら自分で消してください。
- 画面の設定（テーマ・キャラの選択など）は、画面を開いたときに旧い設定から写されます。
- 設定「アシスタント」の保存（表示名・部署の追加など）は引き継がれません。開いて入れ直してください。

GitHub から入れる場合、リポジトリが非公開の間は、そのリポジトリを読める権限が要ります。次のどちらか一方でかまいません。

- `gh auth login` のあとに `gh auth setup-git` を実行する
- SSH 鍵を GitHub に登録する（鍵が無い人は `CLAUDE_CODE_PLUGIN_PREFER_HTTPS=1` を設定する）

## 自動で新しい版にする（おすすめ）

配布者が配る棚（marketplace）は、自動更新が最初は切れています。一度だけ入れます。

1. Claude Code で `/plugin` を開く。
2. Marketplaces → `my-ai-assistant-marketplace` を選ぶ。
3. Enable auto-update を選ぶ。

入れなかった人は、次のどちらかで手で更新します。

```
claude plugin update my-ai-assistant@my-ai-assistant-marketplace
```

または Claude Code の中で `/plugin marketplace update my-ai-assistant-marketplace`。

新しい版は、自動更新を入れた人には次の会話の最初のあと（最大10分ほど）に取り込まれ、「Run /reload-plugins to apply」と出ます。`/reload-plugins` を打つか、次に起動したときから新しい版になります。

## 使い方

1. Code タブで新しい会話を開く。
2. 「My AI Assistant」のペインが出る（出ないときは `/my-ai-assistant` と打つ）。
3. ペインの「画面を開く」を押す。ブラウザで http://127.0.0.1:8790/ が開く。
4. 入力欄に頼みを書いて送る。執行役が答えます。ファイルや画像は、ボタン・ドラッグ・貼り付けで添えられます。
5. 部署に任せた仕事は、画面の仕事一覧（☰）で見る。止めたい仕事の「この仕事を止める」、または「全部止める」を押す。

画面から頼むときは、会話にそのまま入れる形（chat モード）が標準です。執行役が自分で判断して部署に任せます。

### 設定（「アシスタント」タブ）

画面の右上の設定 → 「アシスタント」タブで、次を変えられます。保存すると次の発言から使われます。

- 表示名（空にすると既定に戻る）
- 執行役への追加の指示（口調・得意分野など。空にすると何も足さない）
- 部署（追加・削除・編集。「既定の部署に戻す」→ 保存で、プラグインに入っている既定に戻る）

### Web 版（ブラウザで開く画面。試作・既定は使わない）

自分のパソコンの Claude を、別の場所のブラウザから使うための機能です。ブラウザで Web の画面を開き、ペアリングでパソコンとつなぎます。中継（Supabase の Broadcast）を通りますが、依頼も答えもブラウザとパソコンの間で暗号化され、中継は中身を読めません。ログインはありません。**ペアリングしたブラウザだけが使えます**。

- Web の画面の URL（置き場所は仮）: **https://dronekoh.github.io/my-ai-assistant/app/**
- 前提: パソコン側に **node 22 以降**（Web 版を使うときだけ。標準の WebSocket を使うため 18 や 20 では動きません）。ブラウザ側は新しめの Chrome / Edge / Safari / Firefox
- 流れ（最初の1回だけ）:
  1. パソコンの Claude Code の会話（画面を持っている会話）の**入力欄**に `/my-ai-assistant web-on` → `/my-ai-assistant web-pair` を打つ（画面の「▶ 実行」やターミナルではありません）。ペインに**8桁の番号**が出る（5分で失効・1回きり）
  2. ブラウザで Web の画面の URL を開く → 「ペアリング」の画面に**8桁の番号**を入れて「つなぐ」
  3. ブラウザに**確認用の6桁**が大きく出る。パソコンの Claude Code に同じ6桁が出ているので見比べる（Claude の質問「ブラウザに出ている6桁は ○○○○○○ ですか？」か、ペインの「確認用の6桁」）。**同じなら、パソコン側で「一致（登録する）」を押す**（質問でも、ペインのボタンでも、`/my-ai-assistant web-ok` でもよい。先に答えた方が使われます。待ち時間は3分）。違えば「違う（登録しない）」（`web-ng`）。違うと登録されず、番号も捨てられます。必ず見比べてください
  4. 登録されると、ブラウザは本来の画面（会話・仕事一覧・3D オフィス・履歴・設定）に変わる。2回目からは番号は要りません（鍵はこのブラウザの中に、取り出せない形で保存されます）
- 画面の上に「パソコン: つながっている／つながっていない（最後の合図から N 秒）」が出ます。つながっていないあいだは送信できません（入力欄に理由が出ます）。パソコンが閉じている・Claude Code の会話が開いていないときは「つながっていない」になります
- 「パソコン:」の表示を押すと「このブラウザの登録を消す」が出ます。パソコン側の登録も消すには `/my-ai-assistant web-revoke 名前`（一覧は `web-list`）
- すぐ切る: `/my-ai-assistant web-off`（または、ペインの「Web をすぐ切る」）。橋渡しを止め、設定を「使わない」に戻します。止まらないときは数秒後に子プロセスを止め、止まるとペインに出ます
- ペインに「Web: 使わない / 待機中 / つながっている（ブラウザ名）/ 操作中」が出ます。Web からの操作は `~/.my-ai-assistant/web/log.jsonl` に残ります（時刻・ブラウザ名・操作の種類・大きさ。依頼の本文は書きません）
- Web から使えるのは、状態を見る・依頼（chat）・止める・履歴検索・設定だけです。**▶ 実行、ファイルを開く・Finder で表示、ファイルの送り返し、入力の予測、やり直し（再送）は Web の画面では出ません**（パソコン側でも断ります）。添付は5件・合計 約640KBまで
- 設定の保存は、パソコン側が保存したかの確認ができないので、少し待って画面が設定を読み直します（保存されていなければ、読み直した値が元のままです）
- スマホでも開けます（画面の幅に合わせた見た目）
- 権限の確認を飛ばす設定（bypass）では使わないでください。Web からの依頼も、Claude 側の権限の確認を通ります
- Web の画面の作り方・置き方は `docs/release.md` の「4c」

### 「使うフォルダ」を足す

執行役や部署が、いまの作業フォルダの外のフォルダも読み書きするには、Claude Code 側で足します。プラグインからは足せません。

- 会話の中で `/add-dir <フォルダのパス>` を打つ。
- ターミナルから起動するときは `claude --add-dir <フォルダのパス>` を付ける。

## データと安全

- 画面は 127.0.0.1 だけで待ち受けます。同じネットワークの別の機械からは届きません。
- 履歴検索の索引と添付ファイルは、自分の PC の `~/.my-ai-assistant/`（Windows はホームフォルダの `.my-ai-assistant`）に置きます。外には送りません。
- 画面の「▶ 実行」は、その場でコマンドを実行しません。「次を実行して」という頼みを会話に入れ、Claude 側の確認（Bash の許可）を通して実行します。
- 許可を自動で出す仕組みはありません。確認は Claude 側の画面に出ます。

## できないこと

- 会話の分岐（`< 1/2 >`）。やり直したいときは Claude アプリの巻き戻し（ターミナルでは Esc を2回）を使う。画面の「編集」は、下書きを入力欄に戻すだけです。
- 画面から許可を出すこと。許可は Claude 側の確認で出す。画面は「Claude 側で確認待ちかもしれません」と知らせるだけです。
- ほかの会話の一覧（Code タブの会話・Cowork・定期タスク）を出すこと。

## よくある詰まり

- **Python が無い**: ペインに python.org の案内が出る。上の「前提」のとおり入れて、新しい会話を開き直す。
- **8790 を別のプログラムが使っている**: ペインにエラーが出る。そのプログラムを止めて、新しい会話を開き直す。
- **別の会話が画面を持っている**: ペインに「別のセッションがすでに 8790 で画面を出しています」と出る。同じ画面を使えます（頼みは、画面を持つ会話に入る）。持っている会話を閉じると、このセッションが引き継ぎます。
- **古い版の会話が残っている**: 更新したあと、開いたままの古い会話は数秒で新しい版に切り替わる。切り替わらなければ `/reload-plugins` を打つか、会話を開き直す。

## 開発者向け

自分の PC で、入れずに試す。

```
claude --plugin-dir <このフォルダのパス>
```

その会話の間だけ有効で、普段の設定には何も残りません。

テストと確認（このフォルダで実行）:

```
claude plugin validate .
claude plugin test .
npx -y -p typescript tsc --noEmit -p .
python3 tests/check_server.py 8791
node tests/bridge.test.mjs        # Web 版の橋渡し（本物の Supabase の Broadcast を使う。node 22 以降が要る）
node tests/web.test.mjs           # Web の画面（dist/web を build し、ペアリングから依頼まで通す。8791・8802 を使う）
```

- `claude plugin test .` と `tsc` には、`.claude-plugin/types`（Claude Code の型定義）が要ります。無いときは、型定義のあるフォルダへのリンクを張ります（`ln -s <型定義のフォルダ> .claude-plugin/types`）。`.gitignore` に入っているので commit されません。
- `tests/check_server.py` は別ポート（8791）でサーバーを起動して確かめます。8790 と 8787 は使いません。
- 版を上げる手順は `docs/release.md`、もう1台の PC での確認表は `docs/checklist.md` を見る。

## 中身

```
.claude-plugin/plugin.json       プラグインの名前と版（version）
.claude-plugin/marketplace.json  配布用の棚（このリポジトリ自体が棚になる）
hooks/hooks.json                 本体の場所
hooks/register.tsx               本体（サーバーの起動・依頼の受け渡し・ペイン・部署）
config/org.json                  部署と表示名の既定
server/server.py                 画面のサーバー（Python 標準ライブラリだけ・127.0.0.1:8790）
server/index.html                画面
server/history.py                履歴検索
bridge/                          Web 版の橋渡し（node。暗号化・ペアリング・許可リスト）
web/                             Web の画面の追加部分（ペアリング画面・中継の窓口・つながりの表示）。画面本体は server/index.html から作る
web-proto/lib/                   暗号と中継の部品（ブラウザと node で共通）
config/web.json                  Web 版の中継の接続設定（Supabase の URL と公開用キー）
tests/                           自動テスト
scripts/build_release.py         Web に置く版（zip と marketplace.json）を dist/ に作る
scripts/build_web.py             Web の画面（静的ファイル）を dist/web/ に作る
docs/                            手順書と確認表
```
