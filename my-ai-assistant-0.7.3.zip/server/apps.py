"""Claude アプリの一覧（A5: Code タブの会話・Cowork・定期タスク）と、「待っていること」・会話タイトルの要約。

読むもの（すべて読むだけ・アプリのファイルは書かない。Mac のアプリのフォルダが無ければ、この機能は出さない）:
  1. Code タブの会話   <アプリ>/claude-code-sessions/*/*/local_*.json ＋ 会話ログ <設定フォルダ>/projects/*/<cliSessionId>.jsonl
  2. Cowork            <アプリ>/local-agent-mode-sessions/*/*/local_*.json ＋ 作業ログ 同じフォルダ/<sessionId>/audit.jsonl
  3. 定期タスク        <アプリ>/*/*/*/scheduled-tasks.json（cron・有効/無効・フォルダ・権限）＋ SKILL.md（説明・手順。
                       <設定フォルダ>/scheduled-tasks と ~/Documents/Claude/Scheduled）＋ 実行の記録 local_*.json（履歴）
                       ＋ アプリのログ ~/Library/Logs/Claude/main.log（ずれ幅）
  <アプリ> は ~/Library/Application Support/Claude、<設定フォルダ> は CLAUDE_CONFIG_DIR があればそれ、無ければ ~/.claude。

「待っていること」（返答待ちの会話で、利用者に何を求めているか）と、題名の無い会話のタイトル:
  - まず決まった言い回し（〜してください・〜ますか？・次にやること： など）で拾う（速い・無料）
  - 拾えないものだけ、1件につき1回、プラグインに頼む（サーバーが待ち行列に積む → プラグインが $.model.complete で作って返す）
  - 結果は <データ置き場>/summaries.json に覚え、同じものは作り直さない。失敗も覚える（再挑戦しない）
  - 頼む回数は1時間 MAX_PER_HOUR 回まで（使用量に響くため）。プラグイン側にも同じ上限がある
次回の実行・抜けた回の計算は、アプリ本体（ScheduledTasks）と同じ手順をなぞる。
"""
from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

WORKING_SEC = 90             # ログがこの秒数以内に動いていれば「作業中」
WAITING_SEC = 2 * 3600       # 返答待ちとみなす上限
SHOW_WITHIN_SEC = 24 * 3600  # これより古い会話は出さない
TAIL_BYTES = 200_000
SESSION_CACHE_SEC = 3.0
TASK_CACHE_SEC = 60.0
MAX_SESSIONS = 80
HISTORY_LIMIT = 10
SKIP_MATCH_MS = 120_000      # アプリと同じ（2分以内なら同じ回とみなす）
LOOKBACK_MS = 7 * 86400_000  # アプリはスキップを7日分だけ見る
JITTER_MAX_MIN = 14          # アプリのずれ幅の上限（0〜14分）

# 要約（プラグインに頼む）
MAX_PER_HOUR = 20            # 1時間に頼む回数の上限（プラグイン側 hooks/summaries.ts にも上限がある）
PENDING_SEC = 10 * 60        # 頼んだまま答えが来ないときは、この秒数のあとで頼み直せる
KEEP_SEC = 7 * 86400         # 覚えた結果を残す日数
MAX_KEEP = 2000
MATERIAL_MAX = 2500          # プラグインへ渡す材料の長さ（末尾）
WAIT_MAX = 80                # 「待っていること」の長さの上限
TITLE_MAX = 18               # 会話タイトルの長さの上限
CAP_MARK = "回数の上限"       # プラグインが上限で断ったときの答えに入る言葉（覚えずに、あとで頼み直す）

SKIP_REASON_JA = {
    "per_task_limit": "前の回がまだ動いていた",
    "global_limit": "同時に動かせる数の上限",
    "sign_in_required": "サインインが必要だった",
    "host_unavailable": "実行先につながらなかった",
    "host_not_allowed": "実行先が許可されていない",
    "connection_removed": "接続が外されていた",
    "folder_not_trusted": "フォルダが信頼されていない",
    "folder_missing": "フォルダが見つからない",
    "start_failed": "起動に失敗した",
    "not_available": "この環境では使えない",
    "not_run_before_update": "アプリ更新前に実行されなかった",
}
PERMISSION_JA = {
    "auto": "自動承認",
    "acceptEdits": "編集だけ自動承認",
    "bypassPermissions": "すべて許可（確認なし）",
    "plan": "計画モード",
    "default": "毎回確認",
}
WEEK_JA = "日月火水木金土"

_cfg: dict = {"data_dir": None, "enqueue": None}


def configure(data_dir, enqueue=None) -> None:
    """data_dir: summaries.json の置き場。enqueue(kind, key, material) -> bool: プラグインへ要約を頼む（server.py が渡す）"""
    _cfg["data_dir"] = Path(data_dir) if data_dir else None
    _cfg["enqueue"] = enqueue


# ---------- 場所（ホームから作る。決め打ちしない） ----------

def app_dir() -> Path:
    return Path.home() / "Library" / "Application Support" / "Claude"


def claude_dir() -> Path:
    return Path(os.environ.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude"))


def cowork_tasks_dir() -> Path:
    return Path.home() / "Documents" / "Claude" / "Scheduled"


def app_logs() -> list[Path]:
    base = Path.home() / "Library" / "Logs" / "Claude"
    return [base / "main.log", base / "main1.log"]


def enabled() -> bool:
    """Mac で、アプリのフォルダ（Code タブか Cowork のもの）があるときだけ出す。Windows・Linux・アプリ無しでは出さない"""
    if sys.platform != "darwin":
        return False
    a = app_dir()
    return (a / "claude-code-sessions").is_dir() or (a / "local-agent-mode-sessions").is_dir()


def _glob(pattern_base: Path, pattern: str) -> list[str]:
    return glob.glob(os.path.join(glob.escape(str(pattern_base)), pattern))


# ---------- 小道具 ----------

def now_ms() -> int:
    return int(time.time() * 1000)


def iso(ms) -> str | None:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat() if ms else None


def local_iso(ms) -> str | None:
    return datetime.fromtimestamp(ms / 1000).astimezone().isoformat() if ms else None


def local_dt(ms: int) -> datetime:
    return datetime.fromtimestamp(ms / 1000)


def to_ms(v) -> int:
    """'1792145404940' / 1792145404940 / ISO文字列 → epoch ms"""
    if v is None or isinstance(v, bool):
        return 0
    if isinstance(v, (int, float)):
        return int(v)
    s = str(v)
    if s.isdigit():
        return int(s)
    try:
        return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp() * 1000)
    except ValueError:
        return 0


def read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def tail_lines(path, nbytes: int = TAIL_BYTES) -> list[str]:
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as f:
            if size > nbytes:
                f.seek(size - nbytes)
                f.readline()  # 途中の行を捨てる
            data = f.read()
        return data.decode("utf-8", errors="replace").splitlines()
    except Exception:
        return []


def head_lines(path, nbytes: int = 64_000) -> list[str]:
    try:
        with open(path, "rb") as f:
            data = f.read(nbytes)
        return data.decode("utf-8", errors="replace").splitlines()[:-1] or []
    except Exception:
        return []


def short(s, n: int = 120) -> str:
    if not s:
        return ""
    s = re.sub(r"\s+", " ", str(s)).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def strip_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s or "")


def home_short(p):
    """ホームフォルダ（利用者名を含む）を ~ にして出す（Web 向け）"""
    if not isinstance(p, str) or not p:
        return p
    h = str(Path.home())
    if p == h:
        return "~"
    return "~" + p[len(h):] if p.startswith(h.rstrip("/") + "/") else p


def tool_summary(block: dict) -> str:
    name = block.get("name", "")
    inp = block.get("input") or {}
    hint = ""
    if isinstance(inp, dict):
        for k in ("description", "command", "file_path", "query", "pattern", "url", "prompt"):
            if inp.get(k):
                hint = str(inp[k])
                break
    name = re.sub(r"^mcp__.+?__", "", name)  # mcp__<サーバー>__ を外して道具名だけに
    return short(f"{name} {hint}".strip(), 90)


def when_ja(ms, now: int | None = None) -> str:
    """今日の14:09 / 昨日の20:09 / 明日の10:09 / 10/17 14:09"""
    if not ms:
        return "不明"
    d, n = local_dt(ms), local_dt(now or now_ms())
    diff = (d.date() - n.date()).days
    hm = d.strftime("%H:%M")
    return {0: f"今日の{hm}", -1: f"昨日の{hm}", 1: f"明日の{hm}"}.get(diff, f"{d.month}/{d.day} {hm}")


# ---------- 返答待ちの判定（利用者がやることが残っているか） ----------
# waiting にするのは、利用者が答える・選ぶ・確認する・OK を出す・手で作業する必要があるときだけ。

WRAP_UP_TOOL = "mcp__ccd_turn__wrap_up"
QUESTION_TOOLS = {"AskUserQuestion", "ExitPlanMode"}
_ASK_PATTERNS = [
    r"(ます|です|でしょう|ません)か[？?]",
    r"[？?]\s*$",
    r"(選んで|返して|教えて|決めて|押して|貼って|送って|入れて|開いて|答えて)ください",
    r"(確認|返信|返事|承認|判断|指示|連絡|選択|実行|ログイン|操作)して(ください|もらえ)",
    r"(OK|ＯＫ|ok|了承|許可|返事|返信|判断|確認|指示|承認)\s*を?\s*(ください|お願い)",
    r"ご(確認|判断|指示|返信|連絡)(ください|をお願い)",
    r"お知らせください",
]
# 「必要なら〜」「〜するときは〜」のような任意の一言は、やることに数えない
_OPTIONAL_PATTERNS = r"(必要(なら|であれば|があれば|な場合)|あれば|ときは|時は|場合は|いつでも|また同じ|今後)"


def text_asks_user(text, last_lines: int = 3) -> bool:
    if not text:
        return False
    lines = [ln.strip() for ln in text.strip().splitlines() if ln.strip()]
    for ln in lines[-last_lines:]:
        if re.search(_OPTIONAL_PATTERNS, ln) and not re.search(r"[？?]\s*$", ln):
            continue
        if any(re.search(p, ln) for p in _ASK_PATTERNS):
            return True
    return False


def user_has_todo(blocks: list[dict]):
    """最後に利用者が書いてから後の assistant の発言（道具の呼び出しを含む）から判断する"""
    if not blocks:
        return None
    for b in reversed(blocks):  # 締めの道具（wrap_up）があれば、その引数で決める
        if b.get("type") == "tool_use" and b.get("name") == WRAP_UP_TOOL:
            inp = b.get("input") if isinstance(b.get("input"), dict) else {}
            return bool(inp.get("blocked")) or bool(str(inp.get("ask") or "").strip())
    last = blocks[-1]
    if last.get("type") == "tool_use" and last.get("name") in QUESTION_TOOLS:
        return True
    for b in reversed(blocks):
        if b.get("type") == "text":
            return text_asks_user(b.get("text"))
    return False


# ---------- 「待っていること」を言い回しで拾う ----------

_ASK = [
    r"(ます|です|でしょう|ません|ましょう)か[。]?$",
    r"[？?]」?$",
    r"ください",
    r"(OK|ＯＫ|ok|了承|許可|返事|返信|判断|確認|指示|承認)\s*を?\s*(ください|お願い)",
    r"お願いします",
    r"お知らせください",
]
_NEXT_HEAD = r"^(次にやること|次にやってほしいこと|あなたにやってほしいこと|お願い|お願いしたいこと|次の一手|次は)\s*[:：]?$"
_NEXT_INLINE = r"^(次にやること|次は|お願いしたいこと)\s*[:：]\s*\S"
_OPTIONAL = r"(必要(なら|であれば|があれば|な場合)|あれば|ければ|ときは|時は|場合は|いつでも|また同じ|今後)"


def plain(s: str) -> str:
    """Markdown の記号を外す（**太字**・# 見出し・> 引用・箇条書きの頭・`コード`・[文字](URL)・表の |）"""
    s = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", s)
    s = re.sub(r"^[ \t]*#{1,6}[ \t]+", "", s)
    s = re.sub(r"^[ \t]*>[ \t]?", "", s)
    s = re.sub(r"^[ \t]*(?:[-*+・]|\d+[.)．])[ \t]+", "", s)
    s = s.replace("**", "").replace("__", "").replace("`", "")
    s = re.sub(r"^\|+|\|+$", "", s.strip()).replace("|", " ／ ")
    return re.sub(r"\s+", " ", s).strip()


def _lines(text: str) -> list[str]:
    out, in_code = [], False
    for ln in (text or "").splitlines():
        if ln.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code or re.fullmatch(r"\s*\|?[\s:|-]+\|?\s*", ln or "x") or not ln.strip():
            continue
        p = plain(ln)
        if p:
            out.append(p)
    return out


def _sentences(line: str) -> list[str]:
    parts = re.split(r"(?<=[。！？!?])(?![」』）)])", line)
    return [p.strip() for p in parts if p.strip()]


def _is_ask(s: str) -> bool:
    if re.search(_OPTIONAL, s) and not re.search(r"[？?]」?$", s):
        return False
    return any(re.search(p, s) for p in _ASK)


def _cut(s, n: int = WAIT_MAX) -> str:
    s = re.sub(r"\s+", " ", s or "").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def from_rules(text) -> str:
    """最後の返事から、利用者に求めていることを言い回しで拾う。拾えなければ空"""
    tail = _lines(text or "")[-12:]
    if not tail:
        return ""
    for i in range(len(tail) - 1, -1, -1):  # 1) 「次にやること：」の見出し
        if re.search(_NEXT_HEAD, tail[i]) and i + 1 < len(tail):
            body = tail[i + 1:i + 4]
            asks = [s for ln in body for s in _sentences(ln) if _is_ask(s)]
            return _cut(" ".join(asks[:2]) if asks else " ／ ".join(body[:2]))
        if re.search(_NEXT_INLINE, tail[i]):
            return _cut(re.sub(r"^[^:：]+[:：]\s*", "", tail[i]))
    sents = [(li, s) for li, ln in enumerate(tail) for s in _sentences(ln)]  # 2) 依頼・質問の文（末尾に近いもの）
    for k in range(len(sents) - 1, -1, -1):
        if _is_ask(sents[k][1]):
            picked = [sents[k][1]]
            if k > 0 and _is_ask(sents[k - 1][1]) and len(sents[k - 1][1]) + len(picked[0]) <= WAIT_MAX:
                picked.insert(0, sents[k - 1][1])
            return _cut(" ".join(picked))
    return ""


def last_paragraph(text) -> str:
    tail = _lines(text or "")
    return _cut(tail[-1]) if tail else ""


def from_question_tool(name, inp) -> str:
    """最後が AskUserQuestion / ExitPlanMode で止まっているとき"""
    if name == "ExitPlanMode":
        return "計画を見て、進めてよいか返事をする"
    qs = (inp or {}).get("questions") if isinstance(inp, dict) else None
    if isinstance(qs, list) and qs and isinstance(qs[0], dict):
        q = plain(str(qs[0].get("question") or ""))
        opts = [str(o.get("label")) for o in (qs[0].get("options") or []) if isinstance(o, dict) and o.get("label")]
        if q:
            return _cut(f"{q}（{' ／ '.join(opts[:4])}）" if opts else q)
    return "質問に答える"


def wait_hint(blocks: list[dict]):
    """(言い回しで拾った文, 最後の返事の全文)。全文はプラグインにまとめてもらう材料（画面には出さない）"""
    if not blocks:
        return None, None
    last = blocks[-1]
    if last.get("type") == "tool_use" and last.get("name") in QUESTION_TOOLS:
        return from_question_tool(last.get("name"), last.get("input")), None
    for b in reversed(blocks):
        if b.get("type") == "text" and b.get("text"):
            return from_rules(b["text"]) or None, b["text"]
    return None, None


# ---------- 1. Code タブの会話 ----------

_log_index: dict = {"at": 0.0, "map": {}}


def index_code_logs() -> dict:
    """cliSessionId → 会話ログのパス（30秒ごとに探し直す）"""
    if time.time() - _log_index["at"] > 30:
        _log_index["map"] = {Path(p).stem: p for p in _glob(claude_dir() / "projects", "*/*.jsonl")}
        _log_index["at"] = time.time()
    return _log_index["map"]


def _user_text(d: dict):
    c = (d.get("message") or {}).get("content")
    if isinstance(c, str):
        return c if not c.startswith("<") else None
    if isinstance(c, list):
        for b in c:
            if isinstance(b, dict) and b.get("type") == "text" and b.get("text") and not b["text"].startswith("<"):
                return b["text"]
    return None


def first_requests(path, n: int = 3) -> list[str]:
    """会話ログの頭から、利用者の最初の依頼を n 件（題名を作る材料）"""
    out = []
    for line in head_lines(path):
        try:
            d = json.loads(line)
        except Exception:
            continue
        if d.get("type") == "user":
            t = _user_text(d)
            if t and t.strip():
                out.append(short(strip_tags(t), 300))
                if len(out) >= n:
                    break
    return out


def parse_code_log(path) -> dict:
    """会話ログの末尾から、直近の動きを拾う"""
    last_tool, last_text, last_user, last_kind = None, "", "", None
    turn: list[dict] = []  # 最後に利用者が書いてから後の assistant の発言と道具
    for line in tail_lines(path):
        try:
            d = json.loads(line)
        except Exception:
            continue
        t = d.get("type")
        if t == "assistant":
            last_kind = "assistant"
            for b in (d.get("message") or {}).get("content") or []:
                if not isinstance(b, dict):
                    continue
                if b.get("type") == "tool_use":
                    last_tool = tool_summary(b)
                    turn.append({"type": "tool_use", "name": b.get("name"), "input": b.get("input")})
                elif b.get("type") == "text" and b.get("text"):
                    turn.append({"type": "text", "text": b["text"]})
                    last_text = b["text"]
        elif t == "user":
            c = (d.get("message") or {}).get("content")
            if isinstance(c, list) and any(isinstance(b, dict) and b.get("type") == "tool_result" for b in c):
                turn.append({"type": "tool_result"})  # 道具の返事は「最後の種別」を変えない
            ut = _user_text(d)
            if ut:
                last_kind, turn, last_user = "user", [], ut
    rule, full = wait_hint(turn) if last_kind == "assistant" else (None, None)
    return {
        "lastTool": last_tool,
        "lastAssistantText": short(last_text, 160),
        "lastUserText": short(strip_tags(last_user), 160),
        "lastKind": last_kind,
        "needsUser": user_has_todo(turn) if last_kind == "assistant" else None,
        "waitRule": rule,
        "waitFull": full,
    }


def load_code_sessions(now: int) -> list[dict]:
    logs = index_code_logs()
    out = []
    cutoff = now - SHOW_WITHIN_SEC * 1000
    for p in _glob(app_dir() / "claude-code-sessions", "*/*/local_*.json"):
        meta = read_json(p)
        if not isinstance(meta, dict) or not meta.get("sessionId") or meta.get("isArchived"):
            continue
        last = to_ms(meta.get("lastActivityAt"))
        log_path = logs.get(meta.get("cliSessionId") or "")
        try:
            log_mtime = int(os.path.getmtime(log_path) * 1000) if log_path else 0
        except OSError:
            log_mtime = 0
        last = max(last, log_mtime)
        if last < cutoff:
            continue
        info = parse_code_log(log_path) if log_path else {}
        wrap = meta.get("turnWrapUp") if isinstance(meta.get("turnWrapUp"), dict) else {}
        prs = meta.get("prs") if isinstance(meta.get("prs"), list) else []
        out.append({
            "id": meta["sessionId"], "source": "code", "title": meta.get("title") or "",
            "cwd": meta.get("cwd"), "model": meta.get("model"), "scheduledTaskId": meta.get("scheduledTaskId"),
            "createdAt": to_ms(meta.get("createdAt")), "lastActivityAt": last, "logMtime": log_mtime,
            "recap": wrap.get("recap"), "ask": wrap.get("ask"),
            "pr": prs[0].get("number") if prs and isinstance(prs[0], dict) else None,
            "link": f"claude://claude.ai/epitaxy/{meta['sessionId']}",
            "_log": log_path, **info,
        })
    return out


# ---------- 2. Cowork ----------

def load_cowork_sessions(now: int) -> list[dict]:
    out = []
    cutoff = now - SHOW_WITHIN_SEC * 1000
    for p in _glob(app_dir() / "local-agent-mode-sessions", "*/*/local_*.json"):
        meta = read_json(p)
        if not isinstance(meta, dict) or not meta.get("sessionId") or meta.get("isArchived"):
            continue
        last = to_ms(meta.get("lastActivityAt"))
        audit = Path(p).with_suffix("") / "audit.jsonl"
        try:
            log_mtime = int(audit.stat().st_mtime * 1000) if audit.exists() else 0
        except OSError:
            log_mtime = 0
        last = max(last, log_mtime)
        if last < cutoff:
            continue
        result_text, last_kind, last_tool = "", None, None
        for line in tail_lines(audit, 60_000) if log_mtime else []:
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("type") == "result":
                result_text, last_kind = d.get("result") or "", "assistant"
            elif d.get("type") == "assistant":
                for b in (d.get("message") or {}).get("content") or []:
                    if isinstance(b, dict) and b.get("type") == "tool_use":
                        last_tool = tool_summary(b)
        out.append({
            "id": meta["sessionId"], "source": "cowork", "title": meta.get("title") or "",
            "cwd": None, "model": meta.get("model"), "scheduledTaskId": meta.get("scheduledTaskId"),
            "createdAt": to_ms(meta.get("createdAt")), "lastActivityAt": last, "logMtime": log_mtime,
            "lastTool": last_tool, "lastAssistantText": short(result_text, 160), "lastKind": last_kind,
            "link": None, "_first": short(str(meta.get("initialMessage") or ""), 300),
        })
    return out


def status_of(s: dict, now: int) -> str:
    age = (now - s.get("lastActivityAt", 0)) / 1000
    if s.get("logMtime") and (now - s["logMtime"]) / 1000 < WORKING_SEC:
        return "working"
    if s.get("ask") and age < WAITING_SEC:
        return "waiting"
    if (s.get("lastKind") == "assistant" and age < WAITING_SEC and s["source"] == "code"
            and not s.get("scheduledTaskId") and s.get("needsUser")):
        return "waiting"
    return "done" if age < SHOW_WITHIN_SEC else "idle"


# ---------- 3. 定期タスク ----------

def _cron_field(s: str, lo: int, hi: int):
    vals: set[int] = set()
    for part in s.split(","):
        step = 1
        if "/" in part:
            part, st = part.split("/", 1)
            step = int(st)
        if part in ("*", ""):
            a, b = lo, hi
        elif "-" in part:
            a, b = (int(x) for x in part.split("-", 1))
        else:
            a = int(part)
            b = hi if step > 1 else a
        vals.update(range(a, b + 1, step))
    return vals, s.startswith("*")


class Cron:
    """アプリと同じ解釈：分 時 日 月 曜日。日と曜日が両方指定なら OR"""

    def __init__(self, expr: str):
        f = expr.split()
        if len(f) != 5:
            raise ValueError(expr)
        self.expr = expr
        self.minute, _ = _cron_field(f[0], 0, 59)
        self.hour, _ = _cron_field(f[1], 0, 23)
        self.dom, self.dom_star = _cron_field(f[2], 1, 31)
        self.month, _ = _cron_field(f[3], 1, 12)
        dow, self.dow_star = _cron_field(f[4], 0, 7)
        self.dow = {0 if x == 7 else x for x in dow}

    def day_ok(self, d: datetime) -> bool:
        if d.month not in self.month:
            return False
        dom_ok, dow_ok = d.day in self.dom, (d.isoweekday() % 7) in self.dow
        if not self.dom_star and not self.dow_star:
            return dom_ok or dow_ok
        return dom_ok and dow_ok

    def match(self, d: datetime) -> bool:
        return d.minute in self.minute and d.hour in self.hour and self.day_ok(d)

    def next_after(self, ms: int):
        """今の分の次の分から、最初に当たる時刻"""
        d = local_dt(ms).replace(second=0, microsecond=0) + timedelta(minutes=1)
        end = d + timedelta(days=366)
        while d < end:
            if not self.day_ok(d):
                d = (d + timedelta(days=1)).replace(hour=0, minute=0)
                continue
            if d.hour not in self.hour:
                d = (d + timedelta(hours=1)).replace(minute=0)
                continue
            if d.minute in self.minute:
                return int(d.timestamp() * 1000)
            d += timedelta(minutes=1)
        return None

    def interval_min(self):
        """今から60分以内に2回当たるときだけ間隔を返す"""
        a = self.next_after(now_ms())
        b = self.next_after(a) if a else None
        if a and b and (b - a) <= 60 * 60_000:
            return round((b - a) / 60_000)
        return None


def _hash_jitter(task_id: str, max_min: int) -> int:
    """アプリは sha256(タスクID) の先頭4バイト % (上限分×60) 秒だけ遅らせて動かす"""
    if max_min <= 0:
        return 0
    return int.from_bytes(hashlib.sha256(task_id.encode()).digest()[:4], "big") % (max_min * 60)


_jlog: dict = {"key": None, "obs": []}


def jitter_observations() -> list:
    """アプリのログから（タスクID, 秒）を新しい順に。ファイルが変わったときだけ読み直す"""
    files = [p for p in app_logs() if p.exists()]
    key = tuple((str(p), p.stat().st_mtime, p.stat().st_size) for p in files)
    if key == _jlog["key"]:
        return _jlog["obs"]
    obs = []
    pat = re.compile(r"Delaying dispatch for (\S+) by (\d+)s \(jitter\)")
    for p in files:
        for line in reversed(tail_lines(p, 6_000_000)):
            m = pat.search(line)
            if m:
                obs.append((m.group(1), int(m.group(2))))
        if obs:
            break
    _jlog.update(key=key, obs=obs)
    return obs


def jitter_max_minutes(crons: dict):
    """ログの実測と矛盾しない上限（分）を、新しい実測から順に絞り込む。決まらなければ None"""
    cands = set(range(1, JITTER_MAX_MIN + 1))
    seen = set()
    for tid, sec in jitter_observations():
        if tid in seen:
            continue
        seen.add(tid)
        c = crons.get(tid)
        iv = c.interval_min() if c else None
        ok = {m for m in cands if _hash_jitter(tid, min(m, iv - 1) if iv else m) == sec}
        if ok:
            cands = ok
        if len(cands) == 1:
            return next(iter(cands))
        if len(seen) >= 6:
            break
    return None


def jitter_seconds(task_id: str, cron, max_min, disabled: bool):
    if disabled or cron is None:
        return 0
    if max_min is None:
        return None
    iv = cron.interval_min()
    return _hash_jitter(task_id, min(max_min, iv - 1) if iv else max_min)


def _hm(h: int, m: int) -> str:
    return f"{h}:{m:02d}"


def _days_ja(dom: str, mon: str, dow: str):
    if mon != "*":
        return None
    if dom == "*" and dow == "*":
        return "毎日"
    if dom == "*":
        if dow == "1-5":
            return "平日（月〜金）"
        if dow in ("0,6", "6,0"):
            return "土日"
        try:
            days, _ = _cron_field(dow, 0, 7)
            return "毎週 " + "・".join(WEEK_JA[d % 7] for d in sorted({x % 7 for x in days}))
        except ValueError:
            return None
    if dow == "*" and dom.isdigit():
        return f"毎月 {dom}日"
    return None


def repeat_ja(expr, fire_at, jitter_sec) -> str:
    if not expr:
        return f"1回だけ（{when_ja(fire_at)}）" if fire_at else "なし（手動で実行するだけ）"
    f = expr.split()
    if len(f) != 5:
        return f"cron: {expr}"
    mi, ho, dom, mon, dow = f
    days = _days_ja(dom, mon, dow)
    shift = round((jitter_sec or 0) / 60)
    approx = "約" if jitter_sec else ""
    if days is None or not mi.isdigit():
        return f"cron: {expr}"
    m = int(mi)
    if ho.isdigit():  # 決まった時刻には、ずれ幅を足して見せる（アプリと同じ）
        t = int(ho) * 60 + m + shift
        txt = f"{days} {_hm(t // 60 % 24, t % 60)}"
        return txt + ("ごろ" if jitter_sec else "") if jitter_sec is not None else txt + "（ずれ幅不明）"
    if ho == "*":
        return f"{approx}毎時 {m:02d}分、{days}"
    if re.fullmatch(r"\d+-\d+", ho):
        a, b = (int(x) for x in ho.split("-"))
        return f"{approx}毎時（{_hm(a, m)}〜{_hm(b, m)} の間）、{days}"
    if re.fullmatch(r"\d+(,\d+)+", ho):
        return f"{days} " + "・".join(_hm(int(h), m) for h in ho.split(",")) + ("ごろ" if jitter_sec else "")
    return f"cron: {expr}"


def read_skill(path: Path):
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return {}, ""
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", text, re.S)
    if not m:
        return {}, text.strip()
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip()
    return fm, m.group(2).strip()


_run_cache: dict = {}


def _audit_result(audit: Path):
    """Cowork の作業ログ末尾の result 行：'ok' / 'error' / None（無い）"""
    if not audit.exists():
        return None
    for line in reversed(tail_lines(audit, 40_000)):
        if '"type":"result"' in line or '"type": "result"' in line:
            try:
                d = json.loads(line)
            except Exception:
                continue
            return "error" if d.get("is_error") or str(d.get("subtype", "")).startswith("error") else "ok"
    return None


def task_runs() -> dict:
    """タスクID → 実行の記録（local_*.json の1件＝1回）。ファイルが変わったときだけ読み直す"""
    out: dict = {}
    seen = set()
    for source, sub in (("code", "claude-code-sessions"), ("cowork", "local-agent-mode-sessions")):
        for p in _glob(app_dir() / sub, "*/*/local_*.json"):
            seen.add(p)
            audit = Path(p).with_suffix("") / "audit.jsonl"
            try:
                mt = (os.path.getmtime(p), audit.stat().st_mtime if audit.exists() else 0)
            except OSError:
                continue
            hit = _run_cache.get(p)
            if not hit or hit[0] != mt:
                meta = read_json(p)
                rec = None
                if isinstance(meta, dict) and meta.get("scheduledTaskId"):
                    pts = meta.get("postTurnSummary") if isinstance(meta.get("postTurnSummary"), dict) else {}
                    rec = {
                        "taskId": meta["scheduledTaskId"], "source": source, "sessionId": meta.get("sessionId"),
                        "createdAt": to_ms(meta.get("createdAt")), "lastActivityAt": to_ms(meta.get("lastActivityAt")),
                        "error": meta.get("error"), "category": pts.get("status_category"),
                        "detail": pts.get("needs_action") or pts.get("status_detail"), "turns": meta.get("completedTurns"),
                        "result": _audit_result(audit) if source == "cowork" else None,
                    }
                _run_cache[p] = (mt, rec)
                hit = _run_cache[p]
            if hit[1]:
                out.setdefault(hit[1]["taskId"], []).append(hit[1])
    for p in [k for k in _run_cache if k not in seen]:
        _run_cache.pop(p, None)
    return out


def run_status(r: dict, now: int):
    if r.get("error"):
        return "失敗", short(str(r["error"]), 160)
    cat = r.get("category")
    if cat == "completed":
        return "完了", r.get("detail") or ""
    if cat == "review_ready":
        return "完了（確認待ち）", r.get("detail") or ""
    if cat == "blocked":
        return "完了（要対応あり）", r.get("detail") or ""
    if r.get("result") == "error":
        return "失敗", "作業ログが失敗で終わっています"
    if r.get("result") == "ok" or int(r.get("turns") or 0) >= 1:
        return "完了", ""
    if now - (r.get("lastActivityAt") or 0) < 5 * 60_000:
        return "実行中", ""
    return "不明", "結果の記録がありません"


def missed_runs(task: dict, cron: Cron, run_starts: list, jitter_ms: int, skips: list, now: int) -> list:
    """予定の回のうち、実行が始まっていない回を「スキップ済み」にする（アプリと同じ手順）"""
    adj = [t - jitter_ms for t in run_starts]
    adj_keys = {local_dt(t).strftime("%Y%m%d%H%M") for t in adj}
    since = to_ms(task.get("createdAt"))
    lsf, lra = to_ms(task.get("lastScheduledFor")), to_ms(task.get("lastRunAt"))
    if lsf and (not lra or lsf > lra):
        since = max(since, lsf)
    floor = max(since, now - LOOKBACK_MS)
    d = local_dt(now).replace(second=0, microsecond=0) - timedelta(minutes=1)
    slots, keys = [], set()
    while int(d.timestamp() * 1000) > floor:
        if cron.match(d):
            ms = int(d.timestamp() * 1000)
            k = d.strftime("%Y%m%d%H%M")
            if not any(abs(t - ms) <= SKIP_MATCH_MS for t in adj) and k not in adj_keys and k not in keys:
                rec = next((s for s in skips if isinstance(s, dict) and abs(to_ms(s.get("at")) - ms) <= SKIP_MATCH_MS), None)
                slots.append({"at": ms + jitter_ms, "reason": rec.get("reason") if rec else None})
                keys.add(k)
        d -= timedelta(minutes=1)
    slots = [s for s in slots if s["at"] <= now]
    if len(slots) <= 1:
        return slots
    kept, r = [slots[0]], slots[0]["at"]
    for s in slots[1:]:  # 続けて抜けた回は、間に実行が無ければ1つにまとめる
        if any(s["at"] < t < r for t in run_starts):
            kept.append(s)
            r = s["at"]
    return kept


def _app_task_configs() -> list:
    """(source, 設定ファイル, タスク設定, recordedSkips) の一覧"""
    out = []
    for source, sub in (("code", "claude-code-sessions"), ("cowork", "local-agent-mode-sessions")):
        for p in _glob(app_dir() / sub, "*/*/scheduled-tasks.json"):
            d = read_json(p)
            if not isinstance(d, dict):
                continue
            skips: dict = {}
            for k in ("recordedSkips", "recordedPlaceSkips"):
                for tid, rows in (d.get(k) or {}).items():
                    skips.setdefault(tid, []).extend(rows if isinstance(rows, list) else [])
            for t in d.get("scheduledTasks") or []:
                if isinstance(t, dict) and t.get("id"):
                    out.append((source, p, t, skips))
    return out


def build_tasks(now: int | None = None) -> list:
    now = now or now_ms()
    runs = task_runs()
    configs = {t["id"]: (src, path, t, sk) for src, path, t, sk in _app_task_configs()}
    crons: dict = {}
    for tid, (_, _, t, _) in configs.items():
        try:
            crons[tid] = Cron(t["cronExpression"]) if t.get("cronExpression") else None
        except (ValueError, KeyError, TypeError):
            crons[tid] = None
    max_min = jitter_max_minutes(crons)

    ids: dict = {}  # SKILL.md があるのに設定に無いタスク（設定から消されたもの）も出す
    for base, source in ((claude_dir() / "scheduled-tasks", "code"), (cowork_tasks_dir(), "cowork")):
        try:
            for d in sorted(base.iterdir()):
                if d.is_dir() and (d / "SKILL.md").exists():
                    ids[d.name] = (source, d / "SKILL.md")
        except OSError:
            pass
    for tid, (src, _, t, _) in configs.items():
        if tid not in ids:
            ids[tid] = (src, Path(t.get("filePath") or ""))

    out = []
    for tid, (source, skill_path) in ids.items():
        src, cfg_path, t, skips = configs.get(tid, (source, None, {}, {}))
        if t.get("filePath"):
            skill_path = Path(t["filePath"])
        fm, prompt = read_skill(skill_path) if str(skill_path) not in ("", ".") else ({}, "")
        cron = crons.get(tid)
        fire_at = to_ms(t.get("fireAt")) or None
        remote = t.get("migratedToRemote") if isinstance(t.get("migratedToRemote"), dict) else None
        enabled_ = t.get("enabled") if t else None
        jit = jitter_seconds(tid, cron, max_min, bool(t.get("disableJitter")))

        next_at, next_note = None, ""
        if remote:
            state, state_label = "cloud", "クラウドで実行"
            next_note = "次回の予定はクラウド側にあり、このパソコンからは読めません"
        elif not t:
            state, state_label = "unknown", "不明（アプリの設定に無い）"
        elif not enabled_:
            state, state_label = "disabled", "無効"
        elif not cron and not fire_at:
            state, state_label = "manual", "有効（手動実行のみ）"
        else:
            state, state_label = "enabled", "有効"
        if state == "enabled":
            if fire_at and not t.get("lastRunAt"):
                next_at = fire_at
            elif cron:
                base_next = cron.next_after(now)
                if base_next and jit is not None:
                    next_at = base_next + jit * 1000
                elif base_next:
                    next_at, next_note = base_next, "予定時刻（実際は最大14分ほど遅れて動く・ずれ幅は不明）"
            if fire_at and t.get("lastRunAt"):
                next_note = "1回だけのタスク。実行済み"

        rs = sorted(runs.get(tid, []), key=lambda r: -r["createdAt"])
        hist = []
        for r in rs:
            st, detail = run_status(r, now)
            hist.append({"at": local_iso(r["createdAt"]), "atMs": r["createdAt"], "label": when_ja(r["createdAt"], now),
                         "kind": "run", "status": st, "detail": detail, "sessionId": r["sessionId"],
                         "link": f"claude://claude.ai/epitaxy/{r['sessionId']}" if r["source"] == "code" else None})
        if state == "enabled" and cron and jit is not None:
            for s in missed_runs(t, cron, [r["createdAt"] for r in rs], jit * 1000, skips.get(tid, []), now):
                hist.append({"at": local_iso(s["at"]), "atMs": s["at"], "label": when_ja(s["at"], now), "kind": "skip",
                             "status": "スキップ済み", "detail": SKIP_REASON_JA.get(s["reason"] or "", s["reason"] or ""),
                             "sessionId": None, "link": None})
        hist.sort(key=lambda h: -h["atMs"])
        hist_note = ""
        if remote:
            hist_note = f"{when_ja(to_ms(t.get('migratedToRemoteAt')), now)} にクラウドへ移りました。それ以降の履歴はこのパソコンから読めません"
        elif state == "enabled" and cron and jit is None:
            hist_note = "ずれ幅が分からないため、スキップした回は出していません"

        folders = [t["cwd"]] if t.get("cwd") else [f for f in (t.get("userSelectedFolders") or []) if isinstance(f, str)]
        pm = t.get("permissionMode")
        if remote:
            before = repeat_ja(t.get("cronExpression"), None, 0) if cron else "なし"
            repeat = f"不明（クラウド側の設定。移る前は「{before}」）"
        elif cron:
            repeat = repeat_ja(t.get("cronExpression"), None, jit)
        elif fire_at:
            repeat = repeat_ja(None, fire_at, None)
        elif t:
            repeat = "なし（手動で実行するだけ）"
        else:
            repeat = "不明"
        last_run = hist[0] if hist else None
        out.append({
            "id": tid, "source": src, "name": t.get("displayName") or fm.get("name") or tid,
            "description": fm.get("description", ""), "prompt": prompt, "enabled": enabled_,
            "state": state, "stateLabel": state_label,
            "nextRunAt": local_iso(next_at), "nextRunLabel": when_ja(next_at, now) if next_at else None, "nextRunNote": next_note,
            "repeat": repeat, "cron": t.get("cronExpression"), "fireAt": local_iso(fire_at), "jitterSeconds": jit,
            "folders": folders, "permissionMode": pm,
            "permissionLabel": PERMISSION_JA.get(pm or "default", pm or "不明") if t else "不明",
            "approvedTools": len(t.get("approvedPermissions") or []), "model": t.get("model"),
            "cloudTriggerId": remote.get("triggerId") if remote else None,
            "history": hist[:HISTORY_LIMIT], "historyNote": hist_note,
            "missed": sum(1 for h in hist[:HISTORY_LIMIT] if h["kind"] == "skip"),
            "lastRun": {"at": last_run["at"], "status": last_run["status"]} if last_run else None,
            "configPath": cfg_path, "skillPath": str(skill_path) if str(skill_path) not in ("", ".") else None,
        })
    rank = {"enabled": 0, "manual": 1, "cloud": 2, "disabled": 3, "unknown": 4}
    out.sort(key=lambda x: (rank.get(x["state"], 9), x["nextRunAt"] or "9", x["name"]))
    return out


# ---------- 要約（プラグインに頼む・結果を覚える） ----------

_slock = threading.Lock()
_store: dict | None = None
_pending: dict = {}       # key → 頼んだ時刻
_asked: list = []         # 頼んだ時刻（1時間の上限）


def _store_path():
    d = _cfg["data_dir"]
    return d / "summaries.json" if d else None


def _load() -> dict:
    global _store
    if _store is None:
        p = _store_path()
        d = read_json(p) if p else None
        _store = d if isinstance(d, dict) else {}
    return _store


def _save() -> None:
    p = _store_path()
    if not p:
        return
    s = _load()
    cutoff = time.time() - KEEP_SEC
    for k in [k for k, v in s.items() if not isinstance(v, dict) or v.get("t", 0) < cutoff]:
        s.pop(k, None)
    if len(s) > MAX_KEEP:
        for k in sorted(s, key=lambda k: s[k].get("t", 0))[: len(s) - MAX_KEEP]:
            s.pop(k, None)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + f".tmp-{os.getpid()}")
    tmp.write_text(json.dumps(s, ensure_ascii=False, indent=0), encoding="utf-8")
    os.replace(tmp, p)


def wait_key(session_id: str, text: str) -> str:
    return f"wait:{session_id}:{hashlib.sha1((text or '').encode('utf-8')).hexdigest()[:16]}"


def title_key(session_id: str) -> str:
    return f"title:{session_id}"


def clean_summary(kind: str, text) -> str:
    """プラグインの答えを整える（1行目だけ・かぎかっこ・句点・記号を外す・「なし」は空・長さの上限）"""
    line = ((str(text or "").strip().splitlines() or [""])[0]).strip(" 「」『』\"'。")
    line = plain(line)
    if line in ("", "なし"):
        return ""
    return line[:TITLE_MAX] if kind == "title" else _cut(line, WAIT_MAX)


def lookup(kind: str, key: str, material: str, ask: bool = True):
    """覚えた結果があれば返す。無ければプラグインに頼んで None（1件1回・1時間の上限つき）。ask=False なら頼まない"""
    enqueue = _cfg["enqueue"] if ask else None
    now = time.time()
    with _slock:
        v = _load().get(key)
        if v is not None:
            return v.get("s") or None
        if not enqueue or not material:
            return None
        if key in _pending and now - _pending[key] < PENDING_SEC:
            return None
        _asked[:] = [t for t in _asked if now - t < 3600]
        if len(_asked) >= MAX_PER_HOUR:
            return None
        _pending[key] = now
        _asked.append(now)
    ok = False
    try:
        ok = bool(enqueue(kind, key, material[-MATERIAL_MAX:]))   # 自分の鍵を持たずに呼ぶ（server.py の鍵と取り合わない）
    finally:
        if not ok:
            with _slock:
                _pending.pop(key, None)
                if now in _asked:
                    _asked.remove(now)
    return None


def accept(kind: str, key: str, ok: bool, text: str) -> None:
    """プラグインの答えを覚える。失敗も覚える（同じものは頼み直さない）。上限で断られたときだけ覚えない"""
    if kind not in ("wait", "title") or not isinstance(key, str) or not key.startswith(kind + ":"):
        return
    with _slock:
        _pending.pop(key, None)
        if not ok and CAP_MARK in str(text or ""):
            return
        rec = {"s": clean_summary(kind, text) if ok else "", "t": time.time()}
        if not ok:
            rec["error"] = short(text, 120)
        _load()[key] = rec
        try:
            _save()
        except OSError:
            pass


# ---------- 画面に出す形 ----------

_cache: dict = {"at": 0.0, "sessions": None, "tasks_at": 0.0, "tasks": None}
_clock = threading.Lock()


def _sessions(now: int) -> list:
    with _clock:
        if _cache["sessions"] is None or time.time() - _cache["at"] > SESSION_CACHE_SEC:
            ss = load_code_sessions(now) + load_cowork_sessions(now)
            for s in ss:
                s["status"] = status_of(s, now)
            ss.sort(key=lambda s: -s["lastActivityAt"])
            _cache.update(sessions=ss[:MAX_SESSIONS], at=time.time())
        return _cache["sessions"]


def _tasks(now: int) -> list:
    with _clock:
        if _cache["tasks"] is None or time.time() - _cache["tasks_at"] > TASK_CACHE_SEC:
            try:
                _cache["tasks"] = build_tasks(now)
            except Exception as e:  # 壊れても画面は出す（前回の結果を使い続ける）
                sys.stderr.write(f"[apps] 定期タスクを読めませんでした: {e!r}\n")
                _cache["tasks"] = _cache["tasks"] or []
            _cache["tasks_at"] = time.time()
        return _cache["tasks"]


def view(web: bool = False, ask: bool = True) -> dict:
    """GET /api/apps の答え。web=True（Web 経由）なら会話の本文・手順・ファイルの場所は出さない（題名・状態・要約まで）。
    ask=False なら、まだ無い題名・「待っていること」の要約をプラグインに頼まない（オフィスの机は数秒ごとに読むため。頼むのはこの一覧を開いたときだけ）"""
    if not enabled():
        return {"enabled": False, "sessions": [], "tasks": [], "counts": {}}
    now = now_ms()
    sessions = []
    for s in _sessions(now):
        if s.get("scheduledTaskId"):
            continue  # 定期タスクの実行は、タスクの履歴に出す
        title, title_made = s["title"], False
        if not title:  # 題名が無い会話：最初の依頼から作ってもらう。できるまでは最初の依頼の頭を出す
            firsts = [s["_first"]] if s.get("_first") else first_requests(s["_log"]) if s.get("_log") else []
            material = "\n".join(f"{i + 1}. {r}" for i, r in enumerate(firsts))
            made = lookup("title", title_key(s["id"]), material, ask) if material else None
            title, title_made = (made, True) if made else (short(firsts[0], 24) if firsts else "（無題）", False)
        wait_for, wait_src = None, None
        if s["status"] == "waiting" and not s.get("ask"):
            if s.get("waitRule"):
                wait_for, wait_src = s["waitRule"], "rule"
            elif s.get("waitFull"):
                made = lookup("wait", wait_key(s["id"], s["waitFull"]), s["waitFull"], ask)
                wait_for, wait_src = (made, "model") if made else (last_paragraph(s["waitFull"]) or None, "fallback")
        row = {
            "id": s["id"], "source": s["source"], "title": title, "titleMade": title_made, "status": s["status"],
            "lastActivityAt": iso(s["lastActivityAt"]), "model": s.get("model"), "cwd": s.get("cwd"),
            "ask": s.get("ask"), "waitFor": wait_for, "waitSource": wait_src, "recap": s.get("recap"),
            "pr": s.get("pr"), "lastTool": s.get("lastTool"), "link": s.get("link"),
            "lastText": s.get("lastAssistantText") or s.get("lastUserText") or None,
        }
        if web:
            row.pop("lastText")
            row["cwd"] = home_short(row["cwd"])
        sessions.append(row)
    rank = {"working": 0, "waiting": 1, "done": 2, "idle": 3}
    sessions.sort(key=lambda r: (rank.get(r["status"], 9), -(to_ms(r["lastActivityAt"]) or 0)))
    tasks = []
    for t in _tasks(now):
        t = dict(t)
        if web:
            for k in ("prompt", "configPath", "skillPath"):
                t.pop(k, None)
            t["folders"] = [home_short(f) for f in t["folders"]]
        tasks.append(t)
    counts = {k: sum(1 for r in sessions if r["status"] == k) for k in rank}
    counts["tasks"] = len(tasks)
    counts["missed"] = sum(t.get("missed", 0) for t in tasks)
    return {"enabled": True, "generatedAt": local_iso(now), "sessions": sessions, "tasks": tasks, "counts": counts}
