"""全会話の索引（My AI Assistant 試作・標準ライブラリだけ）。

このパソコンにある Claude の会話を全期間まとめて SQLite（history.db）に取り込み、日本語の部分一致で検索できるようにする。
新しい会話・変わったファイルだけ取り込み直す。読むだけで、元のファイルは書き換えない。

取り込むもの（source）:
  code    Claude Code の会話（ターミナル・デスクトップの Code タブ）  <設定フォルダ>/projects/*/*.jsonl
  task    そのうち定期タスクの会話（デスクトップアプリの記録があるときだけ判別できる）
  cowork  Cowork の会話（Mac のデスクトップアプリのフォルダがあるときだけ）
  memory  Claude のメモリ（ユーザー指示・決めたこと）                <設定フォルダ>/projects/*/memory/*.md
  doc     CLAUDE.md（全体と、会話の作業フォルダにあるもの）

<設定フォルダ> は環境変数 CLAUDE_CONFIG_DIR があればそれ、無ければ ~/.claude（Windows では %USERPROFILE%\\.claude。Path.home() が解決する）。
Cowork・定期タスクの見分け（デスクトップアプリのフォルダを読む部分）は Mac だけ。Windows ではアプリのフォルダが無いので飛ばす。
db の場所は configure() で決める（server.py は <データ置き場>/history.db）。
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

SOURCE_JA = {"code": "Claude Code", "task": "定期タスク", "cowork": "Cowork", "memory": "メモリ", "doc": "CLAUDE.md",
             "agent": "この画面の裏の作業", "chat": "Obsidian の会話ノート"}
TEXT_MAX = 6000         # 1発言あたり取り込む最大文字数
TOOL_RESULT_MAX = 1500  # 道具の結果は長いので頭だけ
CHUNK = 3000            # メモ類を区切る大きさ
MAX_DOC_DIRS = 300      # CLAUDE.md を探す作業フォルダの数の上限
COMMIT_EVERY = 25       # 何件取り込むごとに保存するか（取り込み中でも検索できるように）

_write_lock = threading.Lock()
_cfg: dict = {"db": None, "data": None}
MAX_CHAT_NOTES = 5000   # Obsidian の会話ノートを取り込む上限
_progress: dict = {"running": False, "done": 0, "total": 0, "startedAt": None, "finishedAt": None, "error": None}
_plock = threading.Lock()


def configure(db_path, data_dir=None) -> None:
    """data_dir: データ置き場。そこを作業フォルダにした会話（Addness の更新係・相談役など、この画面が裏で動かした claude -p）を
    「この画面の裏の作業」に分け、obsidian.json の書き出し先の会話ノートも取り込む"""
    _cfg["db"] = Path(db_path)
    _cfg["data"] = Path(data_dir) if data_dir else None


def _under(path: str | None, base: Path | None) -> bool:
    if not path or base is None:
        return False
    try:
        Path(path).resolve().relative_to(base.resolve())
        return True
    except (ValueError, OSError):
        return False


def chat_notes_dir() -> Path | None:
    """Obsidian へ書き出した会話ノートのフォルダ（<データ置き場>/obsidian.json の vault + folder）。使えないときは None"""
    d = _cfg.get("data")
    if d is None:
        return None
    try:
        cfg = json.loads((d / "obsidian.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(cfg, dict) or cfg.get("enabled") is False or not isinstance(cfg.get("vault"), str) or not cfg["vault"].strip():
        return None
    vault = Path(cfg["vault"]).expanduser()
    folder = cfg.get("folder") if isinstance(cfg.get("folder"), str) else ""
    out = (vault / folder) if folder else vault
    # 保管庫の外を指す folder（../ など）は読まない
    if not _under(str(out), vault) or not out.is_dir():
        return None
    return out


def db_path() -> Path:
    if _cfg["db"] is None:
        raise RuntimeError("history.configure(db_path) を先に呼んでください")
    return _cfg["db"]


def claude_dir() -> Path:
    return Path(os.environ.get("CLAUDE_CONFIG_DIR") or (Path.home() / ".claude"))


def app_dir() -> Path:
    """デスクトップアプリのデータ置き場（Mac の場所。Windows など、無ければ Cowork などは飛ばす）"""
    return Path.home() / "Library" / "Application Support" / "Claude"


def _glob(base: Path, pattern: str) -> list[Path]:
    """base の下を pattern（/ 区切り）で探す。Path.glob なので、パスに [ や ] があっても、Windows の \\ 区切りでも壊れない"""
    try:
        return sorted(base.glob(pattern))
    except OSError:
        return []


# ---------- DB ----------

def connect(readonly: bool = False) -> sqlite3.Connection:
    p = db_path()
    if readonly:
        con = sqlite3.connect(f"file:{p}?mode=ro", uri=True, timeout=30, check_same_thread=False)
    else:
        p.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(str(p), timeout=30, check_same_thread=False)
        con.execute("PRAGMA journal_mode=WAL")
        try:
            os.chmod(p, 0o600)   # 会話の中身が入るので本人だけが読める
        except OSError:
            pass
    con.row_factory = sqlite3.Row
    return con


def _has_fts(con: sqlite3.Connection) -> bool:
    return con.execute("SELECT 1 FROM sqlite_master WHERE name='msgs_fts'").fetchone() is not None


def init_db(con: sqlite3.Connection):
    con.executescript("""
    CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, mtime REAL, size INTEGER, sid TEXT);
    CREATE TABLE IF NOT EXISTS sessions(
        sid TEXT PRIMARY KEY, source TEXT, title TEXT, cwd TEXT, first_ts TEXT, last_ts TEXT,
        n INTEGER, link TEXT, path TEXT);
    CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY, sid TEXT, seq INTEGER, ts TEXT, role TEXT, text TEXT);
    CREATE INDEX IF NOT EXISTS msgs_sid ON msgs(sid, seq);
    CREATE INDEX IF NOT EXISTS sessions_last ON sessions(last_ts);
    CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
    """)
    try:   # trigram の全文検索が使えない古い SQLite のときは、部分一致（LIKE）だけで探す
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS msgs_fts USING fts5(text, content='msgs', content_rowid='id', tokenize='trigram')")
    except sqlite3.OperationalError:
        pass
    con.commit()


def _delete_session(con: sqlite3.Connection, sid: str):
    if _has_fts(con):
        for r in con.execute("SELECT id, text FROM msgs WHERE sid=?", (sid,)).fetchall():
            con.execute("INSERT INTO msgs_fts(msgs_fts, rowid, text) VALUES('delete', ?, ?)", (r["id"], r["text"]))
    con.execute("DELETE FROM msgs WHERE sid=?", (sid,))
    con.execute("DELETE FROM sessions WHERE sid=?", (sid,))


def _store(con: sqlite3.Connection, sess: dict, msgs: list[dict]):
    _delete_session(con, sess["sid"])
    if not msgs:
        return
    fts = _has_fts(con)
    tss = [m["ts"] for m in msgs if m.get("ts")]
    con.execute("INSERT OR REPLACE INTO sessions VALUES(?,?,?,?,?,?,?,?,?)",
                (sess["sid"], sess["source"], sess.get("title") or "(無題)", sess.get("cwd"),
                 min(tss) if tss else sess.get("ts"), max(tss) if tss else sess.get("ts"),
                 len(msgs), sess.get("link"), sess.get("path")))
    for i, m in enumerate(msgs):
        cur = con.execute("INSERT INTO msgs(sid, seq, ts, role, text) VALUES(?,?,?,?,?)",
                          (sess["sid"], i, m.get("ts") or sess.get("ts"), m["role"], m["text"]))
        if fts:
            con.execute("INSERT INTO msgs_fts(rowid, text) VALUES(?, ?)", (cur.lastrowid, m["text"]))


# ---------- 読み取り ----------

def _iso_from_mtime(p: Path) -> str:
    return datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()


def _strip_tags(s: str) -> str:
    return re.sub(r"<[^>]{1,200}>", " ", s)


def _session_meta() -> dict[str, dict]:
    """cliSessionId → {title, link 用の id, source, scheduled}（デスクトップアプリの記録。無ければ空）"""
    out = {}
    app = app_dir()
    for pattern, source in (("claude-code-sessions/*/*/local_*.json", "code"),
                            ("local-agent-mode-sessions/*/*/local_*.json", "cowork")):
        for p in _glob(app, pattern):
            try:
                d = json.loads(Path(p).read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(d, dict) or not d.get("cliSessionId"):
                continue
            out[d["cliSessionId"]] = {"title": d.get("title"), "local": d.get("sessionId"), "source": source,
                                      "scheduled": d.get("scheduledTaskId"), "cwd": d.get("cwd")}
    return out


def _tool_result_text(c) -> str:
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return "\n".join(str(x.get("text", "")) for x in c if isinstance(x, dict) and x.get("type") == "text")
    return ""


def parse_jsonl(path: Path) -> tuple[list[dict], dict]:
    """会話の発言を取り出す。役割: user / assistant / tool（道具を使った記録） / result（道具の結果）"""
    msgs, info = [], {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                d = json.loads(line)
            except Exception:
                continue
            if not isinstance(d, dict):
                continue
            t = d.get("type")
            ts = d.get("timestamp")
            if t == "custom-title" and d.get("customTitle"):
                info["title"] = d["customTitle"]
            if d.get("cwd") and "cwd" not in info:
                info["cwd"] = d["cwd"]
            if t == "user":
                c = (d.get("message") or {}).get("content")
                if isinstance(c, str):
                    txt = _strip_tags(c).strip()
                    if txt:
                        msgs.append({"ts": ts, "role": "user", "text": txt[:TEXT_MAX]})
                elif isinstance(c, list):
                    for b in c:
                        if not isinstance(b, dict):
                            continue
                        if b.get("type") == "text" and b.get("text"):
                            txt = _strip_tags(b["text"]).strip()
                            if txt:
                                msgs.append({"ts": ts, "role": "user", "text": txt[:TEXT_MAX]})
                        elif b.get("type") == "tool_result":
                            txt = _tool_result_text(b.get("content")).strip()
                            if txt:
                                msgs.append({"ts": ts, "role": "result", "text": txt[:TOOL_RESULT_MAX]})
            elif t == "assistant":
                for b in (d.get("message") or {}).get("content") or []:
                    if not isinstance(b, dict):
                        continue
                    if b.get("type") == "text" and b.get("text", "").strip():
                        msgs.append({"ts": ts, "role": "assistant", "text": b["text"].strip()[:TEXT_MAX]})
                    elif b.get("type") == "tool_use":
                        inp = b.get("input") or {}
                        name = re.sub(r"^mcp__[0-9a-f-]{20,}__", "", str(b.get("name", "")))
                        msgs.append({"ts": ts, "role": "tool", "text": f"{name} {json.dumps(inp, ensure_ascii=False)[:800]}"})
    return msgs, info


def _chunks(text: str) -> list[str]:
    text = text.strip()
    return [text[i:i + CHUNK] for i in range(0, len(text), CHUNK)] or []


def _frontmatter_title(text: str, fallback: str) -> str:
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    if m:
        name = re.search(r"^name:\s*(.+)$", m.group(1), re.M)
        desc = re.search(r"^description:\s*(.+)$", m.group(1), re.M)
        if desc:
            return f"{name.group(1).strip() + '：' if name else ''}{desc.group(1).strip()}"[:120]
        title = re.search(r"^title:\s*(.+)$", m.group(1), re.M)   # Obsidian のノート
        if title and title.group(1).strip().strip('"\''):
            return title.group(1).strip().strip('"\'')[:120]
    h = re.search(r"^#\s+(.+)$", text, re.M)
    return (h.group(1).strip() if h else fallback)[:120]


# ---------- 取り込み ----------

def _changed(con, path: Path) -> bool:
    try:
        st = path.stat()
    except OSError:
        return False
    r = con.execute("SELECT mtime, size FROM files WHERE path=?", (str(path),)).fetchone()
    return not r or r["mtime"] != st.st_mtime or r["size"] != st.st_size


def _mark(con, path: Path, sid: str):
    st = path.stat()
    con.execute("INSERT OR REPLACE INTO files VALUES(?,?,?,?)", (str(path), st.st_mtime, st.st_size, sid))


def progress() -> dict:
    with _plock:
        return dict(_progress)


def _set_progress(**kw):
    with _plock:
        _progress.update(kw)


def index_all(verbose: bool = False) -> dict:
    """変わったファイルだけ取り込み直す。戻り値は取り込んだ件数"""
    with _write_lock:
        _set_progress(running=True, done=0, total=0, startedAt=datetime.now(timezone.utc).isoformat(), finishedAt=None, error=None)
        con = None
        try:
            con = connect()
            init_db(con)
            meta = _session_meta()
            done = {"sessions": 0, "files": 0}
            seen: set[str] = set()
            cdir = claude_dir()
            app = app_dir()
            transcripts = [(p, "code") for p in _glob(cdir, "projects/*/*.jsonl")]
            transcripts += [(p, "cowork") for p in _glob(app, "local-agent-mode-sessions/*/*/local_*/.claude/projects/*/*.jsonl")]
            memories = _glob(cdir, "projects/*/memory/*.md")
            cnd = chat_notes_dir()
            chats = _glob(cnd, "**/*.md")[:MAX_CHAT_NOTES] if cnd else []
            _set_progress(total=len(transcripts) + len(memories) + len(chats) + 1)
            since_commit = 0

            def tick():
                nonlocal since_commit
                with _plock:
                    _progress["done"] += 1
                since_commit += 1
                if since_commit >= COMMIT_EVERY:
                    con.commit()
                    since_commit = 0

            for p, default_source in transcripts:
                sid = f"{default_source}:{p.stem}"
                seen.add(str(p))
                if _changed(con, p):
                    try:
                        msgs, info = parse_jsonl(p)
                    except OSError:
                        tick()
                        continue
                    m = meta.get(p.stem, {})
                    source = "task" if m.get("scheduled") else (m.get("source") or default_source)
                    if not m and _under(info.get("cwd"), _cfg.get("data")):
                        source = "agent"  # この画面が裏で動かした claude -p（作業フォルダがデータ置き場の中）
                    first_user = next((x["text"] for x in msgs if x["role"] == "user"), "")
                    title = m.get("title") or info.get("title") or first_user[:50] or p.stem
                    link = f"claude://claude.ai/epitaxy/{m['local']}" if m.get("local") and source != "cowork" else None
                    _store(con, {"sid": sid, "source": source, "title": title, "cwd": m.get("cwd") or info.get("cwd"),
                                 "link": link, "path": str(p), "ts": _iso_from_mtime(p)}, msgs)
                    _mark(con, p, sid)
                    done["sessions"] += 1
                tick()
            # 前の版で取り込んだ分（この画面の裏の作業も Claude Code に入っていた）を分け直す
            if _cfg.get("data") is not None:
                for r in con.execute("SELECT sid, cwd FROM sessions WHERE source='code' AND cwd IS NOT NULL").fetchall():
                    if _under(r["cwd"], _cfg["data"]):
                        con.execute("UPDATE sessions SET source='agent' WHERE sid=?", (r["sid"],))
            con.commit()

            def do_doc(p: Path, source: str, title: str | None = None):
                seen.add(str(p))
                if not _changed(con, p):
                    return
                try:
                    text = p.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    return
                sid = f"{source}:{p}"
                ts = _iso_from_mtime(p)
                _store(con, {"sid": sid, "source": source, "title": title or _frontmatter_title(text, p.stem),
                             "path": str(p), "ts": ts}, [{"ts": ts, "role": "note", "text": c} for c in _chunks(text)])
                _mark(con, p, sid)
                done["files"] += 1

            for p in memories:
                do_doc(p, "memory", "メモリの索引（MEMORY.md）" if p.name == "MEMORY.md" else None)
                tick()
            for p in chats:
                do_doc(p, "chat")
                tick()
            global_md = cdir / "CLAUDE.md"
            if global_md.is_file():
                do_doc(global_md, "doc", "CLAUDE.md（全体）")
            # 会話の作業フォルダにある CLAUDE.md
            cwds = [r[0] for r in con.execute("SELECT DISTINCT cwd FROM sessions WHERE cwd IS NOT NULL AND source IN ('code','task','cowork')")]
            for cwd in sorted(cwds)[:MAX_DOC_DIRS]:
                p = Path(cwd) / "CLAUDE.md"
                if p.is_file() and p != global_md and str(p) not in seen:
                    do_doc(p, "doc", f"CLAUDE.md（{Path(cwd).name or cwd}）")
            tick()
            con.commit()

            # 消えたファイルの分は索引からも消す（1つも見つからなかったときは、フォルダごと外れた可能性があるので消さない）
            gone = []
            if seen:
                gone = [r["path"] for r in con.execute("SELECT path FROM files") if r["path"] not in seen]
                for path in gone:
                    r = con.execute("SELECT sid FROM files WHERE path=?", (path,)).fetchone()
                    if r and r["sid"]:
                        _delete_session(con, r["sid"])
                    con.execute("DELETE FROM files WHERE path=?", (path,))
            con.execute("INSERT OR REPLACE INTO meta VALUES('indexed_at', ?)", (datetime.now(timezone.utc).isoformat(),))
            con.commit()
            if verbose:
                print(f"取り込み: 会話 {done['sessions']} 件 / メモ類 {done['files']} 件 / 消えた {len(gone)} 件")
            return done
        except Exception as e:
            _set_progress(error=repr(e)[:200])
            raise
        finally:
            if con is not None:
                con.close()
            _set_progress(running=False, finishedAt=datetime.now(timezone.utc).isoformat())


# ---------- 検索・閲覧（読むだけ） ----------

def _snippet(text: str, terms: list[str], width: int = 110) -> str:
    low = text.lower()
    pos = min([low.find(t.lower()) for t in terms if low.find(t.lower()) >= 0] or [0])
    start = max(0, pos - width // 3)
    s = text[start:start + width].replace("\n", " ")
    return ("…" if start > 0 else "") + s + ("…" if start + width < len(text) else "")


def search(q: str, source: str | None = None, limit: int = 20, per_session: int = 3,
           since: str | None = None, con: sqlite3.Connection | None = None) -> list[dict]:
    """全期間の会話を検索。空白区切りの語はすべて含むもの（AND）。会話ごとにまとめ、新しい順"""
    terms = [t for t in re.split(r"[\s　]+", q.strip()) if t]
    if not terms:
        return []
    own = con is None
    try:
        con = con or connect(readonly=True)
    except sqlite3.OperationalError:
        return []   # まだ db が無い（取り込みの前）
    try:
        where, args = [], []
        if all(len(t) >= 3 for t in terms) and _has_fts(con):
            where.append("m.id IN (SELECT rowid FROM msgs_fts WHERE msgs_fts MATCH ?)")
            args.append(" AND ".join('"' + t.replace('"', '""') + '"' for t in terms))
        else:  # 2文字以下の語（「見積」など）は trigram で引けないので部分一致
            for t in terms:
                where.append("m.text LIKE ? ESCAPE '\\'")
                args.append("%" + t.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        if source:
            where.append("s.source = ?")
            args.append(source)
        if since:
            where.append("m.ts >= ?")
            args.append(since)
        sql = f"""SELECT m.sid, m.seq, m.ts, m.role, m.text, s.title, s.source, s.link, s.last_ts
                  FROM msgs m JOIN sessions s ON s.sid = m.sid
                  WHERE {' AND '.join(where)} ORDER BY m.ts DESC LIMIT 2000"""
        out: dict[str, dict] = {}
        for r in con.execute(sql, args):
            g = out.get(r["sid"])
            if not g:
                if len(out) >= limit:
                    continue
                g = out[r["sid"]] = {"sid": r["sid"], "title": r["title"], "source": r["source"],
                                     "sourceJa": SOURCE_JA.get(r["source"], r["source"]), "link": r["link"],
                                     "lastTs": r["last_ts"], "hits": []}
            g.setdefault("_cand", []).append(r)
        rank = {"user": 0, "assistant": 1, "note": 1, "result": 2, "tool": 3}
        for g in out.values():  # 人と Claude の発言を先に、道具の記録は後に
            cand = sorted(g.pop("_cand"), key=lambda r: (rank.get(r["role"], 4), -(len(r["ts"] or ""))))
            g["hits"] = [{"seq": r["seq"], "ts": r["ts"], "role": r["role"], "snippet": _snippet(r["text"], terms)} for r in cand[:per_session]]
        return list(out.values())
    finally:
        if own:
            con.close()


def get_session(sid: str, offset: int = 0, limit: int = 300, con: sqlite3.Connection | None = None) -> dict | None:
    own = con is None
    try:
        con = con or connect(readonly=True)
    except sqlite3.OperationalError:
        return None
    try:
        s = con.execute("SELECT * FROM sessions WHERE sid=?", (sid,)).fetchone()
        if not s:
            return None
        msgs = [dict(r) for r in con.execute(
            "SELECT seq, ts, role, text FROM msgs WHERE sid=? ORDER BY seq LIMIT ? OFFSET ?", (sid, limit, offset))]
        return {**dict(s), "sourceJa": SOURCE_JA.get(s["source"], s["source"]), "offset": offset, "messages": msgs}
    finally:
        if own:
            con.close()


def list_sessions(source: str | None = None, title: str | None = None, offset: int = 0, limit: int = 50,
                  con: sqlite3.Connection | None = None) -> dict:
    own = con is None
    try:
        con = con or connect(readonly=True)
    except sqlite3.OperationalError:
        return {"total": 0, "offset": offset, "sessions": []}
    try:
        where, args = ["1=1"], []
        if source:
            where.append("source=?")
            args.append(source)
        if title:
            where.append("title LIKE ? ESCAPE '\\'")
            args.append("%" + title.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        total = con.execute(f"SELECT count(*) FROM sessions WHERE {' AND '.join(where)}", args).fetchone()[0]
        rows = [dict(r) | {"sourceJa": SOURCE_JA.get(r["source"], r["source"])} for r in con.execute(
            f"SELECT sid, source, title, first_ts, last_ts, n, link FROM sessions WHERE {' AND '.join(where)} "
            f"ORDER BY last_ts DESC LIMIT ? OFFSET ?", args + [limit, offset])]
        return {"total": total, "offset": offset, "sessions": rows}
    finally:
        if own:
            con.close()


def stats(con: sqlite3.Connection | None = None) -> dict:
    """件数など。取り込み中は indexing に進み具合が出る（ready は「検索できる件数がある」）"""
    ind = progress()
    indexing = {"running": ind["running"], "done": ind["done"], "total": ind["total"], "error": ind["error"]}
    own = con is None
    try:
        con = con or connect(readonly=True)
    except sqlite3.OperationalError:
        return {"ready": False, "indexing": indexing}
    try:
        by = {r["source"]: {"sessions": r["c"], "label": SOURCE_JA.get(r["source"], r["source"])}
              for r in con.execute("SELECT source, count(*) c FROM sessions GROUP BY source")}
        msgs = con.execute("SELECT count(*) FROM msgs").fetchone()[0]
        at = con.execute("SELECT v FROM meta WHERE k='indexed_at'").fetchone()
        span = con.execute("SELECT min(first_ts), max(last_ts) FROM sessions WHERE source IN ('code','cowork','task')").fetchone()
        return {"ready": bool(by) or at is not None, "bySource": by, "messages": msgs, "indexedAt": at[0] if at else None,
                "from": span[0], "to": span[1], "indexing": indexing}
    except sqlite3.OperationalError:
        return {"ready": False, "indexing": indexing}
    finally:
        if own:
            con.close()


def memory_index() -> str:
    """メモリの索引（MEMORY.md）の中身"""
    texts = []
    for p in _glob(claude_dir(), "projects/*/memory/MEMORY.md"):
        try:
            texts.append(p.read_text(encoding="utf-8"))
        except OSError:
            pass
    return "\n\n".join(texts)


def start_background(interval: int = 300) -> threading.Thread:
    """起動時に1回、その後は interval 秒ごとに差分を取り込む（裏のスレッド）"""
    def loop():
        while True:
            try:
                index_all()
            except Exception as e:  # 取り込みに失敗しても画面は止めない
                print(f"[history] 取り込み失敗: {e!r}", file=sys.stderr, flush=True)
            time.sleep(interval)
    t = threading.Thread(target=loop, daemon=True, name="history-index")
    t.start()
    return t
