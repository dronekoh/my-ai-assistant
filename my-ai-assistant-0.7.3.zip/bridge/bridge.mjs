// 橋渡し（子プロセスの入口）。プラグインが $.process.spawn で起動する。node 22 以上（標準の WebSocket・WebCrypto を使う）。
//   node bridge.mjs --config <web.json> [--server http://127.0.0.1:8790] [--data <dir>]
// 環境変数 MYAI_WEB_CTL_TOKEN: 親（プラグイン）だけが手元の制御窓口（127.0.0.1・ランダムなポート）を使うための合言葉。
// 環境変数 MYAI_WEB_ORIGIN_KEY: 手元サーバーと共有する、起動ごとの合言葉。Web から来た依頼に X-Web-Origin として付ける。
// 環境変数 MYAI_WEB_HISTORY: 1 のときだけ、履歴を Web から読める（既定は読めない。起動後は制御窓口の history で切り替える）。
// 親へは標準出力に1行1つの JSON で知らせる（ready / sas / pair_done / pair_rejected / pair_expired / pk_created / pk_added / fatal）。診断は標準エラー。
// 標準入力は使わない（プラグインの $.process.spawn は起動後に標準入力へ書けない）。親からの指示は制御窓口の HTTP で受ける。
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { timingSafeEqual } from 'node:crypto';

const out = (o) => process.stdout.write(JSON.stringify(o) + '\n');
const err = (...a) => process.stderr.write(a.join(' ') + '\n');
const die = (reason, detail) => { out({ t: 'fatal', reason, detail }); setTimeout(() => process.exit(2), 50); };

if (typeof WebSocket !== 'function' || typeof CompressionStream !== 'function' || !globalThis.crypto?.subtle) {
  die('node_too_old', process.version); // この下は node 22 以上で動くものだけ
} else {
  await main();
}

async function main() {
  const { createBridge } = await import('./lib/bridge-core.mjs');
  const arg = (name, dflt) => { const i = process.argv.indexOf(name); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : dflt; };
  const token = process.env.MYAI_WEB_CTL_TOKEN || '';
  if (token.length < 16) return die('no_token');
  let cfg;
  try { cfg = JSON.parse(await readFile(arg('--config', ''), 'utf8')); } catch { return die('no_config'); }
  if (typeof cfg.url !== 'string' || !/^https:\/\/[^/\s]+$/.test(cfg.url) || typeof cfg.key !== 'string' || cfg.key.length < 8) return die('bad_config');
  const dataDir = arg('--data', process.env.MY_AI_WEB_DIR || join(homedir(), '.my-ai-assistant', 'web'));
  const serverBase = arg('--server', 'http://127.0.0.1:8790');
  if (!/^http:\/\/(127\.0\.0\.1|localhost|\[::1\]):\d+$/.test(serverBase)) return die('bad_server'); // 手元のサーバー以外へは渡さない

  let lastCtl = Date.now();
  let quitting = false; // 止める合図を受けた。以降の連絡は「親が生きている合図」に数えない（止まらない橋渡しを延命しない）
  const originKey = process.env.MYAI_WEB_ORIGIN_KEY || ''; // 手元サーバーと共有する起動ごとの合言葉（Web から来た依頼の印）。無ければ印は付けない
  const bridge = await createBridge({ url: cfg.url, key: cfg.key, dataDir, serverBase, emit: out, log: err, originKey, historyOn: process.env.MYAI_WEB_HISTORY === '1' });

  const same = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y); };
  const reply = (res, code, obj) => { const d = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(d) }); res.end(d); };
  async function ctl(c) {
    switch (c.cmd) {
      case 'status': return { ok: true, ...bridge.status() };
      case 'pair': return { ok: true, ...(await bridge.pair()) };
      case 'list': return { ok: true, browsers: bridge.list(), passkeys: bridge.listPasskeys() };
      case 'revoke': return bridge.revoke(c.name);
      case 'history': return { ok: true, history: bridge.setHistory(c.on === true) };
      case 'sas': return { ok: bridge.answerSas(String(c.id ?? ''), c.ok === true) };
      case 'quit': quitting = true; setTimeout(() => shutdown(0), 50); return { ok: true };
      default: return { ok: false, error: 'unknown_cmd' };
    }
  }
  const srv = createServer((req, res) => {
    if (req.method !== 'POST' || req.url !== '/ctl' || !same(String(req.headers['x-ctl-token'] || ''), token)) return reply(res, 403, { ok: false });
    if (!String(req.headers['host'] || '').match(/^(127\.0\.0\.1|localhost)(:\d+)?$/)) return reply(res, 403, { ok: false }); // 他のサイトからの名前解決すり替えよけ
    const chunks = []; let n = 0;
    req.on('data', (d) => { n += d.length; if (n > 4096) req.destroy(); else chunks.push(d); });
    req.on('end', async () => {
      if (!quitting) lastCtl = Date.now();
      let c; try { c = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return reply(res, 400, { ok: false }); }
      try { reply(res, 200, await ctl(c)); } catch (x) { err('ctl 失敗', x.message); reply(res, 500, { ok: false, error: 'failed' }); }
    });
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));

  let closing = false;
  async function shutdown(code) {
    if (closing) return; closing = true;
    setTimeout(() => process.exit(code), 3000); // 片づけが引っかかっても、3 秒で必ず終わる（実機で quit のあと 9 分動き続けた不具合の対策）
    try { srv.close(); srv.closeAllConnections?.(); await bridge.stop(); } catch {}
    process.exit(code);
  }
  process.on('SIGTERM', () => shutdown(0)); process.on('SIGINT', () => shutdown(0));
  // 親（プラグイン）が見えなくなったら止まる（親が強制終了されて取り残されないように）。親は数秒おきに status を呼ぶ
  setInterval(() => { if (Date.now() - lastCtl > 45000) { err('親からの連絡が途絶えたので止まります'); shutdown(0); } }, 5000).unref();
  out({ t: 'ready', port: srv.address().port, pid: process.pid, node: process.version });
}
