// 過去の会話の検索（search_history・read_session・list_memory）。執行役の道具（register.tsx）と Addness の相談（addness.ts）が使う。
import type { EngineInterface } from 'claude-code'

type HistHit = { seq: number; ts: string | null; role: string; snippet: string }
type HistGroup = { sid: string; title: string; sourceJa: string; lastTs: string | null; hits: HistHit[] }
type HistSession = {
  title: string
  sourceJa: string
  n: number
  offset: number
  messages: { seq: number; ts: string | null; role: string; text: string }[]
}

export function formatSearch(groups: HistGroup[]): string {
  if (groups.length === 0) return '見つかりませんでした。語を短くする・言い換える・空白で区切る、を試してください。'
  const lines: string[] = []
  for (const g of groups) {
    lines.push(`■ [${g.sourceJa}] ${g.title}（最終 ${(g.lastTs ?? '').slice(0, 10)}） session_id=${g.sid}`)
    for (const h of g.hits) lines.push(`   ${(h.ts ?? '').slice(0, 16)} ${h.role}: ${h.snippet}`)
  }
  return lines.join('\n')
}

export function formatSession(s: HistSession, roles: string): string {
  const want = new Set(roles.split(',').map(r => r.trim()).filter(r => r !== ''))
  const head = `[${s.sourceJa}] ${s.title}  発言 ${s.n} 件中 ${s.offset}〜${s.offset + s.messages.length - 1}`
  const body = s.messages.filter(m => want.size === 0 || want.has(m.role)).map(m => `--- #${m.seq} ${(m.ts ?? '').slice(0, 16)} ${m.role}\n${m.text}`)
  const next = s.offset + s.messages.length
  return `${head}\n${body.join('\n')}${next < s.n ? `\n（続きあり：offset=${next}）` : ''}`
}

function intArg(v: unknown, dflt: number, lo: number, hi: number): number {
  const n = typeof v === 'number' ? Math.trunc(v) : typeof v === 'string' && /^\d+$/.test(v) ? Number(v) : dflt
  return Math.max(lo, Math.min(n, hi))
}

// 道具の呼び出し → サーバーの /api/history/*（合言葉つき）→ 文。サーバーが止まっているときはその旨の文を返す
export async function runHistoryTool($: EngineInterface, name: string, a: Record<string, unknown>, bridge: { base: string; token: string }): Promise<string> {
  const BASE = bridge.base
  const get = async (path: string, q: Record<string, string | number>): Promise<{ status: number; body: unknown }> => {
    const qs = Object.entries(q).filter(([, v]) => v !== '').map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`).join('&')
    const r = await $.http.fetch(`${BASE}${path}${qs !== '' ? `?${qs}` : ''}`, { headers: { 'X-Bridge-Token': bridge.token } })
    let body: unknown = null
    try {
      body = JSON.parse(r.text)
    } catch {
      body = null
    }
    return { status: r.status, body }
  }
  try {
    if (name === 'search_history') {
      const q = typeof a.query === 'string' ? a.query : ''
      if (q.trim() === '') return 'query が空です。検索語を入れてください。'
      const r = await get('/api/history/search', {
        q,
        limit: intArg(a.limit, 10, 1, 30),
        source: typeof a.source === 'string' ? a.source : '',
        since: typeof a.since === 'string' ? a.since : '',
      })
      if (r.status !== 200) return `エラー: 履歴の検索に失敗しました（HTTP ${r.status}）`
      const st = (await get('/api/history/stats', {})).body as { ready?: boolean; indexing?: { running?: boolean; done?: number; total?: number } } | null
      const found = formatSearch((r.body as { results?: HistGroup[] } | null)?.results ?? [])
      const note =
        st?.indexing?.running === true ? `\n（注意: 履歴の取り込みが途中です（${st.indexing.done ?? 0}/${st.indexing.total ?? '?'}）。新しい会話や古い会話がまだ入っていないことがあります）` : ''
      return found + note
    }
    if (name === 'read_session') {
      const sid = typeof a.session_id === 'string' ? a.session_id : ''
      if (sid === '') return 'session_id が空です。'
      const r = await get('/api/history/session', { sid, offset: intArg(a.offset, 0, 0, 10_000_000), limit: intArg(a.limit, 60, 1, 200) })
      if (r.status === 404) return 'その session_id の会話はありません。'
      if (r.status !== 200 || r.body === null) return `エラー: 会話を読めませんでした（HTTP ${r.status}）`
      return formatSession(r.body as HistSession, typeof a.roles === 'string' ? a.roles : '')
    }
    if (name === 'list_memory') {
      const r = await get('/api/history/memory', {})
      const text = (r.body as { text?: string } | null)?.text ?? ''
      if (r.status !== 200) return `エラー: メモリの索引を読めませんでした（HTTP ${r.status}）`
      return text !== '' ? text : 'メモリの索引が見つかりません。'
    }
  } catch (err) {
    return `エラー: 履歴の窓口（${BASE}）に届きませんでした。画面のサーバーが動いているか確かめてください（${String(err).slice(0, 80)}）`
  }
  return `エラー: 知らない道具です: ${name}`
}
