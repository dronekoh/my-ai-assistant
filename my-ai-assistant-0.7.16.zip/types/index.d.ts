export type MyAiAssistantPhase = 'starting' | 'running' | 'no-python' | 'port-busy' | 'stopped' | 'failed'

export type MyAiAssistantStatus = {
  phase: MyAiAssistantPhase
  message: string
}

declare module 'claude-code' {
  interface PluginState {
    'my-ai-assistant': {
      status: MyAiAssistantStatus
      handled: number
      last: string | null
      org: string
      name: string
      web: { line: string; pair: { code: string; expiresAt: number } | null; sas: { code: string; name: string } | null; history: boolean; note: string | null }
      // 仕事一覧（部署へ任せた仕事の控え）と、発言ごとの時刻。プラグインを読み直しても残すための控え
      // Shaped: 形の印（shape）が違う古い値は「無い」として読まれる
      tasks: Shaped<unknown[]>
      msgTs: Shaped<{ n: number; ts: string[] }>
    }
  }
}
