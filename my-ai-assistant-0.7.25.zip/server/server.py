#!/usr/bin/env python3
"""AI Assistant（既定の表示名 My AI Assistant）プラグイン版の試作サーバー（Python 標準ライブラリだけ）。

役目は「画面を出す」と「画面からの依頼を預かる」だけ。Claude は呼ばない。
依頼は、プラグイン（Claude Code の中で動く）が取りに来て、その Claude の中で仕事をして、答えを返しに来る。

    画面 --POST /api/ask--> このサーバー <--GET /api/bridge/next-- プラグイン
    画面 <--GET /api/jobs/<id>-- このサーバー <--POST /api/bridge/result-- プラグイン
    画面 <--GET /api/state------- このサーバー <--POST /api/bridge/state--- プラグイン（会話の中身）
    画面 --POST /api/exec/send--> このサーバー（添付を保存し、依頼として待ち行列へ。▶ 実行も「実行してください」の依頼としてここへ）
画面 --POST /api/exec/suggest--> このサーバー（入力の予測の依頼 → プラグインが作って答えを返す）
画面 --GET /api/history/*----> このサーバー（全会話の索引 history.py。プラグインの検索の道具も同じ口を呼ぶ）
画面 --GET/POST /api/settings-> このサーバー（設定「アシスタント」。POST は検証して待ち行列へ → プラグインが $.store に保存し、
                               /api/bridge/settings で今の値をこのサーバーへ知らせる。GET はその値を返す）

守り:
- 127.0.0.1 だけで待つ（社外・LAN から届かない）
- Host が 127.0.0.1:<port> / localhost:<port> 以外は断る（DNS rebinding よけ）
- 画面からの POST は独自ヘッダ X-My-AI-Assistant と JSON を必須にする（よそのサイトからの送り込みよけ）
- プラグイン用の口は、起動時に環境変数 MYAI_BRIDGE_TOKEN で渡された合言葉が要る
"""
from __future__ import annotations

import addness
import addness_chat
import apps
import argparse
import base64
import binascii
import hmac
import history
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
import urllib.parse
import uuid
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = "my-ai-assistant"
MAX_TEXT = 4000            # /api/ask（簡易）
MAX_SEND_TEXT = 100000     # /api/exec/send
MAX_ATTACH_TOTAL = 50 * 1024 * 1024
MAX_ATTACH_FILES = 20
WEB_ATTACH_DAY_BYTES = 50 * 1024 * 1024   # Web 経由の添付は、1日あたりの合計がこれまで（W5）
WEB_ATTACH_KEEP_DAYS = 7                  # Web 経由の添付は、これより古ければ自動で消す（W5）
MAX_BODY_SEND = 80 * 1024 * 1024   # base64 は 4/3 倍になるので 50MB の添付が入る大きさ
MAX_BODY_STATE = 4 * 1024 * 1024
MAX_MSG_TEXT = 20000
MAX_MESSAGES = 800  # 要約の前の控え（プラグインの ARCHIVE_KEEP 300 行）＋いまの会話
MAX_TASKS = 60
SHOW_WITHIN_SEC = 24 * 3600   # 終わった仕事は、これより古ければデスクに出さない（本番と同じ考え）
OTHER_DEPT = {"id": "other", "name": "その他", "image": "support", "color": "#5b6677"}
TASK_STATUS = ("working", "done", "failed", "stopped")
DESK_STATUS = {"working": "working", "done": "done", "failed": "waiting", "stopped": "idle"}   # 仕事 → デスク
RANK = {"working": 0, "waiting": 1, "done": 2, "idle": 3}
MODES = ("agent", "chat")
# 画面から開けるファイルの種類（アプリ・スクリプトは開かない）
DOC_EXT = {".xlsx", ".xls", ".xlsm", ".csv", ".pdf", ".docx", ".doc", ".pptx", ".png", ".jpg", ".jpeg",
           ".zip", ".dxf", ".txt", ".md"}
# Web から「パソコンのアプリで開く」を許す拡張子（DOC_EXT との重なりだけが効く。bridge/lib/policy.mjs の WEB_OPEN_EXT と同じ）。
# マクロ付き（.xlsm など）・実行できる形・ブラウザで動く形（.html .svg）・.zip・.dxf・拡張子なしは、Web からは開かない
WEB_OPEN_EXT = {".pdf", ".xlsx", ".xls", ".docx", ".doc", ".pptx", ".csv", ".txt", ".md", ".png", ".jpg", ".jpeg", ".gif", ".webp"}
# 出す機能の切り替え（画面はこれを見て出し分ける。false のものは隠す）。tasks は仕事一覧
FEATURES = {"tasks": True, "history": True, "suggest": True, "usage": True, "edit": True, "runCommand": True}
ROLE_IMAGE = {"planning": "planning", "research": "analyst", "programmer": "programmer",
              "designer": "designer", "general": "support"}
CTYPES = {".js": "text/javascript; charset=utf-8", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
          ".png": "image/png", ".webp": "image/webp", ".css": "text/css; charset=utf-8"}

_lock = threading.Lock()
_jobs: dict = {}          # id -> {id, text, mode, status, answer, created}
_queue: list = []         # 未着手の id（古い順）
_last_poll = 0.0          # プラグインが最後に取りに来た時刻
_conv: dict = {"messages": [], "busy": False, "busySince": None, "live": None, "model": None,
               "tasks": [], "outputs": set(), "at": 0.0, "usage": None, "context": None, "owner": None, "permits": []}   # プラグインが送ってきた会話の中身（画面用の形）
_suggest: dict = {}       # 入力の予測 {"for": 返事の id, "status": pending|ready|none|failed, "text": 予測, "reason": 失敗の理由}（メモリだけ）
SUGGEST_TAIL = 3000       # 予測に渡す執行役の返事（末尾の文字数）
SUGGEST_RECENT = 4        # 渡す利用者の直近の発言の数
SUGGEST_MAX_LEN = 40      # これより長い予測は出さない（切れた文が出ると紛らわしい）
LIMIT_KEYS = ("five_hour", "seven_day")
_notes: list = []         # 止めるボタンの結果など、画面の会話に出す一言 {id, role:"note", text, ts}
DATA_DIR = Path(os.environ.get("MYAI_DATA_DIR") or (Path.home() / ".my-ai-assistant"))
OLD_DATA_DIR_NAME = ".koh-assistant"   # v0.2.0 より前の名前（データ置き場の移し替えだけに使う）


def migrate_old_data_dir(home: Path) -> str:
    """旧名 ~/.koh-assistant の中身を、新しい ~/.my-ai-assistant へコピーする（新しい方が無いときだけ。元は消さない）。
    途中で失敗しても半端な新フォルダを残さないよう、一時の名前へコピーしてから付け替える。戻り値は結果の一言（何もしないときは空）"""
    new, old = home / ".my-ai-assistant", home / OLD_DATA_DIR_NAME
    if new.exists() or not old.is_dir():
        return ""
    tmp = home / ".my-ai-assistant.migrating"
    try:
        if tmp.exists():
            shutil.rmtree(tmp)
        shutil.copytree(old, tmp)
        tmp.rename(new)
    except OSError as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return "移し替えに失敗しました（旧データはそのまま）: %s" % e
    return "旧データ置き場 %s を %s へコピーしました（元は残してあります）" % (old, new)
STALE_JOB_SEC = 10 * 60   # これより古い未完了の依頼は「処理中」の表示に使わない（プラグインが止まったとき）

# ---- 設定「アシスタント」（段7）----
# プラグイン（hooks/register.tsx の validateSettings）と同じ上限・同じ規則。変えるときは両方を直す（tests が両方を確かめる）
DEFAULT_NAME = "My AI Assistant"
LIMITS = {"displayName": 30, "extraInstructions": 2000, "departments": 12, "deptName": 32, "label": 20,
          "description": 300, "prompt": 4000, "tools": 30}
MAX_BODY_SETTINGS = 256 * 1024
DEPT_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")
TOOL_RE = re.compile(r"^[A-Za-z0-9_*:.-]{1,100}$")
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
EFFORTS = ("low", "medium", "high", "xhigh", "max")
MODELS = ("sonnet", "opus", "haiku", "inherit")
ROLE_IMAGES = ("executive", "planning", "analyst", "programmer", "designer", "support", "hr", "marketing", "sales", "accounting")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")          # 改行・タブ以外の制御文字
_CTRL_LINE = re.compile(r"[\x00-\x1f\x7f]")                        # 1行の欄：改行・タブも不可
COMPACT_CHOICES = (200000, 400000, 600000, 800000, 1000000)   # 自動圧縮の目安（20万ずつ）。プラグインの COMPACT_CHOICES と同じ
COMPACT_DEFAULT = 200000
_settings: dict = {"displayName": None, "extraInstructions": "", "departments": None, "customDepartments": False, "compactWindow": None}   # プラグインが知らせた今の値（None=まだ届いていない）
_settings_synced = False


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def iso_of(epoch: float) -> str:
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def load_org() -> dict:
    try:
        d = json.loads((HERE.parent / "config" / "org.json").read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _str(v, n: int, default=None):
    return v[:n] if isinstance(v, str) else default


def clean_messages(raw) -> list:
    """プラグインから来た会話を、画面が読める形だけに絞る（余計な項目は捨てる・長さを抑える）"""
    out = []
    if not isinstance(raw, list):
        return out
    for m in raw[-MAX_MESSAGES:]:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant", "step", "note", "files"):
            continue
        item = {"id": _str(m.get("id"), 64, f"m{len(out)}"), "role": m["role"],
                "text": _str(m.get("text"), MAX_MSG_TEXT, "").replace("\r\n", "\n"), "ts": _str(m.get("ts"), 40, None)}
        if m["role"] == "step":
            item["kind"] = _str(m.get("kind"), 20, "tool")
            item["text"] = item["text"][:300]
        if m["role"] == "files":
            item["outputs"] = [p for p in (m.get("outputs") or [])
                                if isinstance(p, str) and len(p) < 1024 and os.path.splitext(p)[1].lower() in DOC_EXT][:20]
            if not item["outputs"]:
                continue
        if m["role"] == "user" and isinstance(m.get("files"), list):
            item["files"] = [{"name": _str(f.get("name"), 120, ""), "size": f.get("size") if isinstance(f.get("size"), int) else None}
                             for f in m["files"] if isinstance(f, dict)][:20]
        out.append(item)
    return out


def clean_context(raw):
    """会話の量（本番の ctx_view と同じ形）：tokens・window・pct・at・source・compact・compacting"""
    if not isinstance(raw, dict):
        return None
    window = raw.get("window")
    if not isinstance(window, (int, float)) or isinstance(window, bool) or window <= 0:
        return None
    tokens = raw.get("tokens")
    tokens = int(tokens) if isinstance(tokens, (int, float)) and not isinstance(tokens, bool) and tokens >= 0 else None
    pct = raw.get("pct")
    pct = float(pct) if isinstance(pct, (int, float)) and not isinstance(pct, bool) else (
        round(tokens * 100 / window, 1) if tokens is not None else None)
    cp = raw.get("compact")
    cp_at = _str(cp.get("at"), 40) if isinstance(cp, dict) else ""
    return {"tokens": tokens, "window": int(window), "pct": pct, "at": _str(raw.get("at"), 40), "source": _str(raw.get("source"), 20, "plugin"),
            "compact": {"at": cp_at} if cp_at else None, "compacting": raw.get("compacting") is True}


def platform_name(plat: str | None = None) -> str:
    """画面に伝える OS の種類（できたファイルの置き場所を開くボタンの名前に使う）"""
    plat = plat or sys.platform
    return "mac" if plat == "darwin" else "windows" if plat in ("win32", "cygwin") else "linux"


def path_key(p: str, pm=os.path) -> str:
    """パスの照合用の形。区切り（/ と \\）・大文字小文字（Windows）・. や .. をそろえる。pm=ntpath で Windows の規則になる"""
    return pm.normcase(pm.normpath(p))


def home_short(p, home: str | None = None, pm=os.path) -> str | None:
    """作業フォルダなどの絶対パス。ホームフォルダ（利用者名を含む）は ~ に置き換えて出す。
    Windows の C:\\Users\\x\\… も C:/Users/x/… も同じ家として扱う（pm=ntpath のとき）。~ の後ろは元の区切りのまま"""
    if not isinstance(p, str) or not p or len(p) > 500 or "\0" in p:
        return None
    home = home if home is not None else str(Path.home())
    if not home:
        return p
    kp, kh = path_key(p, pm), path_key(home, pm)
    if kp == kh:
        return "~"
    if kp.startswith(kh.rstrip("\\/") + pm.sep):
        rest = p[len(home.rstrip("\\/")):]
        return "~" + (rest if rest[:1] in ("/", "\\") else pm.sep + rest)
    return p


MAX_PERMITS = 20
PERMIT_ID_RE = re.compile(r"^perm-[a-z0-9]{1,16}-[0-9]{1,9}$")


def clean_permits(raw) -> list:
    """許可待ち（Claude アプリの確認の画面で止まっている呼び出し）。プラグインは見て知らせるだけで、答えはアプリでする。
    {id, department, tool, summary, since, agentId, sessionId} の形・長さだけに絞る（1行の欄は改行・制御文字を空白にする）"""
    out = []
    if not isinstance(raw, list):
        return out
    line = lambda v, n: _CTRL_LINE.sub(" ", v)[:n] if isinstance(v, str) else ""
    for p in raw[:MAX_PERMITS]:
        if not isinstance(p, dict) or not isinstance(p.get("id"), str) or not PERMIT_ID_RE.match(p["id"]):
            continue
        out.append({"id": p["id"], "department": line(p.get("department"), 40) or "部署", "tool": line(p.get("tool"), 100),
                    "summary": line(p.get("summary"), 200), "since": _str(p.get("since"), 40),
                    "agentId": _str(p.get("agentId"), 64), "sessionId": _str(p.get("sessionId"), 64)})
    return out


def permits_view(permits: list, web: bool) -> list:
    """画面へ出す形。この会話を Claude アプリで開く id（local_…）を付ける（Web にも。机の key と同じ id で、押すとパソコンのアプリで開く）。
    会話の内部の id（cliSessionId）は出さない"""
    out = []
    for p in permits:
        item = {k: p[k] for k in ("id", "department", "tool", "summary", "since")}
        if apps.enabled():
            try:
                item["appSid"] = apps.app_session_for_cli(p.get("sessionId"))
            except Exception:  # 引けなくてもカードは出す
                item["appSid"] = None
        out.append(item)
    return out


def clean_owner(raw):
    """この画面を出している会話の情報（作業フォルダ・プロジェクトの場所・会話の開始時刻・プラグインの版だけ）"""
    if not isinstance(raw, dict):
        return None
    out = {"cwd": home_short(raw.get("cwd")), "root": home_short(raw.get("root")),
           "startedAt": _str(raw.get("startedAt"), 40), "version": _str(raw.get("version"), 20)}
    return out if any(v for v in out.values()) else None


PAIRS = (("「", "」"), ("『", "』"), ('"', '"'), ("'", "'"), ("`", "`"), ("“", "”"))


def _wrapped(t: str) -> bool:
    """文全体が、対になる引用符で1組だけ囲まれているか（文頭の「だけ・文中の」は囲みではない）"""
    if len(t) < 2:
        return False
    for o, c in PAIRS:
        if t[0] != o or t[-1] != c:
            continue
        inner, depth = t[1:-1], 0
        if o == c:
            return o not in inner      # "A" と "B" のように途中でも閉じていれば、全体の囲みではない
        for ch in inner:
            depth += 1 if ch == o else -1 if ch == c else 0
            if depth < 0:
                break
        else:
            if depth == 0:
                return True
    return False


def unquote(line: str) -> str:
    """予測の1行から、全体を囲む引用符だけを外す（対になるときだけ。文頭・文末の片方だけは残す）"""
    t = (line or "").strip()
    while _wrapped(t):
        t = t[1:-1].strip()
    return t


def clean_usage(raw):
    """利用上限（本番の _limit_view と同じ形）：{status, five_hour: {pct, resetsAt, at}|None, seven_day: …}"""
    if not isinstance(raw, dict):
        return None
    out = {"status": _str(raw.get("status"), 40)}
    for k in LIMIT_KEYS:
        w = raw.get(k)
        pct = w.get("pct") if isinstance(w, dict) else None
        if not isinstance(pct, (int, float)) or isinstance(pct, bool):
            out[k] = None
            continue
        r = w.get("resetsAt")
        out[k] = {"pct": min(round(float(pct), 1), 100.0), "resetsAt": int(r) if isinstance(r, (int, float)) and not isinstance(r, bool) else None,
                  "at": _str(w.get("at"), 40)}
    return out


def fresh_usage(usage, now_sec: float):
    """リセット時刻を過ぎた窓の値は古いので出さない（本番の _limit_view と同じ考え）"""
    if not isinstance(usage, dict):
        return None
    out = dict(usage)
    for k in LIMIT_KEYS:
        w = out.get(k)
        if isinstance(w, dict) and isinstance(w.get("resetsAt"), int) and w["resetsAt"] <= now_sec:
            out[k] = None
    return out


def suggest_target(messages: list, busy: bool):
    """予測の対象：いちばん最後の執行役の返事（その後に利用者の発言が無く、執行役が待っているときだけ）"""
    if busy:
        return None
    for m in reversed(messages):
        if m.get("role") == "user":
            return None
        if m.get("role") == "assistant" and (m.get("text") or "").strip():
            return m
    return None


def short(s, n: int = 120) -> str:
    t = re.sub(r"\s+", " ", str(s or "")).strip()
    return t if len(t) <= n else t[: n - 1] + "…"


def to_ms(v) -> float:
    """ISO 文字列（Z 付きも可）をミリ秒に。読めなければ 0"""
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp() * 1000
    except (ValueError, TypeError):
        return 0.0


def clean_tasks(raw, valid_depts) -> list:
    """プラグインから来た仕事（部署1つ＝1件）を、画面が読める形だけに絞る"""
    out = []
    if not isinstance(raw, list):
        return out
    for t in raw[:MAX_TASKS]:
        if not isinstance(t, dict) or not isinstance(t.get("id"), str) or not t["id"] or len(t["id"]) > 128:
            continue
        dept = _str(t.get("department"), 64, "other")
        tools = [{"ts": _str(x.get("ts"), 40, None), "text": _str(x.get("text"), 300, "")}
                 for x in (t.get("tools") or []) if isinstance(x, dict)][-40:]
        outs = [p for p in (t.get("outputs") or [])
                if isinstance(p, str) and len(p) < 1024 and os.path.splitext(p)[1].lower() in DOC_EXT][:20]
        out.append({
            "id": t["id"], "taskId": t["id"], "department": dept if dept in valid_depts else "other",
            "title": _str(t.get("title"), 60, "仕事"), "prompt": _str(t.get("prompt"), 2000, ""),
            "model": _str(t.get("model"), 100, ""), "background": bool(t.get("background")),
            "status": t.get("status") if t.get("status") in TASK_STATUS else "working",
            "startedAt": _str(t.get("startedAt"), 40, None), "finishedAt": _str(t.get("finishedAt"), 40, None),
            "summary": _str(t.get("summary"), 8000, None), "tools": tools, "live": _str(t.get("live"), 200, None),
            "outputs": outs, "sessionId": None})
    return out


def out_info(paths: list) -> list:
    res = []
    for fp in paths or []:
        try:
            st = os.stat(fp)
        except OSError:
            continue
        res.append({"path": fp, "name": os.path.basename(fp),
                    "dir": home_short(os.path.dirname(fp)) or "",
                    "ext": os.path.splitext(fp)[1].lower().lstrip("."), "size": st.st_size,
                    "mtime": iso_of(st.st_mtime)})
    return res


def _text(v, name: str, max_len: int, *, line: bool, required: bool = False):
    """文字列の欄を検証する。前後の空白は除く。長さは文字数（サロゲートペアも1字）"""
    if not isinstance(v, str):
        raise ValueError(f"{name}は文字列で入れてください")
    t = v.strip()
    if (_CTRL_LINE if line else _CTRL).search(t):
        raise ValueError(f"{name}に使えない文字（改行や制御文字）が入っています" if line else f"{name}に使えない制御文字が入っています")
    if len(t) > max_len:
        raise ValueError(f"{name}は{max_len}文字までです（いま{len(t)}文字）")
    if required and not t:
        raise ValueError(f"{name}を入れてください")
    return t


def clean_dept(raw, index: int, defaults: dict | None = None) -> dict:
    """部署1件を検証して整える。名前は英小文字・数字・ハイフン。画像は ROLE_IMAGES から、色は #rrggbb"""
    if not isinstance(raw, dict):
        raise ValueError(f"部署{index + 1}の形が違います")
    d = defaults or {}
    nm = _text(raw.get("name"), f"部署{index + 1}の名前", LIMITS["deptName"], line=True, required=True)
    if not DEPT_NAME_RE.match(nm):
        raise ValueError(f"部署の名前「{nm}」は、半角の英小文字・数字・ハイフンだけにしてください（先頭は英小文字か数字）")
    out = {"name": nm,
           "label": _text(raw.get("label") if raw.get("label") not in (None, "") else nm, f"部署「{nm}」の表示名", LIMITS["label"], line=True),
           "description": _text(raw.get("description"), f"部署「{nm}」の説明", LIMITS["description"], line=True, required=True),
           "prompt": _text(raw.get("prompt"), f"部署「{nm}」の指示", LIMITS["prompt"], line=False, required=True)}
    model = raw.get("model") if raw.get("model") not in (None, "") else d.get("model", "sonnet")
    if not isinstance(model, str) or not MODEL_RE.match(model):
        raise ValueError(f"部署「{nm}」のモデルの指定が正しくありません")
    out["model"] = model
    effort = raw.get("effort") if raw.get("effort") is not None else d.get("effort")
    if effort is not None:
        ok = (isinstance(effort, str) and effort in EFFORTS) or (isinstance(effort, int) and not isinstance(effort, bool) and 1 <= effort <= 200000)
        if not ok:
            raise ValueError(f"部署「{nm}」の effort が正しくありません")
        out["effort"] = effort
    tools = raw.get("tools")
    if tools is not None:
        if not isinstance(tools, list) or len(tools) > LIMITS["tools"] or not all(isinstance(t, str) and TOOL_RE.match(t) for t in tools):
            raise ValueError(f"部署「{nm}」の tools の指定が正しくありません")
        out["tools"] = list(tools)
    img = raw.get("image") if raw.get("image") not in (None, "") else ROLE_IMAGE.get(nm, "support")
    if img not in ROLE_IMAGES:
        raise ValueError(f"部署「{nm}」の画像の指定が正しくありません")
    out["image"] = img
    color = raw.get("color") if raw.get("color") not in (None, "") else "#5b6677"
    if not isinstance(color, str) or not COLOR_RE.match(color):
        raise ValueError(f"部署「{nm}」の色の指定が正しくありません")
    out["color"] = color
    return out


def validate_settings(raw) -> dict:
    """設定の更新（部分でよい）を検証する。返り値は「渡された項目だけ」の整った値。不正なら ValueError（日本語の理由）。
    displayName: null か空 → 既定に戻す（None）。extraInstructions: null → ''。departments: null → 既定（org.json）に戻す"""
    if not isinstance(raw, dict):
        raise ValueError("設定の形が違います")
    out: dict = {}
    if "displayName" in raw:
        v = raw["displayName"]
        out["displayName"] = None if v is None or (isinstance(v, str) and not v.strip()) else _text(v, "表示名", LIMITS["displayName"], line=True)
    if "compactWindow" in raw:
        v = raw["compactWindow"]
        if v is None:
            out["compactWindow"] = None
        elif isinstance(v, int) and not isinstance(v, bool) and v in COMPACT_CHOICES:
            out["compactWindow"] = v
        else:
            raise ValueError("圧縮の目安は 20万・40万・60万・80万・100万 のどれかにしてください")
    if "extraInstructions" in raw:
        v = raw["extraInstructions"]
        out["extraInstructions"] = "" if v is None else _text(v, "執行役への追加の指示", LIMITS["extraInstructions"], line=False)
    if "departments" in raw:
        v = raw["departments"]
        if v is None:
            out["departments"] = None
        else:
            if not isinstance(v, list):
                raise ValueError("部署は一覧で入れてください")
            if len(v) > LIMITS["departments"]:
                raise ValueError(f"部署は{LIMITS['departments']}件までです（いま{len(v)}件）")
            depts, seen = [], set()
            for i, x in enumerate(v):
                d = clean_dept(x, i)
                if d["name"] in seen:
                    raise ValueError(f"部署の名前「{d['name']}」が重なっています")
                seen.add(d["name"])
                depts.append(d)
            out["departments"] = depts
    return out


def guard_web_tools(clean: dict) -> None:
    """Web から来た設定の更新では、部署の tools（使える道具）を今の値のままにする（変えさせない）。
    同じ名前の部署は今の tools（無ければ無し）に戻し、新しい部署は tools なし（既定の部署と同じ）にする"""
    depts = clean.get("departments")
    if not isinstance(depts, list):
        return
    cur = {d["name"]: d for d in effective_settings()[0]["departments"]}
    for d in depts:
        old = cur.get(d["name"])
        if old is not None and "tools" in old:
            d["tools"] = list(old["tools"])
        else:
            d.pop("tools", None)


def default_departments() -> list:
    """config/org.json の部署（既定）。読めない・形が違う部署は飛ばす"""
    org = load_org()
    base = org.get("defaults") if isinstance(org.get("defaults"), dict) else {}
    out = []
    for i, x in enumerate(org.get("departments") or []):
        try:
            d = clean_dept(x, i, base)
        except ValueError:
            continue
        out.append(d)
    return out


def default_name() -> str:
    ex = load_org().get("executive")
    t = ex.get("title") if isinstance(ex, dict) else None
    return t.strip() if isinstance(t, str) and t.strip() and len(t.strip()) <= LIMITS["displayName"] else DEFAULT_NAME


def effective_settings() -> dict:
    """いまの設定（画面に見せる形）。プラグインから届いていなければ既定（org.json）"""
    with _lock:
        st = dict(_settings)
        synced = _settings_synced
    depts = st["departments"] if st["departments"] is not None else default_departments()
    return {"displayName": st["displayName"] or default_name(), "extraInstructions": st["extraInstructions"] or "",
            "departments": depts, "customDepartments": bool(st["customDepartments"]),
            "compactWindow": st.get("compactWindow") or COMPACT_DEFAULT}, synced


# ---- Web からの発言の決まり（bridge/lib/policy.mjs の stripInvisible・isRunRequest・startsWithCommandMark と同じ）----
# 送り直し（/api/exec/retry）は Web から id だけが来るので、元の発言をサーバーが見て同じ決まりで断る
_INVISIBLE_ONE = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x2800, 0x3164, 0xFFA0}
RUN_PREFIX = "次のコマンドを実行してください"


def strip_invisible(t) -> str:
    """NFKC にして、制御文字・書式文字（Cc・Cf）と充填文字・異体字選択子を除く"""
    s = unicodedata.normalize("NFKC", str(t))
    return "".join(c for c in s if not (unicodedata.category(c) in ("Cc", "Cf") or ord(c) in _INVISIBLE_ONE
                                        or 0x180B <= ord(c) <= 0x180D or 0xFE00 <= ord(c) <= 0xFE0F or 0xE0100 <= ord(c) <= 0xE01EF))


def is_run_request(text) -> bool:
    return re.sub(r"^[\s>\"'`「『（(*_#-]+", "", strip_invisible(text)).startswith(RUN_PREFIX)


def starts_with_command_mark(text) -> bool:
    return re.match(r"[/!#]", re.sub(r"^\s+", "", strip_invisible(text))) is not None


def web_text_refusal(text) -> str | None:
    """Web から送れない発言なら、その理由。送れるなら None（policy.mjs の checkSend と同じ）"""
    if len(text or "") > MAX_SEND_TEXT:
        return "発言が長すぎます"
    if is_run_request(text):
        return "「実行」の依頼は Web からは出せません"
    if starts_with_command_mark(text):
        return "/ ! # で始まる依頼は Web からは出せません"
    return None


# ---- ▶ 実行（/api/exec/run）：server/index.html の runnableBlock・RUN.request と同じ決まり。サーバーはコマンドを実行しない ----
FENCE_RE = re.compile(r"```([^\n`]*)\n([\s\S]*?)```")
SHELL_LANGS = {"bash", "sh", "zsh", "shell"}
KNOWN_CMDS = set("""cd ls pwd echo printf cat less git gh python python3 python3.9 python3.11 python3.12 pip pip3 uv uvx npm npx node yarn pnpm
curl wget pkill kill killall ps open osascript launchctl brew make docker alembic pytest ruff mypy uvicorn claude
mkdir cp mv rm rmdir ln touch chmod tail head grep rg find sed awk export source ssh scp rsync sleep date wc tar zip unzip
env which lsof sqlite3 jq defaults say du df tree diff file stat shasum md5 xattr mdfind caffeinate time nohup supabase
vercel render psql pbcopy pbpaste tee sort uniq cut tr xargs true false test sudo""".split())
SUDO_RE = re.compile(r"(^|[\s;&|(`$])sudo(\s|$)", re.M)
RUN_MAX_CODE = 20000
WEB_RUN_MARK = "（Web から ▶ 実行 が押されました。登録したブラウザからの依頼です）"


def looks_like_command(code: str) -> bool:
    lines = [x.strip() for x in code.split("\n") if x.strip() and not x.strip().startswith("#")]
    if not lines:
        return False
    tok = lines[0].split()[0]
    if not re.fullmatch(r"[\x00-\x7f]+", tok):
        return False
    return tok in KNOWN_CMDS or tok.startswith(("./", "/", "~/")) or re.match(r"[A-Z_][A-Z0-9_]*=", tok) is not None


def runnable_block(lang: str, code: str) -> tuple[bool, str]:
    if not code.strip():
        return False, ""
    if lang and lang not in SHELL_LANGS:
        return False, ""
    if not lang and not looks_like_command(code):
        return False, ""
    if SUDO_RE.search(code):
        return False, "sudo を含むため、画面からは実行しません（ターミナルで実行してください）"
    if len(code) > RUN_MAX_CODE:
        return False, "長すぎるため画面からは実行しません"
    return True, ""


def run_block(messages: list, msg_id: str, idx: int) -> str:
    """執行役の発言 msg_id の idx 番目の ``` ブロックを取り出し、▶ 実行の依頼の文にする（画面の RUN.request と同じ形）。依頼にできなければ ValueError"""
    m = next((x for x in messages if x.get("id") == msg_id and x.get("role") == "assistant"), None)
    if not m:
        raise ValueError("その発言が見つかりません（執行役の発言だけ）")
    f = next((f for i, f in enumerate(FENCE_RE.finditer(m.get("text") or "")) if i == idx), None)
    if not f:
        raise ValueError("そのコードのブロックが見つかりません")
    lang = ((f.group(1) or "").strip().split() or [""])[0].lower()
    code = f.group(2)[:-1] if f.group(2).endswith("\n") else f.group(2)
    ok, why = runnable_block(lang, code)
    if not ok:
        raise ValueError(why or "このブロックは依頼できません")
    return "次のコマンドを実行してください。\n\n```bash\n" + code + "\n```"


def _job_active(job: dict) -> bool:
    return (job.get("kind") == "exec" and job.get("mode") not in ("stop", "stoptask") and job["status"] in ("queued", "running")
            and time.time() - job["created"] < STALE_JOB_SEC)


def enqueue_summary(kind: str, key: str, material: str) -> bool:
    """「待っていること」・会話タイトルの要約をプラグインに頼む（apps.py が呼ぶ）。プラグインがつながっていなければ積まない"""
    with _lock:
        if time.time() - _last_poll >= 10:
            return False
        jid = "summary-" + uuid.uuid4().hex[:8]
        _jobs[jid] = {"id": jid, "text": "", "mode": "summary", "kind": "summary", "summaryKind": kind, "key": key,
                      "material": material, "status": "queued", "answer": None, "created": time.time()}
        _queue.append(jid)
    return True


MAX_APP_DESKS = 30   # オフィスに並べる Claude アプリの会話（Code タブ・Cowork・定期タスク）の上限


# 初めから入っている部署の、題名によく出る語（部署の説明から取る語に足す。個人名・社名は入れない）
DEFAULT_KEYWORDS = {
    "planning": ["企画", "計画", "目標", "ロードマップ", "戦略", "KPI", "優先", "方針", "事業", "進め方", "アイデア", "ダッシュボード", "dashboard", "plan"],
    "research": ["調査", "調べ", "確認", "比較", "件数", "集計", "分析", "解析", "状況", "一覧", "レビュー", "review", "抽出", "推移", "実績", "要約", "analysis",
                 "analyze", "summary", "research"],
    "programmer": ["システム", "DB", "データベース", "API", "コード", "バグ", "不具合", "実装", "テスト", "修正", "直す", "fix",
                   "エラー", "同期", "設定", "GAS", "スクリプト", "自動化", "仕組み", "移行", "デプロイ", "脆弱性", "スプレッドシート",
                   "スプシ", "試験", "ツール", "アプリ", "system", "bug", "test", "deploy", "excel", "sync", "automation",
                   "implementation", "tool", "app", "setup", "merge"],
    "designer": ["デザイン", "画面", "UI", "図", "資料", "スライド", "パワポ", "レイアウト", "画像", "動画", "design", "slide"],
    "general": ["書類", "案内", "文書", "連絡", "下書き", "送付", "手続き", "申請", "出勤", "カレンダー", "予定", "メール", "記事", "翻訳", "招待", "通知", "アナウンス",
                "article", "translation", "invite", "meeting", "transcript"],
}


def dept_keywords(d: dict) -> list[str]:
    """部署の振り分けに使う語。表示名・設定の keywords・初めからの部署の語（DEFAULT_KEYWORDS）と、
    説明の「（部署）。」より後ろを 、・ で区切った語（「設定の修正」は「設定」「修正」も）。英字は小文字にそろえる"""
    words = [d.get("label") or "", d.get("name") or ""]
    if isinstance(d.get("keywords"), list):
        words += [w for w in d["keywords"] if isinstance(w, str)]
    words += DEFAULT_KEYWORDS.get(d.get("name") or "", [])
    desc = str(d.get("description") or "")
    desc = desc.split("。", 1)[1] if "（部署）。" in desc else desc
    for w in re.split(r"[、・,，。()（）\s]+", desc):
        words.append(w)
        if "の" in w:
            words += w.split("の", 1)
    return sorted({w.lower() for w in words if len(w) >= 2 or (w and not w.isascii())}, key=len, reverse=True)


def _kw_in(k: str, hay: str) -> bool:
    """英字の語は、単語の頭からだけ当てる（"required" の中の "ui" などに当たらないように。後ろは複数形などのため見ない）"""
    if k.isascii():
        return re.search(r"(?<![a-z0-9])" + re.escape(k), hay) is not None
    return k in hay


def assign_department(title: str, dept_defs: list[dict]) -> str:
    """題名に入っている語がいちばん多い部署へ（同じ数なら長い語が当たった方、それも同じなら並び順）。
    作業フォルダは見ない（本番の assign_department と同じ考え）。どれにも当たらなければ「その他」"""
    hay = (title or "").replace("仕様", "").lower()   # 「仕様」の「様」が顧客名用の語に当たらないように
    best, best_score = OTHER_DEPT["id"], (0, 0)
    for d in dept_defs:
        hits = [k for k in d["keywords"] if _kw_in(k, hay)]
        score = (len(hits), max((len(k) for k in hits), default=0))
        if score > best_score:
            best, best_score = d["id"], score
    return best


def app_desks(dept_defs: list[dict], owner: dict | None, web: bool) -> list[dict]:
    """Claude アプリの会話（Code タブ・Cowork）と定期タスクの実行を、題名で部署に振り分けてデスクにする（Mac だけ）。
    この画面を動かしている会話（執行役。作業フォルダが同じもの）は出さない。Web には本文・作業フォルダを出さない"""
    if not apps.enabled():
        return []
    try:
        v = apps.view(web=web, ask=False)
    except Exception as e:  # 読めなくてもオフィスは出す
        sys.stderr.write(f"[server] Claude アプリの会話を読めませんでした: {e!r}\n")
        return []
    own = (owner or {}).get("cwd")
    out = []
    for r in v.get("sessions", []):
        if r["status"] == "idle" or (own and apps.home_short(r.get("cwd")) == own):
            continue
        out.append({
            "key": f"app:{r['id']}", "title": r["title"], "source": r["source"], "taskId": None,
            "status": r["status"], "count": 1, "lastActivityAt": r["lastActivityAt"], "lastTool": None if web else r.get("lastTool"),
            "lastText": None if web else short(r.get("lastText"), 160), "recap": r.get("recap"), "ask": r.get("ask"),
            "waitFor": r.get("waitFor"), "cwd": None if web else r.get("cwd"), "model": r.get("model"), "pr": r.get("pr"),
            "link": r.get("link"), "task": None, "sessions": [], "runId": None,
            "department": assign_department(r["title"], dept_defs), "instruction": None, "result": None,
        })
    # 定期タスク: 有効なものの、直近の実行（SHOW_WITHIN_SEC より新しいものだけ）。実行中・失敗・完了で色を変える
    now = time.time() * 1000
    for t in v.get("tasks", []):
        last = t.get("lastRun") if isinstance(t.get("lastRun"), dict) else None
        if t.get("state") != "enabled" or not last or (now - to_ms(last.get("at"))) / 1000 > SHOW_WITHIN_SEC:
            continue
        st = str(last.get("status") or "")
        status = "working" if st == "実行中" else "waiting" if st == "失敗" or "要対応" in st else "done"
        name = t.get("name") or t.get("id") or "定期タスク"
        out.append({
            "key": f"task:{t.get('id')}", "title": name, "source": "task", "taskId": t.get("id"), "status": status,
            "count": 1, "lastActivityAt": last.get("at"), "lastTool": None, "lastText": None, "recap": None,
            "ask": st if status == "waiting" else None, "waitFor": None, "cwd": None, "model": None,
            "pr": None, "link": None, "task": None, "sessions": [], "runId": None,
            "department": assign_department(f"{name} {t.get('id') or ''}", dept_defs), "instruction": None, "result": None,
        })
    return out[:MAX_APP_DESKS]


def build_state(web: bool = False) -> dict:
    """画面用の状態。仕事1件＝デスク1つ。部署・表示名は設定（プラグインが保存した値。無ければ config/org.json）から。
    Claude アプリの会話・定期タスクも、題名で部署へ振り分けて並べる（本番の build_state と同じ考え）"""
    org = load_org()
    ex_org = org.get("executive") if isinstance(org.get("executive"), dict) else {}
    cfg, _ = effective_settings()
    executive = {"name": ex_org.get("name") or "執行役", "title": cfg["displayName"],
                 "image": ex_org.get("image") or "executive", "color": ex_org.get("color") or "#3b4a6b"}
    dept_defs = [{"id": d["name"], "name": d.get("label") or d["name"], "image": d.get("image") or ROLE_IMAGE.get(d["name"], "support"),
                  "color": d.get("color") or "#5b6677", "keywords": dept_keywords(d)} for d in cfg["departments"]]
    with _lock:
        conv = {k: (list(v) if isinstance(v, list) else v) for k, v in _conv.items() if k != "outputs"}
        sg = dict(_suggest)
        jobs = [dict(j) for j in _jobs.values() if j.get("kind") == "exec"]
        alive = (time.time() - _last_poll) < 10
    with _lock:
        notes = [dict(n) for n in _notes]
    messages = conv["messages"]
    now = time.time() * 1000
    tasks = sorted(conv["tasks"], key=lambda t: t.get("startedAt") or "", reverse=True)[:MAX_TASKS]
    tasks = [{**t, "outputs": out_info(t.get("outputs"))} for t in tasks]
    user_texts = [m["text"] for m in messages if m["role"] == "user"]
    # まだ会話に入っていない依頼（待ち行列・入れた直後）も、送った発言として先に出す
    pending = []
    for j in sorted(jobs, key=lambda x: x["created"]):
        if j.get("mode") == "stop":
            continue
        if _job_active(j) and not any(j["text"] in t for t in user_texts):
            pending.append({"id": "p-" + j["id"], "role": "user", "text": j["display"], "ts": iso_of(j["created"]),
                            "files": j.get("files") or []})
        elif j["status"] == "failed" and time.time() - j["created"] < STALE_JOB_SEC:
            # 会話に入ってから止めた・失敗したものと、会話に入る前に終わったものを分けて書く
            reached = any(j["text"] in t for t in user_texts)
            head = "この依頼は途中で終わりました: " if reached else "この依頼は会話に届きませんでした: "
            note = {"id": "f-" + j["id"], "role": "note", "text": head + (j.get("answer") or ""), "ts": iso_of(j["created"])}
            if not reached and j.get("retryable"):   # 会話に届かなかった発言は、同じ中身で送り直せる（/api/exec/retry）
                note.update(kind="retry", retry=j["id"], retried=bool(j.get("retried")))
            pending.append(note)
    out_msgs = []
    for m in messages:
        if m["role"] == "files":
            m = {**m, "outputs": out_info(m["outputs"])}
            if not m["outputs"]:
                continue
        out_msgs.append(m)
    for n in notes:   # 止めるボタンの結果などは、時刻の合う位置に入れる
        at = next((i for i, m in enumerate(out_msgs) if to_ms(m.get("ts")) > to_ms(n["ts"])), len(out_msgs))
        out_msgs.insert(at, n)
    out_msgs += pending
    # 仕事1件＝デスク1つ（本番の build_state と同じ作り）。終わった仕事は SHOW_WITHIN_SEC だけ出す
    desks = []
    for t in tasks:
        if t["status"] != "working" and (now - (to_ms(t.get("finishedAt") or t.get("startedAt")))) / 1000 > SHOW_WITHIN_SEC:
            continue
        desks.append({
            "key": f"exec:{t['id']}", "title": t["title"], "source": "run", "taskId": None,
            "status": DESK_STATUS.get(t["status"], "idle"), "count": 1,
            "lastActivityAt": t.get("finishedAt") or (t["tools"][-1]["ts"] if t.get("tools") else t.get("startedAt")),
            "lastTool": t.get("live"), "lastText": short(t.get("summary") or t.get("live") or t.get("prompt"), 160),
            "recap": None, "ask": "止まりました" if t["status"] == "failed" else None,
            "cwd": None, "model": t.get("model"), "pr": None, "link": None, "task": None, "sessions": [],
            "runId": "exec", "department": t["department"], "instruction": t.get("prompt"), "result": t.get("summary"),
        })
    desks += app_desks(dept_defs, conv.get("owner"), web)
    desks.sort(key=lambda d: (RANK[d["status"]], -(to_ms(d["lastActivityAt"]) if d["lastActivityAt"] else 0)))
    summary = {k: sum(1 for d in desks if d["status"] == k) for k in RANK}
    # 部署ごとの状態（いちばん忙しい担当の状態）。「その他」は仕事があるときだけ
    departments = []
    for dep in dept_defs + [OTHER_DEPT]:
        members = [d for d in desks if d["department"] == dep["id"]]
        if not members and dep is OTHER_DEPT:
            continue
        st = min((m["status"] for m in members), key=lambda k: RANK[k]) if members else "idle"
        latest = max(members, key=lambda m: m["lastActivityAt"] or "") if members else None
        departments.append({
            "id": dep["id"], "name": dep["name"], "head": "責任者", "image": dep["image"], "color": dep["color"],
            "status": st, "counts": {k: sum(1 for m in members if m["status"] == k) for k in RANK},
            "members": [m["key"] for m in members], "lastActivityAt": latest["lastActivityAt"] if latest else None,
            "ask": next((m["ask"] for m in members if m["status"] == "waiting" and m.get("ask")), None), "waitFor": None})
    active = [j for j in jobs if _job_active(j)]
    busy = bool(conv["busy"]) or bool(active)
    busy_since = conv["busySince"] or (iso_of(min(j["created"] for j in active)) if active else None)
    tgt = suggest_target(out_msgs, busy)
    suggest = {"for": tgt["id"], "text": sg["text"]} if tgt and sg.get("for") == tgt["id"] and sg.get("status") == "ready" else None
    # 予測の状態（pending / ready / none=「なし」・空 / failed=作れなかった）と失敗の理由。画面の診断用（文は suggest だけが運ぶ）
    suggest_status = ({"for": tgt["id"], "status": sg.get("status"), "reason": sg.get("reason")}
                      if tgt and sg.get("for") == tgt["id"] and sg.get("status") else None)
    ex = {"sessionId": None, "alive": alive, "busy": busy, "busySince": busy_since if busy else None,
          "live": conv["live"] if busy else None, "messages": out_msgs, "tasks": tasks, "cost": 0, "limit": None,
          "usage": fresh_usage(conv["usage"], time.time()), "context": conv["context"], "suggest": suggest,
          "model": conv["model"] or "", "editGroups": {}, "edit": None,
          "suggestStatus": suggest_status, "owner": conv.get("owner"),
          "permits": permits_view(conv.get("permits") or [], web) if alive else []}
    return {"generatedAt": now_iso(), "summary": summary, "executive": executive, "departments": departments,
            "desks": desks, "threadTitles": {}, "executiveBusy": busy,
            "exec": ex, "events": [], "tasks": [], "features": {**FEATURES, "addness": addness.enabled(), "apps": apps.enabled()},
            "app": {"name": cfg["displayName"]}, "platform": platform_name()}


WEB_DIR_RE = re.compile(r"^web-(\d{8})-\d{6}-[0-9a-f]{6}$")


def _dir_size(d: Path) -> int:
    n = 0
    try:
        for p in d.iterdir():
            try:
                if p.is_file() and not p.is_symlink():
                    n += p.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return n


def web_attach_today_bytes(now: datetime | None = None) -> int:
    """今日 Web から受けた添付の合計（バイト）"""
    day = (now or datetime.now()).strftime("%Y%m%d")
    root = DATA_DIR / "attachments"
    total = 0
    try:
        for d in root.iterdir():
            m = WEB_DIR_RE.match(d.name)
            if m and m.group(1) == day and d.is_dir() and not d.is_symlink():
                total += _dir_size(d)
    except OSError:
        pass
    return total


def cleanup_web_attachments(now: datetime | None = None, keep_days: int = WEB_ATTACH_KEEP_DAYS) -> int:
    """Web 経由の添付（web-日付-… のフォルダ）のうち、keep_days 日より古いものを消す。消した数を返す。Web 以外の添付には触らない"""
    cut = ((now or datetime.now()) - timedelta(days=keep_days)).strftime("%Y%m%d")
    root = DATA_DIR / "attachments"
    n = 0
    try:
        for d in root.iterdir():
            m = WEB_DIR_RE.match(d.name)
            if m and m.group(1) < cut and d.is_dir() and not d.is_symlink():
                shutil.rmtree(d, ignore_errors=True)
                n += 1
    except OSError:
        pass
    return n


def save_attachments(files, web: bool = False) -> list:
    """base64 の添付をデータ置き場（リポジトリの外）に保存する。返り値: [{name,size,path}]。
    web=True（Web 経由）は、フォルダ名を web- で始め、1日あたりの合計に上限（WEB_ATTACH_DAY_BYTES）を設ける。7日より古い Web の添付は消す"""
    if not isinstance(files, list):
        raise ValueError("files は配列です")
    if len(files) > MAX_ATTACH_FILES:
        raise ValueError(f"添付は{MAX_ATTACH_FILES}件までです")
    saved, total = [], 0
    if web:
        cleanup_web_attachments()
        used = web_attach_today_bytes()
    d = DATA_DIR / "attachments" / (("web-" if web else "") + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6])
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("添付の形が違います")
        name = re.sub(r"[/\\\0:]", "_", str(f.get("name") or "file")).lstrip(".")[:120] or "file"
        try:
            data = base64.b64decode(f.get("data") or "", validate=True)
        except (binascii.Error, ValueError):
            raise ValueError(f"添付 {name} を読み取れません")
        total += len(data)
        if total > MAX_ATTACH_TOTAL:
            raise ValueError("添付ファイルが大きすぎます（合計50MBまで）")
        if web and used + total > WEB_ATTACH_DAY_BYTES:
            shutil.rmtree(d, ignore_errors=True)   # 途中まで書いたものは残さない
            raise ValueError(f"Web からの添付は、1日あたり合計{WEB_ATTACH_DAY_BYTES // (1024 * 1024)}MBまでです（今日はあと{max(0, WEB_ATTACH_DAY_BYTES - used) // 1024}KB）")
        d.mkdir(parents=True, exist_ok=True)
        fp = d / name
        i = 1
        while fp.exists():
            fp = d / f"{i}_{name}"
            i += 1
        fp.write_bytes(data)
        saved.append({"name": fp.name, "size": len(data), "path": str(fp)})
    return saved


def open_allowed(fp: Path) -> bool:
    """会話に出てきたパス（できたファイル）か、保存した添付だけ"""
    with _lock:
        known = {path_key(str(Path(os.path.expanduser(p)).resolve())) for p in _conv["outputs"]}
    if path_key(str(fp)) in known:
        return True
    att = path_key(str((DATA_DIR / "attachments").resolve()))
    return any(path_key(str(a)) == att for a in fp.parents)


def open_command(fp: str, reveal: bool, plat: str | None = None) -> tuple[list, bool]:
    """ファイルを開く（または置き場所を見せる）コマンド。返り値 (argv, 終了コードを厳密に見るか)。
    Mac: open / open -R、Windows: explorer / explorer /select,<パス>（explorer は成功でも 1 を返すので見ない）、その他: xdg-open"""
    plat = plat or sys.platform
    if plat == "darwin":
        return ["open", *(["-R"] if reveal else []), fp], True
    if plat in ("win32", "cygwin"):
        return (["explorer", f"/select,{fp}"] if reveal else ["explorer", fp]), False
    return ["xdg-open", os.path.dirname(fp) if reveal else fp], True


def open_output(path: str, reveal: bool, web: bool = False) -> dict:
    if not path or len(path) > 1024 or "\0" in path:
        raise ValueError("パスがありません")
    fp = Path(os.path.expanduser(path)).resolve()
    if not open_allowed(fp):
        raise ValueError("この会話に出てきていないファイルは開けません")
    if fp.suffix.lower() not in DOC_EXT:
        raise ValueError("書類（Excel・PDF・Word・画像など）以外は開けません")
    if web and not reveal and fp.suffix.lower() not in WEB_OPEN_EXT:   # 見るのは実体（リンクの先）の拡張子
        raise ValueError("Web からは、マクロ付き・実行できる形のファイルは開けません（PDF・Excel・Word・画像などだけ）")
    if not fp.is_file():
        raise ValueError("ファイルが見つかりません（移動・削除された可能性）")
    argv, strict = open_command(str(fp), reveal)
    r = subprocess.run(argv, capture_output=True, text=True, timeout=15)
    if strict and r.returncode != 0:
        raise ValueError(r.stderr.strip() or "開けませんでした")
    return {"ok": True}


FILE_SEND_MAX = 5 * 1024 * 1024   # Web 版へ送り返すファイルの上限（base64 にして約 7MB。橋渡しの答えの上限 8MB の内）
FILE_MIME = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
             ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8", ".csv": "text/csv; charset=utf-8",
             ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xls": "application/vnd.ms-excel",
             ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12", ".doc": "application/msword",
             ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
             ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
             ".zip": "application/zip", ".dxf": "application/dxf"}


def read_output(path: str) -> dict:
    """Web 版の「開く」：できたファイルの中身を base64 で返す（開ける範囲は open_output と同じ。大きさは FILE_SEND_MAX まで）"""
    if not path or len(path) > 1024 or "\0" in path:
        raise ValueError("パスがありません")
    fp = Path(os.path.expanduser(path)).resolve()
    if not open_allowed(fp):
        raise ValueError("この会話に出てきていないファイルは開けません")
    if fp.suffix.lower() not in DOC_EXT:
        raise ValueError("書類（Excel・PDF・Word・画像など）以外は開けません")
    if not fp.is_file():
        raise ValueError("ファイルが見つかりません（移動・削除された可能性）")
    size = fp.stat().st_size
    if size > FILE_SEND_MAX:
        raise ValueError(f"大きすぎて Web には送れません（{size // (1024 * 1024)}MB。5MB まで）。パソコンで開いてください")
    data = fp.read_bytes()[:FILE_SEND_MAX + 1]
    if len(data) > FILE_SEND_MAX:
        raise ValueError("大きすぎて Web には送れません（5MB まで）。パソコンで開いてください")
    return {"ok": True, "name": fp.name, "mime": FILE_MIME.get(fp.suffix.lower(), "application/octet-stream"),
            "size": len(data), "data": base64.b64encode(data).decode("ascii")}


class Handler(BaseHTTPRequestHandler):
    server_version = "AssistantTrial/0.1"
    token = ""
    web_key = ""   # 橋渡しと共有する起動ごとの合言葉（MYAI_WEB_ORIGIN_KEY）。これを付けた依頼だけを「Web から」と記録する
    port = 0
    version = "?"

    # ---- 共通 ----
    def log_message(self, fmt, *args):  # 標準エラーに短く（プラグインの debug ログへ流れる）
        sys.stderr.write("[server] " + (fmt % args) + "\n")

    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").strip().lower()
        return host in (f"127.0.0.1:{self.port}", f"localhost:{self.port}")

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        return origin.lower() in (f"http://127.0.0.1:{self.port}", f"http://localhost:{self.port}")

    def _bridge_ok(self) -> bool:
        got = self.headers.get("X-Bridge-Token") or ""
        return bool(self.token) and hmac.compare_digest(got, self.token)

    def _send(self, code: int, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(data)

    def _screen_ok(self) -> bool:
        return self.headers.get("X-My-AI-Assistant") == "1" and self._origin_ok()

    def _web(self):
        """Web から来た依頼の印を調べる。返り値: (ok, fp)。印が無ければ (True, None)＝手元の画面。
        印（X-Web-Origin）があって合言葉と違うなら (False, None)＝断る。合っていれば (True, 橋渡しが付けたブラウザの指紋)"""
        got = self.headers.get("X-Web-Origin")
        if got is None:
            return True, None
        if not self.web_key or not hmac.compare_digest(got, self.web_key):
            return False, None
        fp = re.sub(r"[^0-9a-f]", "", (self.headers.get("X-Web-Browser") or "").lower())[:64]
        return True, (fp or "unknown")

    def _json_body(self, limit=64 * 1024):
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            return None
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if n <= 0 or n > limit:
            return None
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return None

    # ---- GET ----
    def do_GET(self):
        global _last_poll
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            html = (HERE / "index.html").read_bytes()
            return self._send(200, html, "text/html; charset=utf-8")
        if path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if path == "/api/state":
            web_ok, web_fp = self._web()
            return self._send(200, build_state(web=web_fp is not None or not web_ok))
        if path.startswith("/assets/"):
            root = (HERE / "assets").resolve()
            fp = (root / path[len("/assets/"):]).resolve()
            if root not in fp.parents or not fp.is_file() or fp.suffix.lower() not in CTYPES:
                return self._send(404, {"error": "not found"})
            return self._send(200, fp.read_bytes(), CTYPES[fp.suffix.lower()])
        if path == "/api/settings":   # 画面の設定「アシスタント」：今の値と、既定・上限・使える画像
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            cfg, synced = effective_settings()
            with _lock:
                alive = (time.time() - _last_poll) < 10
            return self._send(200, {"ok": True, "synced": synced, "connected": alive, "settings": cfg,
                                    "defaults": {"displayName": default_name(), "departments": default_departments(), "compactWindow": COMPACT_DEFAULT},
                                    "compactChoices": list(COMPACT_CHOICES),
                                    "limits": dict(LIMITS), "images": list(ROLE_IMAGES), "models": list(MODELS)})
        if path == "/api/health":
            with _lock:
                alive = (time.time() - _last_poll) < 10
            return self._send(200, {"app": APP, "version": self.version, "pluginConnected": alive})
        if path.startswith("/api/jobs/"):
            jid = path[len("/api/jobs/"):]
            with _lock:
                job = _jobs.get(jid)
                view = dict(job) if job else None
            if not view:
                return self._send(404, {"error": "no such job"})
            return self._send(200, view)
        if path == "/api/bridge/addness-draft":   # プラグインから：Addness の下書きの道具を出すか（Addness の設定があるか）
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            return self._send(200, {"ok": True, "enabled": addness.load_config() is not None})
        if path == "/api/addness/items":   # Addness のやること（設定が無ければ enabled: False）
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            try:
                return self._send(200, addness_chat.items_view())
            except Exception as e:
                return self._send(500, {"error": repr(e)})
        if path in addness_chat.SCREEN_GET:   # Addness の今すぐ更新の状態・相談の中身（A2・A3）
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            qs = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
            return self._send(*addness_chat.screen_get(path, qs))
        if path == "/api/apps":   # Claude アプリの会話・Cowork・定期タスクの一覧（読むだけ。Web からは本文を出さない）
            web_ok, web_fp = self._web()
            if not self._origin_ok() or not web_ok:
                return self._send(403, {"error": "bad origin"})
            try:
                return self._send(200, apps.view(web=web_fp is not None))
            except Exception as e:
                return self._send(500, {"error": repr(e)})
        if path.startswith("/api/history/"):   # 全期間の会話（読むだけ・同じパソコンの画面と、プラグインの検索の道具から）
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            return self._history_get(path)
        if path == "/api/bridge/next":
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            with _lock:
                _last_poll = time.time()
                if not _queue:
                    job = None
                else:
                    job = _jobs[_queue.pop(0)]
                    job["status"] = "running"
                    job = dict(job)
            if not job:
                self.send_response(204)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            return self._send(200, job)
        return self._send(404, {"error": "not found"})

    def _history_get(self, path: str):
        qs = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
        try:
            if path == "/api/history/stats":
                return self._send(200, history.stats())
            if path == "/api/history/search":
                res = history.search(qs.get("q", "")[:500], source=qs.get("source") or None, since=qs.get("since") or None,
                                     limit=max(1, min(int(qs.get("limit", 40)), 100)), per_session=3)
                return self._send(200, {"results": res})
            if path == "/api/history/sessions":
                return self._send(200, history.list_sessions(source=qs.get("source") or None, title=qs.get("title") or None,
                                                             offset=max(0, int(qs.get("offset", 0))), limit=max(1, min(int(qs.get("limit", 50)), 200))))
            if path == "/api/history/session":
                s = history.get_session(qs.get("sid", ""), offset=max(0, int(qs.get("offset", 0))), limit=max(1, min(int(qs.get("limit", 300)), 1000)))
                return self._send(200 if s else 404, s or {"error": "not found"})
            if path == "/api/history/memory":
                return self._send(200, {"text": history.memory_index()})
        except ValueError:
            return self._send(400, {"error": "数の指定が正しくありません"})
        except Exception as e:
            return self._send(500, {"error": repr(e)})
        return self._send(404, {"error": "not found"})

    # ---- POST ----
    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = self.path.split("?", 1)[0]
        if path == "/api/ask":  # 画面から
            if self.headers.get("X-My-AI-Assistant") != "1" or not self._origin_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body()
            text = (body or {}).get("text") if isinstance(body, dict) else None
            mode = (body or {}).get("mode", "chat") if isinstance(body, dict) else "chat"
            if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT or mode not in MODES:
                return self._send(400, {"error": "text (1-4000 chars) and mode (agent|chat) required"})
            jid = uuid.uuid4().hex[:12]
            with _lock:
                _jobs[jid] = {"id": jid, "text": text.strip(), "mode": mode, "status": "queued",
                              "answer": None, "created": time.time()}
                _queue.append(jid)
            return self._send(200, {"id": jid})
        if path == "/api/settings":  # 画面から（設定の保存。検証して待ち行列へ。保存するのはプラグイン）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body(MAX_BODY_SETTINGS)
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "JSON の本文が要ります（256KB まで）"})
            try:
                clean = validate_settings(body)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            if not clean:
                return self._send(400, {"ok": False, "error": "変える項目がありません"})
            if web_fp is not None:
                guard_web_tools(clean)   # Web からは、部署の tools（使える道具）を変えさせない
            jid = "settings-" + uuid.uuid4().hex[:8]
            with _lock:
                for i in list(_queue):   # まだ受け取られていない前の保存は、新しい方に置き換える
                    if _jobs[i].get("mode") == "settings":
                        _queue.remove(i)
                        _jobs[i]["status"], _jobs[i]["answer"] = "failed", "新しい保存に置き換わりました"
                _jobs[jid] = {"id": jid, "text": "", "mode": "settings", "kind": "settings", "settings": clean,
                              "status": "queued", "answer": None, "created": time.time(),
                              **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                _queue.append(jid)
            return self._send(200, {"ok": True, "id": jid})
        if path == "/api/bridge/settings":  # プラグインから：保存した（または起動時に読んだ）今の設定を知らせる
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body(MAX_BODY_SETTINGS)
            try:
                clean = validate_settings(body)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            global _settings_synced
            with _lock:
                for k in ("displayName", "extraInstructions", "departments", "compactWindow"):
                    if k in clean:
                        _settings[k] = clean[k]
                _settings["customDepartments"] = bool(isinstance(body, dict) and body.get("customDepartments"))
                _settings_synced = True
            return self._send(200, {"ok": True})
        if path == "/api/exec/send":  # 画面から（執行役への発言。添付は保存して本文にパスを付ける）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body(MAX_BODY_SEND)
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "JSON の本文が要ります（添付は合計50MBまで）"})
            text = body.get("text")
            text = text.strip() if isinstance(text, str) else ""
            files = body.get("files") or []
            if (not text and not files) or len(text) > MAX_SEND_TEXT:
                return self._send(400, {"ok": False, "error": "発言が空か、長すぎます"})
            try:
                saved = save_attachments(files, web=web_fp is not None)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            lines = "\n".join(f"添付: {x['path']}" for x in saved)
            full = "\n\n".join(x for x in (text, lines) if x)
            jid = uuid.uuid4().hex[:12]
            fl = [{"name": x["name"], "size": x["size"]} for x in saved]
            with _lock:
                _jobs[jid] = {"id": jid, "text": full.strip(), "mode": "chat", "status": "queued", "answer": None,
                              "created": time.time(), "kind": "exec", "display": text, "files": fl, "retryable": True,
                              **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                _queue.append(jid)
            return self._send(200, {"ok": True, "message": {"id": "p-" + jid, "role": "user", "text": text,
                                                              "ts": now_iso(), "files": fl}})
        if path == "/api/exec/retry":  # 画面から（会話に届かなかった発言を、サーバーに残っている元の中身のまま、もう一度送る）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            if not isinstance(body, dict) or set(body) != {"id"} or not isinstance(body.get("id"), str) \
                    or not re.fullmatch(r"[0-9a-f]{12}", body["id"]):
                return self._send(400, {"ok": False, "error": "id だけを渡してください"})
            with _lock:
                old = _jobs.get(body["id"])
                user_texts = [m["text"] for m in _conv["messages"] if m["role"] == "user"]
                if not old or not old.get("retryable") or old.get("kind") != "exec" or old.get("mode") != "chat" \
                        or old.get("status") != "failed" or time.time() - old["created"] >= STALE_JOB_SEC \
                        or any(old["text"] in t for t in user_texts):
                    return self._send(404, {"ok": False, "error": "送り直せる発言が見つかりません（届かなかった発言だけ・10分以内）"})
                if old.get("retried"):
                    return self._send(409, {"ok": False, "error": "この発言は、もう送り直しました"})
                if web_fp is not None:   # Web からは、送信（/api/exec/send）と同じ決まり。元の発言が手元の画面からのものでも同じに見る
                    why = web_text_refusal(old.get("display") or "") or web_text_refusal(old["text"])
                    if why:
                        return self._send(403, {"ok": False, "error": why})
                old["retried"] = True
                jid = uuid.uuid4().hex[:12]
                _jobs[jid] = {"id": jid, "text": old["text"], "mode": "chat", "status": "queued", "answer": None,
                              "created": time.time(), "kind": "exec", "display": old.get("display") or "", "files": list(old.get("files") or []),
                              "retryable": True, "retryOf": old["id"],
                              **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                _queue.append(jid)
            return self._send(200, {"ok": True, "id": jid})
        if path == "/api/exec/run":  # 画面から（▶ 実行：執行役の発言のコードを「実行してください」の依頼にして会話に入れる。ここでは実行しない）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            if not isinstance(body, dict) or set(body) != {"msg", "idx"} or not isinstance(body.get("msg"), str) \
                    or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", body["msg"]) or type(body.get("idx")) is not int or not 0 <= body["idx"] <= 999:
                return self._send(400, {"ok": False, "error": "msg（発言の id）と idx（何番目のブロックか）だけを渡してください"})
            with _lock:
                msgs = list(_conv["messages"])
            try:
                req = run_block(msgs, body["msg"], body["idx"])
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            # Web からの依頼には、執行役に分かる印を先に付ける（実行するかどうか・許可の確認は、いつもどおり会話の Claude とエンジンが決める）
            text = (WEB_RUN_MARK + "\n" + req) if web_fp is not None else req
            jid = uuid.uuid4().hex[:12]
            with _lock:
                _jobs[jid] = {"id": jid, "text": text, "mode": "chat", "status": "queued", "answer": None,
                              "created": time.time(), "kind": "exec", "display": text, "files": [], "run": True,
                              **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                _queue.append(jid)
            return self._send(200, {"ok": True, "message": {"id": "p-" + jid, "role": "user", "text": text, "ts": now_iso(), "files": []}})
        if path == "/api/exec/suggest":  # 画面から（入力の予測を頼む。作るのはプラグイン。同じ返事には1回だけ。自動では送らない）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, _fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            for_id = str((body or {}).get("for") or "") if isinstance(body, dict) else ""
            st = build_state()["exec"]
            tgt = suggest_target(st["messages"], bool(st["busy"]))
            if not tgt or tgt["id"] != for_id:
                return self._send(200, {"ok": True, "status": "skip"})
            with _lock:
                if _suggest.get("for") == for_id:
                    return self._send(200, {"ok": True, "status": _suggest.get("status")})
                _suggest.clear()
                _suggest.update({"for": for_id, "status": "pending", "text": None, "reason": None})
                recent = [m["text"] for m in st["messages"] if m["role"] == "user" and (m.get("text") or "").strip()][-SUGGEST_RECENT:]
                jid = "suggest-" + uuid.uuid4().hex[:8]
                _jobs[jid] = {"id": jid, "text": "", "mode": "suggest", "kind": "suggest", "forId": for_id, "status": "queued",
                              "reply": (tgt.get("text") or "")[-SUGGEST_TAIL:], "recent": [r[:300] for r in recent],
                              "answer": None, "created": time.time()}
                _queue.append(jid)
            return self._send(200, {"ok": True, "status": "pending"})
        if path == "/api/exec/stop":  # 画面から（いま動いている発言を止める）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            with _lock:
                if not any(_jobs[i].get("mode") == "stop" for i in _queue):
                    jid = "stop-" + uuid.uuid4().hex[:8]
                    _jobs[jid] = {"id": jid, "text": "", "mode": "stop", "status": "queued", "answer": None,
                                  "created": time.time(), "kind": "exec",
                                  **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                    _queue.append(jid)
                for i in list(_queue):  # まだ会話に入っていない依頼は取り下げる
                    j = _jobs[i]
                    if j.get("kind") == "exec" and j.get("mode") not in ("stop", "stoptask"):
                        _queue.remove(i)
                        j["status"], j["answer"] = "failed", "止めました"
            return self._send(200, {"ok": True})
        m = re.fullmatch(r"/api/exec/tasks/([^/]{1,128})/stop", path)
        if m:  # 画面から（仕事を1つ止める。止めるのはプラグイン）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            tid = urllib.parse.unquote(m.group(1))
            with _lock:
                task = next((t for t in _conv["tasks"] if t["id"] == tid), None)
                if not task:
                    return self._send(404, {"ok": False, "error": "その仕事が見つかりません"})
                if task["status"] != "working":
                    return self._send(200, {"ok": True, "stopped": 0})
                if not any(_jobs[i].get("mode") == "stoptask" and _jobs[i].get("taskId") == tid for i in _queue):
                    jid = "stoptask-" + uuid.uuid4().hex[:8]
                    _jobs[jid] = {"id": jid, "text": "", "mode": "stoptask", "taskId": tid, "title": task["title"],
                                  "status": "queued", "answer": None, "created": time.time(), "kind": "exec",
                                  **({"origin": "web", "webFp": web_fp} if web_fp is not None else {})}
                    _queue.append(jid)
            return self._send(200, {"ok": True, "stopped": 1})
        if path in ("/api/addness/done", "/api/addness/undone"):  # 画面から（済み・元に戻す）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            ok, _fp = self._web()
            if not ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            iid = body.get("id") if isinstance(body, dict) else None
            if not isinstance(iid, str) or not iid or len(iid) > 300:
                return self._send(400, {"error": "id required"})
            try:
                res = addness.mark_done(iid) if path.endswith("/done") else addness.undo_done(iid)
            except ValueError as e:
                return self._send(200, {"ok": False, "error": str(e)})
            except Exception as e:
                return self._send(500, {"ok": False, "error": repr(e)})
            return self._send(200, res)
        if path in addness_chat.SCREEN_POST:  # 画面から（今すぐ更新・相談・止める・送信OK。A2〜A4）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            ok, fp = self._web()
            if not ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body(MAX_BODY_SEND if path == "/api/addness/chat" else 64 * 1024)
            return self._send(*addness_chat.screen_post(path, body, web=fp is not None))
        if path == "/api/open":  # 画面の「開く」「Finder で表示」
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, web_fp = self._web()
            if not web_ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "path が要ります"})
            # Web 版からは {path, reveal: true}（Finder で表示）か {path}（開く・WEB_OPEN_EXT の拡張子だけ）の形だけ（bridge/lib/policy.mjs と同じ決まり）
            if web_fp is not None and not (set(body) == {"path"} or (set(body) == {"path", "reveal"} and body.get("reveal") is True)):
                return self._send(403, {"ok": False, "error": "Web 版から渡せるのは {path} か {path, reveal: true} だけです"})
            try:
                return self._send(200, open_output(str(body.get("path") or ""), body.get("reveal") is True, web=web_fp is not None))
            except (ValueError, subprocess.SubprocessError, OSError) as e:
                return self._send(400, {"ok": False, "error": str(e)})
        if path == "/api/apps/open":  # 画面の「チャットを開く」：Claude アプリの会話をアプリで開く（手元の画面だけ。id だけを受け取る）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            web_ok, _fp = self._web()   # Web 版からも開ける（本文は {id} だけ・実在する会話だけ。bridge/lib/policy.mjs と同じ決まり）。合言葉が違えば断る
            if not web_ok:
                return self._send(403, {"ok": False, "error": "bad web origin"})
            if not apps.enabled():
                return self._send(404, {"ok": False, "error": "Claude アプリの一覧が使えません"})
            body = self._json_body()
            if not isinstance(body, dict) or set(body) != {"id"}:
                return self._send(400, {"ok": False, "error": "id だけを渡してください"})
            try:
                return self._send(200, apps.open_chat(str(body.get("id") or "")))
            except (ValueError, subprocess.SubprocessError, OSError) as e:
                return self._send(400, {"ok": False, "error": str(e)})
        if path == "/api/file":  # 画面から（Web 版の「開く」：できたファイルの中身を送り返す）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            ok, _fp = self._web()
            if not ok:
                return self._send(403, {"error": "bad web origin"})
            body = self._json_body()
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "path が要ります"})
            try:
                return self._send(200, read_output(str(body.get("path") or "")))
            except (ValueError, OSError) as e:
                return self._send(400, {"ok": False, "error": str(e)})
        if path == "/api/bridge/state":  # プラグインから（会話の中身）
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body(MAX_BODY_STATE)
            if not isinstance(body, dict):
                return self._send(400, {"error": "state required"})
            msgs = clean_messages(body.get("messages"))
            valid = {d["name"] for d in effective_settings()[0]["departments"]} | {"other"}
            tasks = clean_tasks(body.get("tasks"), valid)
            outs = {p for m in msgs if m["role"] == "files" for p in m["outputs"]} | {p for t in tasks for p in t["outputs"]}
            with _lock:
                _conv.update(messages=msgs, busy=bool(body.get("busy")), busySince=_str(body.get("busySince"), 40),
                             live=_str(body.get("live"), 200), model=_str(body.get("model"), 100),
                             tasks=tasks, outputs=outs, at=time.time(),
                             usage=clean_usage(body.get("usage")), context=clean_context(body.get("context")),
                             owner=clean_owner(body.get("owner")), permits=clean_permits(body.get("permits")))
            return self._send(200, {"ok": True, "count": len(msgs), "tasks": len(tasks)})
        if path == "/api/bridge/addness-draft":  # プラグインから：執行役の返信を相談チャットの下書きカードにする（投稿はしない）
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body()
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "JSON の本文が要ります"})
            try:
                return self._send(200, addness_chat.office_draft(body))
            except ValueError as e:
                return self._send(200, {"ok": False, "error": str(e)})
        if path == "/api/bridge/drop-web":  # プラグインから：web-off / web-revoke のとき、Web から来てまだ会話に入っていない依頼を捨てる
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body()
            fp = body.get("fp") if isinstance(body, dict) and isinstance(body.get("fp"), str) and body.get("fp") else None
            dropped, running = 0, 0
            with _lock:
                for i in list(_queue):
                    j = _jobs[i]
                    if j.get("origin") == "web" and (fp is None or j.get("webFp") == fp):
                        _queue.remove(i)
                        j["status"], j["answer"] = "failed", "Web の取り消し・停止で捨てました"
                        dropped += 1
                for j in _jobs.values():   # もう会話に入っている（動いている）Web の依頼。数だけ知らせる
                    if j.get("origin") == "web" and j.get("status") == "running" and j.get("kind") == "exec" and j.get("mode") not in ("stop", "stoptask") \
                            and (fp is None or j.get("webFp") == fp) and time.time() - j["created"] < STALE_JOB_SEC:
                        running += 1
            return self._send(200, {"ok": True, "dropped": dropped, "running": running})
        if path == "/api/bridge/shutdown":  # プラグインから：新しい版が入ったので、持ち主がサーバーを手放す
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            self._send(200, {"ok": True})
            threading.Thread(target=Handler.httpd.shutdown, daemon=True).start()
            return
        if path == "/api/bridge/result":  # プラグインから
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body()
            if not isinstance(body, dict) or not isinstance(body.get("id"), str):
                return self._send(400, {"error": "id required"})
            with _lock:
                job = _jobs.get(body["id"])
                if not job:
                    return self._send(404, {"error": "no such job"})
                job["status"] = "done" if body.get("ok") else "failed"
                job["answer"] = str(body.get("text") or "")[:20000]
                if job.get("mode") == "summary":   # 要約：apps.py が覚える。中身は /api/jobs に残さない
                    apps.accept(job.get("summaryKind"), job.get("key"), bool(body.get("ok")), job["answer"])
                    job["answer"], job["material"] = "", ""
                    return self._send(200, {"ok": True})
                if job.get("mode") == "suggest":   # 入力の予測：まだ同じ返事が最後のときだけ置く。出すのは ready のときだけ
                    if _suggest.get("for") == job.get("forId"):
                        if not body.get("ok"):   # 作れなかった：failed と短い理由（理由は suggestStatus で見える）
                            _suggest.update(status="failed", text=None, reason=short(job["answer"], 80) or "理由は不明です")
                        else:
                            line = unquote((job["answer"].strip().splitlines() or [""])[0])
                            if not line or line == "なし":
                                _suggest.update(status="none", text=None, reason=None)
                            elif len(line) > SUGGEST_MAX_LEN:
                                _suggest.update(status="failed", text=None, reason=f"予測が長すぎました（{len(line)}字）")
                            else:
                                _suggest.update(status="ready", text=line, reason=None)
                    job["answer"] = ""   # 予測の中身は /api/jobs に残さない
                    return self._send(200, {"ok": True})
                if isinstance(body.get("note"), str) and body["note"].strip():   # 止めるボタンの結果を会話に一言出す
                    _notes.append({"id": "n-" + uuid.uuid4().hex[:8], "role": "note", "text": body["note"][:500], "ts": now_iso()})
                    del _notes[:-20]
            return self._send(200, {"ok": True})
        return self._send(404, {"error": "not found"})


class Server(ThreadingHTTPServer):
    request_queue_size = 64   # 同時に来る接続の待ち行列（既定の5だと、30接続で切られた。W5）
    daemon_threads = True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8790)
    ap.add_argument("--version", default="?")
    ap.add_argument("--data-dir", default="")
    args = ap.parse_args()
    for stream in (sys.stdout, sys.stderr):   # Windows の既定（cp932 など）で日本語のログが落ちないように
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    global DATA_DIR
    if args.data_dir:
        DATA_DIR = Path(args.data_dir)
    elif not os.environ.get("MYAI_DATA_DIR"):
        msg = migrate_old_data_dir(Path.home())
        if msg:
            sys.stderr.write("[server] " + msg + "\n")
    if args.port == 8787:
        sys.exit("8787 は本番の画面のポートなので使いません")
    history.configure(DATA_DIR / "history.db", DATA_DIR)
    addness.configure(DATA_DIR)
    addness_chat.configure(save_attachments)
    apps.configure(DATA_DIR, enqueue=enqueue_summary)
    history.start_background(interval=300)   # 起動時に1回、その後5分ごとに差分を取り込む（裏のスレッド）
    Handler.token = os.environ.get("MYAI_BRIDGE_TOKEN", "")
    Handler.web_key = os.environ.get("MYAI_WEB_ORIGIN_KEY", "")
    cleanup_web_attachments()   # 起動時に、7日より古い Web の添付を消す
    # 会話の一覧（オフィスの机）を先に裏で読んでおく。最初の /api/state が数秒待たないように
    threading.Thread(target=lambda: apps.enabled() and apps.view(ask=False), daemon=True).start()
    Handler.port = args.port
    Handler.version = args.version
    if not Handler.token:
        sys.stderr.write("[server] MYAI_BRIDGE_TOKEN がありません（プラグインからの答えを受け取れません）\n")
    httpd = Server(("127.0.0.1", args.port), Handler)
    Handler.httpd = httpd
    print(f"LISTENING http://127.0.0.1:{args.port}/", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
