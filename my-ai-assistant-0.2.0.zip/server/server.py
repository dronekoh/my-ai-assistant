#!/usr/bin/env python3
"""AI Assistant（既定の表示名 My AI Assistant）プラグイン版の試作サーバー（Python 標準ライブラリだけ）。

役目は「画面を出す」と「画面からの依頼を預かる」だけ。Claude は呼ばない。
依頼は、プラグイン（Claude Code の中で動く）が取りに来て、その Claude の中で仕事をして、答えを返しに来る。

    画面 --POST /api/ask--> このサーバー <--GET /api/bridge/next-- プラグイン
    画面 <--GET /api/jobs/<id>-- このサーバー <--POST /api/bridge/result-- プラグイン
    画面 <--GET /api/state------- このサーバー <--POST /api/bridge/state--- プラグイン（会話の中身）
    画面 --POST /api/exec/send--> このサーバー（添付を保存し、依頼として待ち行列へ。▶ 実行も「実行してください」の依頼としてここへ）
画面 --POST /api/exec/suggest--> このサーバー（入力の予測の依頼 → プラグインが作って答えを返す）
画面 --GET /api/history/*----> このサーバー（全会話の索引 history.py。プラグインの検索の道具も同じ口を呼ぶ）
画面 --GET/POST /api/settings-> このサーバー（設定「アシスタント」。POST は検証して待ち行列へ → プラグインが $.store に保存し、
                               /api/bridge/settings で今の値をこのサーバーへ知らせる。GET はその値を返す）

守り:
- 127.0.0.1 だけで待つ（社外・LAN から届かない）
- Host が 127.0.0.1:<port> / localhost:<port> 以外は断る（DNS rebinding よけ）
- 画面からの POST は独自ヘッダ X-My-AI-Assistant と JSON を必須にする（よそのサイトからの送り込みよけ）
- プラグイン用の口は、起動時に環境変数 MYAI_BRIDGE_TOKEN で渡された合言葉が要る
"""
from __future__ import annotations

import argparse
import base64
import binascii
import hmac
import history
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = "my-ai-assistant"
MAX_TEXT = 4000            # /api/ask（簡易）
MAX_SEND_TEXT = 100000     # /api/exec/send
MAX_ATTACH_TOTAL = 50 * 1024 * 1024
MAX_ATTACH_FILES = 20
MAX_BODY_SEND = 80 * 1024 * 1024   # base64 は 4/3 倍になるので 50MB の添付が入る大きさ
MAX_BODY_STATE = 4 * 1024 * 1024
MAX_MSG_TEXT = 20000
MAX_MESSAGES = 300
MAX_TASKS = 60
SHOW_WITHIN_SEC = 24 * 3600   # 終わった仕事は、これより古ければデスクに出さない（本番と同じ考え）
OTHER_DEPT = {"id": "other", "name": "その他", "image": "support", "color": "#5b6677"}
TASK_STATUS = ("working", "done", "failed", "stopped")
DESK_STATUS = {"working": "working", "done": "done", "failed": "waiting", "stopped": "idle"}   # 仕事 → デスク
RANK = {"working": 0, "waiting": 1, "done": 2, "idle": 3}
MODES = ("agent", "chat")
# 画面から開けるファイルの種類（アプリ・スクリプトは開かない）
DOC_EXT = {".xlsx", ".xls", ".xlsm", ".csv", ".pdf", ".docx", ".doc", ".pptx", ".png", ".jpg", ".jpeg",
           ".zip", ".dxf", ".txt", ".md"}
# 出す機能の切り替え（画面はこれを見て出し分ける。false のものは隠す）。tasks は仕事一覧
FEATURES = {"tasks": True, "history": True, "suggest": True, "usage": True, "edit": True, "runCommand": True}
ROLE_IMAGE = {"planning": "planning", "research": "analyst", "programmer": "programmer",
              "designer": "designer", "general": "support"}
CTYPES = {".js": "text/javascript; charset=utf-8", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
          ".png": "image/png", ".webp": "image/webp", ".css": "text/css; charset=utf-8"}

_lock = threading.Lock()
_jobs: dict = {}          # id -> {id, text, mode, status, answer, created}
_queue: list = []         # 未着手の id（古い順）
_last_poll = 0.0          # プラグインが最後に取りに来た時刻
_conv: dict = {"messages": [], "busy": False, "busySince": None, "live": None, "model": None,
               "tasks": [], "outputs": set(), "at": 0.0, "usage": None, "context": None, "owner": None}   # プラグインが送ってきた会話の中身（画面用の形）
_suggest: dict = {}       # 入力の予測 {"for": 返事の id, "status": pending|ready|none|failed, "text": 予測, "reason": 失敗の理由}（メモリだけ）
SUGGEST_TAIL = 3000       # 予測に渡す執行役の返事（末尾の文字数）
SUGGEST_RECENT = 4        # 渡す利用者の直近の発言の数
SUGGEST_MAX_LEN = 40      # これより長い予測は出さない（切れた文が出ると紛らわしい）
LIMIT_KEYS = ("five_hour", "seven_day")
_notes: list = []         # 止めるボタンの結果など、画面の会話に出す一言 {id, role:"note", text, ts}
DATA_DIR = Path(os.environ.get("MYAI_DATA_DIR") or (Path.home() / ".my-ai-assistant"))
OLD_DATA_DIR_NAME = ".koh-assistant"   # v0.2.0 より前の名前（データ置き場の移し替えだけに使う）


def migrate_old_data_dir(home: Path) -> str:
    """旧名 ~/.koh-assistant の中身を、新しい ~/.my-ai-assistant へコピーする（新しい方が無いときだけ。元は消さない）。
    途中で失敗しても半端な新フォルダを残さないよう、一時の名前へコピーしてから付け替える。戻り値は結果の一言（何もしないときは空）"""
    new, old = home / ".my-ai-assistant", home / OLD_DATA_DIR_NAME
    if new.exists() or not old.is_dir():
        return ""
    tmp = home / ".my-ai-assistant.migrating"
    try:
        if tmp.exists():
            shutil.rmtree(tmp)
        shutil.copytree(old, tmp)
        tmp.rename(new)
    except OSError as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return "移し替えに失敗しました（旧データはそのまま）: %s" % e
    return "旧データ置き場 %s を %s へコピーしました（元は残してあります）" % (old, new)
STALE_JOB_SEC = 10 * 60   # これより古い未完了の依頼は「処理中」の表示に使わない（プラグインが止まったとき）

# ---- 設定「アシスタント」（段7）----
# プラグイン（hooks/register.tsx の validateSettings）と同じ上限・同じ規則。変えるときは両方を直す（tests が両方を確かめる）
DEFAULT_NAME = "My AI Assistant"
LIMITS = {"displayName": 30, "extraInstructions": 2000, "departments": 12, "deptName": 32, "label": 20,
          "description": 300, "prompt": 4000, "tools": 30}
MAX_BODY_SETTINGS = 256 * 1024
DEPT_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")
MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$")
TOOL_RE = re.compile(r"^[A-Za-z0-9_*:.-]{1,100}$")
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
EFFORTS = ("low", "medium", "high", "xhigh", "max")
MODELS = ("sonnet", "opus", "haiku", "inherit")
ROLE_IMAGES = ("executive", "planning", "analyst", "programmer", "designer", "support", "hr", "marketing", "sales", "accounting")
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")          # 改行・タブ以外の制御文字
_CTRL_LINE = re.compile(r"[\x00-\x1f\x7f]")                        # 1行の欄：改行・タブも不可
_settings: dict = {"displayName": None, "extraInstructions": "", "departments": None, "customDepartments": False}   # プラグインが知らせた今の値（None=まだ届いていない）
_settings_synced = False


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def iso_of(epoch: float) -> str:
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def load_org() -> dict:
    try:
        d = json.loads((HERE.parent / "config" / "org.json").read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _str(v, n: int, default=None):
    return v[:n] if isinstance(v, str) else default


def clean_messages(raw) -> list:
    """プラグインから来た会話を、画面が読める形だけに絞る（余計な項目は捨てる・長さを抑える）"""
    out = []
    if not isinstance(raw, list):
        return out
    for m in raw[-MAX_MESSAGES:]:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant", "step", "note", "files"):
            continue
        item = {"id": _str(m.get("id"), 64, f"m{len(out)}"), "role": m["role"],
                "text": _str(m.get("text"), MAX_MSG_TEXT, "").replace("\r\n", "\n"), "ts": _str(m.get("ts"), 40, None)}
        if m["role"] == "step":
            item["kind"] = _str(m.get("kind"), 20, "tool")
            item["text"] = item["text"][:300]
        if m["role"] == "files":
            item["outputs"] = [p for p in (m.get("outputs") or [])
                                if isinstance(p, str) and len(p) < 1024 and os.path.splitext(p)[1].lower() in DOC_EXT][:20]
            if not item["outputs"]:
                continue
        if m["role"] == "user" and isinstance(m.get("files"), list):
            item["files"] = [{"name": _str(f.get("name"), 120, ""), "size": f.get("size") if isinstance(f.get("size"), int) else None}
                             for f in m["files"] if isinstance(f, dict)][:20]
        out.append(item)
    return out


def clean_context(raw):
    """会話の量（本番の ctx_view と同じ形）：tokens・window・pct・at・source・compact・compacting"""
    if not isinstance(raw, dict):
        return None
    window = raw.get("window")
    if not isinstance(window, (int, float)) or isinstance(window, bool) or window <= 0:
        return None
    tokens = raw.get("tokens")
    tokens = int(tokens) if isinstance(tokens, (int, float)) and not isinstance(tokens, bool) and tokens >= 0 else None
    pct = raw.get("pct")
    pct = float(pct) if isinstance(pct, (int, float)) and not isinstance(pct, bool) else (
        round(tokens * 100 / window, 1) if tokens is not None else None)
    return {"tokens": tokens, "window": int(window), "pct": pct, "at": _str(raw.get("at"), 40), "source": _str(raw.get("source"), 20, "plugin"),
            "compact": None, "compacting": False}


def platform_name(plat: str | None = None) -> str:
    """画面に伝える OS の種類（できたファイルの置き場所を開くボタンの名前に使う）"""
    plat = plat or sys.platform
    return "mac" if plat == "darwin" else "windows" if plat in ("win32", "cygwin") else "linux"


def path_key(p: str, pm=os.path) -> str:
    """パスの照合用の形。区切り（/ と \\）・大文字小文字（Windows）・. や .. をそろえる。pm=ntpath で Windows の規則になる"""
    return pm.normcase(pm.normpath(p))


def home_short(p, home: str | None = None, pm=os.path) -> str | None:
    """作業フォルダなどの絶対パス。ホームフォルダ（利用者名を含む）は ~ に置き換えて出す。
    Windows の C:\\Users\\x\\… も C:/Users/x/… も同じ家として扱う（pm=ntpath のとき）。~ の後ろは元の区切りのまま"""
    if not isinstance(p, str) or not p or len(p) > 500 or "\0" in p:
        return None
    home = home if home is not None else str(Path.home())
    if not home:
        return p
    kp, kh = path_key(p, pm), path_key(home, pm)
    if kp == kh:
        return "~"
    if kp.startswith(kh.rstrip("\\/") + pm.sep):
        rest = p[len(home.rstrip("\\/")):]
        return "~" + (rest if rest[:1] in ("/", "\\") else pm.sep + rest)
    return p


def clean_owner(raw):
    """この画面を出している会話の情報（作業フォルダ・プロジェクトの場所・会話の開始時刻・プラグインの版だけ）"""
    if not isinstance(raw, dict):
        return None
    out = {"cwd": home_short(raw.get("cwd")), "root": home_short(raw.get("root")),
           "startedAt": _str(raw.get("startedAt"), 40), "version": _str(raw.get("version"), 20)}
    return out if any(v for v in out.values()) else None


PAIRS = (("「", "」"), ("『", "』"), ('"', '"'), ("'", "'"), ("`", "`"), ("“", "”"))


def _wrapped(t: str) -> bool:
    """文全体が、対になる引用符で1組だけ囲まれているか（文頭の「だけ・文中の」は囲みではない）"""
    if len(t) < 2:
        return False
    for o, c in PAIRS:
        if t[0] != o or t[-1] != c:
            continue
        inner, depth = t[1:-1], 0
        if o == c:
            return o not in inner      # "A" と "B" のように途中でも閉じていれば、全体の囲みではない
        for ch in inner:
            depth += 1 if ch == o else -1 if ch == c else 0
            if depth < 0:
                break
        else:
            if depth == 0:
                return True
    return False


def unquote(line: str) -> str:
    """予測の1行から、全体を囲む引用符だけを外す（対になるときだけ。文頭・文末の片方だけは残す）"""
    t = (line or "").strip()
    while _wrapped(t):
        t = t[1:-1].strip()
    return t


def clean_usage(raw):
    """利用上限（本番の _limit_view と同じ形）：{status, five_hour: {pct, resetsAt, at}|None, seven_day: …}"""
    if not isinstance(raw, dict):
        return None
    out = {"status": _str(raw.get("status"), 40)}
    for k in LIMIT_KEYS:
        w = raw.get(k)
        pct = w.get("pct") if isinstance(w, dict) else None
        if not isinstance(pct, (int, float)) or isinstance(pct, bool):
            out[k] = None
            continue
        r = w.get("resetsAt")
        out[k] = {"pct": min(round(float(pct), 1), 100.0), "resetsAt": int(r) if isinstance(r, (int, float)) and not isinstance(r, bool) else None,
                  "at": _str(w.get("at"), 40)}
    return out


def fresh_usage(usage, now_sec: float):
    """リセット時刻を過ぎた窓の値は古いので出さない（本番の _limit_view と同じ考え）"""
    if not isinstance(usage, dict):
        return None
    out = dict(usage)
    for k in LIMIT_KEYS:
        w = out.get(k)
        if isinstance(w, dict) and isinstance(w.get("resetsAt"), int) and w["resetsAt"] <= now_sec:
            out[k] = None
    return out


def suggest_target(messages: list, busy: bool):
    """予測の対象：いちばん最後の執行役の返事（その後に利用者の発言が無く、執行役が待っているときだけ）"""
    if busy:
        return None
    for m in reversed(messages):
        if m.get("role") == "user":
            return None
        if m.get("role") == "assistant" and (m.get("text") or "").strip():
            return m
    return None


def short(s, n: int = 120) -> str:
    t = re.sub(r"\s+", " ", str(s or "")).strip()
    return t if len(t) <= n else t[: n - 1] + "…"


def to_ms(v) -> float:
    """ISO 文字列（Z 付きも可）をミリ秒に。読めなければ 0"""
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp() * 1000
    except (ValueError, TypeError):
        return 0.0


def clean_tasks(raw, valid_depts) -> list:
    """プラグインから来た仕事（部署1つ＝1件）を、画面が読める形だけに絞る"""
    out = []
    if not isinstance(raw, list):
        return out
    for t in raw[:MAX_TASKS]:
        if not isinstance(t, dict) or not isinstance(t.get("id"), str) or not t["id"] or len(t["id"]) > 128:
            continue
        dept = _str(t.get("department"), 64, "other")
        tools = [{"ts": _str(x.get("ts"), 40, None), "text": _str(x.get("text"), 300, "")}
                 for x in (t.get("tools") or []) if isinstance(x, dict)][-40:]
        outs = [p for p in (t.get("outputs") or [])
                if isinstance(p, str) and len(p) < 1024 and os.path.splitext(p)[1].lower() in DOC_EXT][:20]
        out.append({
            "id": t["id"], "taskId": t["id"], "department": dept if dept in valid_depts else "other",
            "title": _str(t.get("title"), 60, "仕事"), "prompt": _str(t.get("prompt"), 2000, ""),
            "model": _str(t.get("model"), 100, ""), "background": bool(t.get("background")),
            "status": t.get("status") if t.get("status") in TASK_STATUS else "working",
            "startedAt": _str(t.get("startedAt"), 40, None), "finishedAt": _str(t.get("finishedAt"), 40, None),
            "summary": _str(t.get("summary"), 8000, None), "tools": tools, "live": _str(t.get("live"), 200, None),
            "outputs": outs, "sessionId": None})
    return out


def out_info(paths: list) -> list:
    res = []
    for fp in paths or []:
        try:
            st = os.stat(fp)
        except OSError:
            continue
        res.append({"path": fp, "name": os.path.basename(fp),
                    "dir": home_short(os.path.dirname(fp)) or "",
                    "ext": os.path.splitext(fp)[1].lower().lstrip("."), "size": st.st_size,
                    "mtime": iso_of(st.st_mtime)})
    return res


def _text(v, name: str, max_len: int, *, line: bool, required: bool = False):
    """文字列の欄を検証する。前後の空白は除く。長さは文字数（サロゲートペアも1字）"""
    if not isinstance(v, str):
        raise ValueError(f"{name}は文字列で入れてください")
    t = v.strip()
    if (_CTRL_LINE if line else _CTRL).search(t):
        raise ValueError(f"{name}に使えない文字（改行や制御文字）が入っています" if line else f"{name}に使えない制御文字が入っています")
    if len(t) > max_len:
        raise ValueError(f"{name}は{max_len}文字までです（いま{len(t)}文字）")
    if required and not t:
        raise ValueError(f"{name}を入れてください")
    return t


def clean_dept(raw, index: int, defaults: dict | None = None) -> dict:
    """部署1件を検証して整える。名前は英小文字・数字・ハイフン。画像は ROLE_IMAGES から、色は #rrggbb"""
    if not isinstance(raw, dict):
        raise ValueError(f"部署{index + 1}の形が違います")
    d = defaults or {}
    nm = _text(raw.get("name"), f"部署{index + 1}の名前", LIMITS["deptName"], line=True, required=True)
    if not DEPT_NAME_RE.match(nm):
        raise ValueError(f"部署の名前「{nm}」は、半角の英小文字・数字・ハイフンだけにしてください（先頭は英小文字か数字）")
    out = {"name": nm,
           "label": _text(raw.get("label") if raw.get("label") not in (None, "") else nm, f"部署「{nm}」の表示名", LIMITS["label"], line=True),
           "description": _text(raw.get("description"), f"部署「{nm}」の説明", LIMITS["description"], line=True, required=True),
           "prompt": _text(raw.get("prompt"), f"部署「{nm}」の指示", LIMITS["prompt"], line=False, required=True)}
    model = raw.get("model") if raw.get("model") not in (None, "") else d.get("model", "sonnet")
    if not isinstance(model, str) or not MODEL_RE.match(model):
        raise ValueError(f"部署「{nm}」のモデルの指定が正しくありません")
    out["model"] = model
    effort = raw.get("effort") if raw.get("effort") is not None else d.get("effort")
    if effort is not None:
        ok = (isinstance(effort, str) and effort in EFFORTS) or (isinstance(effort, int) and not isinstance(effort, bool) and 1 <= effort <= 200000)
        if not ok:
            raise ValueError(f"部署「{nm}」の effort が正しくありません")
        out["effort"] = effort
    tools = raw.get("tools")
    if tools is not None:
        if not isinstance(tools, list) or len(tools) > LIMITS["tools"] or not all(isinstance(t, str) and TOOL_RE.match(t) for t in tools):
            raise ValueError(f"部署「{nm}」の tools の指定が正しくありません")
        out["tools"] = list(tools)
    img = raw.get("image") if raw.get("image") not in (None, "") else ROLE_IMAGE.get(nm, "support")
    if img not in ROLE_IMAGES:
        raise ValueError(f"部署「{nm}」の画像の指定が正しくありません")
    out["image"] = img
    color = raw.get("color") if raw.get("color") not in (None, "") else "#5b6677"
    if not isinstance(color, str) or not COLOR_RE.match(color):
        raise ValueError(f"部署「{nm}」の色の指定が正しくありません")
    out["color"] = color
    return out


def validate_settings(raw) -> dict:
    """設定の更新（部分でよい）を検証する。返り値は「渡された項目だけ」の整った値。不正なら ValueError（日本語の理由）。
    displayName: null か空 → 既定に戻す（None）。extraInstructions: null → ''。departments: null → 既定（org.json）に戻す"""
    if not isinstance(raw, dict):
        raise ValueError("設定の形が違います")
    out: dict = {}
    if "displayName" in raw:
        v = raw["displayName"]
        out["displayName"] = None if v is None or (isinstance(v, str) and not v.strip()) else _text(v, "表示名", LIMITS["displayName"], line=True)
    if "extraInstructions" in raw:
        v = raw["extraInstructions"]
        out["extraInstructions"] = "" if v is None else _text(v, "執行役への追加の指示", LIMITS["extraInstructions"], line=False)
    if "departments" in raw:
        v = raw["departments"]
        if v is None:
            out["departments"] = None
        else:
            if not isinstance(v, list):
                raise ValueError("部署は一覧で入れてください")
            if len(v) > LIMITS["departments"]:
                raise ValueError(f"部署は{LIMITS['departments']}件までです（いま{len(v)}件）")
            depts, seen = [], set()
            for i, x in enumerate(v):
                d = clean_dept(x, i)
                if d["name"] in seen:
                    raise ValueError(f"部署の名前「{d['name']}」が重なっています")
                seen.add(d["name"])
                depts.append(d)
            out["departments"] = depts
    return out


def default_departments() -> list:
    """config/org.json の部署（既定）。読めない・形が違う部署は飛ばす"""
    org = load_org()
    base = org.get("defaults") if isinstance(org.get("defaults"), dict) else {}
    out = []
    for i, x in enumerate(org.get("departments") or []):
        try:
            d = clean_dept(x, i, base)
        except ValueError:
            continue
        out.append(d)
    return out


def default_name() -> str:
    ex = load_org().get("executive")
    t = ex.get("title") if isinstance(ex, dict) else None
    return t.strip() if isinstance(t, str) and t.strip() and len(t.strip()) <= LIMITS["displayName"] else DEFAULT_NAME


def effective_settings() -> dict:
    """いまの設定（画面に見せる形）。プラグインから届いていなければ既定（org.json）"""
    with _lock:
        st = dict(_settings)
        synced = _settings_synced
    depts = st["departments"] if st["departments"] is not None else default_departments()
    return {"displayName": st["displayName"] or default_name(), "extraInstructions": st["extraInstructions"] or "",
            "departments": depts, "customDepartments": bool(st["customDepartments"])}, synced


def _job_active(job: dict) -> bool:
    return (job.get("kind") == "exec" and job.get("mode") not in ("stop", "stoptask") and job["status"] in ("queued", "running")
            and time.time() - job["created"] < STALE_JOB_SEC)


def build_state() -> dict:
    """画面用の状態。仕事1件＝デスク1つ。部署・表示名は設定（プラグインが保存した値。無ければ config/org.json）から"""
    org = load_org()
    ex_org = org.get("executive") if isinstance(org.get("executive"), dict) else {}
    cfg, _ = effective_settings()
    executive = {"name": ex_org.get("name") or "執行役", "title": cfg["displayName"],
                 "image": ex_org.get("image") or "executive", "color": ex_org.get("color") or "#3b4a6b"}
    dept_defs = [{"id": d["name"], "name": d.get("label") or d["name"], "image": d.get("image") or ROLE_IMAGE.get(d["name"], "support"),
                  "color": d.get("color") or "#5b6677"} for d in cfg["departments"]]
    with _lock:
        conv = {k: (list(v) if isinstance(v, list) else v) for k, v in _conv.items() if k != "outputs"}
        sg = dict(_suggest)
        jobs = [dict(j) for j in _jobs.values() if j.get("kind") == "exec"]
        alive = (time.time() - _last_poll) < 10
    with _lock:
        notes = [dict(n) for n in _notes]
    messages = conv["messages"]
    now = time.time() * 1000
    tasks = sorted(conv["tasks"], key=lambda t: t.get("startedAt") or "", reverse=True)[:MAX_TASKS]
    tasks = [{**t, "outputs": out_info(t.get("outputs"))} for t in tasks]
    user_texts = [m["text"] for m in messages if m["role"] == "user"]
    # まだ会話に入っていない依頼（待ち行列・入れた直後）も、送った発言として先に出す
    pending = []
    for j in sorted(jobs, key=lambda x: x["created"]):
        if j.get("mode") == "stop":
            continue
        if _job_active(j) and not any(j["text"] in t for t in user_texts):
            pending.append({"id": "p-" + j["id"], "role": "user", "text": j["display"], "ts": iso_of(j["created"]),
                            "files": j.get("files") or []})
        elif j["status"] == "failed" and time.time() - j["created"] < STALE_JOB_SEC:
            # 会話に入ってから止めた・失敗したものと、会話に入る前に終わったものを分けて書く
            reached = any(j["text"] in t for t in user_texts)
            head = "この依頼は途中で終わりました: " if reached else "この依頼は会話に届きませんでした: "
            pending.append({"id": "f-" + j["id"], "role": "note", "text": head + (j.get("answer") or ""),
                            "ts": iso_of(j["created"])})
    out_msgs = []
    for m in messages:
        if m["role"] == "files":
            m = {**m, "outputs": out_info(m["outputs"])}
            if not m["outputs"]:
                continue
        out_msgs.append(m)
    for n in notes:   # 止めるボタンの結果などは、時刻の合う位置に入れる
        at = next((i for i, m in enumerate(out_msgs) if to_ms(m.get("ts")) > to_ms(n["ts"])), len(out_msgs))
        out_msgs.insert(at, n)
    out_msgs += pending
    # 仕事1件＝デスク1つ（本番の build_state と同じ作り）。終わった仕事は SHOW_WITHIN_SEC だけ出す
    desks = []
    for t in tasks:
        if t["status"] != "working" and (now - (to_ms(t.get("finishedAt") or t.get("startedAt")))) / 1000 > SHOW_WITHIN_SEC:
            continue
        desks.append({
            "key": f"exec:{t['id']}", "title": t["title"], "source": "run", "taskId": None,
            "status": DESK_STATUS.get(t["status"], "idle"), "count": 1,
            "lastActivityAt": t.get("finishedAt") or (t["tools"][-1]["ts"] if t.get("tools") else t.get("startedAt")),
            "lastTool": t.get("live"), "lastText": short(t.get("summary") or t.get("live") or t.get("prompt"), 160),
            "recap": None, "ask": "止まりました" if t["status"] == "failed" else None,
            "cwd": None, "model": t.get("model"), "pr": None, "link": None, "task": None, "sessions": [],
            "runId": "exec", "department": t["department"], "instruction": t.get("prompt"), "result": t.get("summary"),
        })
    desks.sort(key=lambda d: (RANK[d["status"]], -(to_ms(d["lastActivityAt"]) if d["lastActivityAt"] else 0)))
    summary = {k: sum(1 for d in desks if d["status"] == k) for k in RANK}
    # 部署ごとの状態（いちばん忙しい担当の状態）。「その他」は仕事があるときだけ
    departments = []
    for dep in dept_defs + [OTHER_DEPT]:
        members = [d for d in desks if d["department"] == dep["id"]]
        if not members and dep is OTHER_DEPT:
            continue
        st = min((m["status"] for m in members), key=lambda k: RANK[k]) if members else "idle"
        latest = max(members, key=lambda m: m["lastActivityAt"] or "") if members else None
        departments.append({
            "id": dep["id"], "name": dep["name"], "head": "責任者", "image": dep["image"], "color": dep["color"],
            "status": st, "counts": {k: sum(1 for m in members if m["status"] == k) for k in RANK},
            "members": [m["key"] for m in members], "lastActivityAt": latest["lastActivityAt"] if latest else None,
            "ask": next((m["ask"] for m in members if m["status"] == "waiting" and m.get("ask")), None), "waitFor": None})
    active = [j for j in jobs if _job_active(j)]
    busy = bool(conv["busy"]) or bool(active)
    busy_since = conv["busySince"] or (iso_of(min(j["created"] for j in active)) if active else None)
    tgt = suggest_target(out_msgs, busy)
    suggest = {"for": tgt["id"], "text": sg["text"]} if tgt and sg.get("for") == tgt["id"] and sg.get("status") == "ready" else None
    # 予測の状態（pending / ready / none=「なし」・空 / failed=作れなかった）と失敗の理由。画面の診断用（文は suggest だけが運ぶ）
    suggest_status = ({"for": tgt["id"], "status": sg.get("status"), "reason": sg.get("reason")}
                      if tgt and sg.get("for") == tgt["id"] and sg.get("status") else None)
    ex = {"sessionId": None, "alive": alive, "busy": busy, "busySince": busy_since if busy else None,
          "live": conv["live"] if busy else None, "messages": out_msgs, "tasks": tasks, "cost": 0, "limit": None,
          "usage": fresh_usage(conv["usage"], time.time()), "context": conv["context"], "suggest": suggest,
          "model": conv["model"] or "", "editGroups": {}, "edit": None,
          "suggestStatus": suggest_status, "owner": conv.get("owner")}
    return {"generatedAt": now_iso(), "summary": summary, "executive": executive, "departments": departments,
            "desks": desks, "threadTitles": {}, "executiveBusy": busy,
            "exec": ex, "events": [], "tasks": [], "features": dict(FEATURES),
            "app": {"name": cfg["displayName"]}, "platform": platform_name()}


def save_attachments(files) -> list:
    """base64 の添付をデータ置き場（リポジトリの外）に保存する。返り値: [{name,size,path}]"""
    if not isinstance(files, list):
        raise ValueError("files は配列です")
    if len(files) > MAX_ATTACH_FILES:
        raise ValueError(f"添付は{MAX_ATTACH_FILES}件までです")
    saved, total = [], 0
    d = DATA_DIR / "attachments" / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6])
    for f in files:
        if not isinstance(f, dict):
            raise ValueError("添付の形が違います")
        name = re.sub(r"[/\\\0:]", "_", str(f.get("name") or "file")).lstrip(".")[:120] or "file"
        try:
            data = base64.b64decode(f.get("data") or "", validate=True)
        except (binascii.Error, ValueError):
            raise ValueError(f"添付 {name} を読み取れません")
        total += len(data)
        if total > MAX_ATTACH_TOTAL:
            raise ValueError("添付ファイルが大きすぎます（合計50MBまで）")
        d.mkdir(parents=True, exist_ok=True)
        fp = d / name
        i = 1
        while fp.exists():
            fp = d / f"{i}_{name}"
            i += 1
        fp.write_bytes(data)
        saved.append({"name": fp.name, "size": len(data), "path": str(fp)})
    return saved


def open_allowed(fp: Path) -> bool:
    """会話に出てきたパス（できたファイル）か、保存した添付だけ"""
    with _lock:
        known = {path_key(str(Path(os.path.expanduser(p)).resolve())) for p in _conv["outputs"]}
    if path_key(str(fp)) in known:
        return True
    att = path_key(str((DATA_DIR / "attachments").resolve()))
    return any(path_key(str(a)) == att for a in fp.parents)


def open_command(fp: str, reveal: bool, plat: str | None = None) -> tuple[list, bool]:
    """ファイルを開く（または置き場所を見せる）コマンド。返り値 (argv, 終了コードを厳密に見るか)。
    Mac: open / open -R、Windows: explorer / explorer /select,<パス>（explorer は成功でも 1 を返すので見ない）、その他: xdg-open"""
    plat = plat or sys.platform
    if plat == "darwin":
        return ["open", *(["-R"] if reveal else []), fp], True
    if plat in ("win32", "cygwin"):
        return (["explorer", f"/select,{fp}"] if reveal else ["explorer", fp]), False
    return ["xdg-open", os.path.dirname(fp) if reveal else fp], True


def open_output(path: str, reveal: bool) -> dict:
    if not path or len(path) > 1024 or "\0" in path:
        raise ValueError("パスがありません")
    fp = Path(os.path.expanduser(path)).resolve()
    if not open_allowed(fp):
        raise ValueError("この会話に出てきていないファイルは開けません")
    if fp.suffix.lower() not in DOC_EXT:
        raise ValueError("書類（Excel・PDF・Word・画像など）以外は開けません")
    if not fp.is_file():
        raise ValueError("ファイルが見つかりません（移動・削除された可能性）")
    argv, strict = open_command(str(fp), reveal)
    r = subprocess.run(argv, capture_output=True, text=True, timeout=15)
    if strict and r.returncode != 0:
        raise ValueError(r.stderr.strip() or "開けませんでした")
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    server_version = "AssistantTrial/0.1"
    token = ""
    port = 0
    version = "?"

    # ---- 共通 ----
    def log_message(self, fmt, *args):  # 標準エラーに短く（プラグインの debug ログへ流れる）
        sys.stderr.write("[server] " + (fmt % args) + "\n")

    def _host_ok(self) -> bool:
        host = (self.headers.get("Host") or "").strip().lower()
        return host in (f"127.0.0.1:{self.port}", f"localhost:{self.port}")

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        return origin.lower() in (f"http://127.0.0.1:{self.port}", f"http://localhost:{self.port}")

    def _bridge_ok(self) -> bool:
        got = self.headers.get("X-Bridge-Token") or ""
        return bool(self.token) and hmac.compare_digest(got, self.token)

    def _send(self, code: int, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(data)

    def _screen_ok(self) -> bool:
        return self.headers.get("X-My-AI-Assistant") == "1" and self._origin_ok()

    def _json_body(self, limit=64 * 1024):
        if "application/json" not in (self.headers.get("Content-Type") or ""):
            return None
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return None
        if n <= 0 or n > limit:
            return None
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return None

    # ---- GET ----
    def do_GET(self):
        global _last_poll
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            html = (HERE / "index.html").read_bytes()
            return self._send(200, html, "text/html; charset=utf-8")
        if path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if path == "/api/state":
            return self._send(200, build_state())
        if path.startswith("/assets/"):
            root = (HERE / "assets").resolve()
            fp = (root / path[len("/assets/"):]).resolve()
            if root not in fp.parents or not fp.is_file() or fp.suffix.lower() not in CTYPES:
                return self._send(404, {"error": "not found"})
            return self._send(200, fp.read_bytes(), CTYPES[fp.suffix.lower()])
        if path == "/api/settings":   # 画面の設定「アシスタント」：今の値と、既定・上限・使える画像
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            cfg, synced = effective_settings()
            with _lock:
                alive = (time.time() - _last_poll) < 10
            return self._send(200, {"ok": True, "synced": synced, "connected": alive, "settings": cfg,
                                    "defaults": {"displayName": default_name(), "departments": default_departments()},
                                    "limits": dict(LIMITS), "images": list(ROLE_IMAGES), "models": list(MODELS)})
        if path == "/api/health":
            with _lock:
                alive = (time.time() - _last_poll) < 10
            return self._send(200, {"app": APP, "version": self.version, "pluginConnected": alive})
        if path.startswith("/api/jobs/"):
            jid = path[len("/api/jobs/"):]
            with _lock:
                job = _jobs.get(jid)
                view = dict(job) if job else None
            if not view:
                return self._send(404, {"error": "no such job"})
            return self._send(200, view)
        if path.startswith("/api/history/"):   # 全期間の会話（読むだけ・同じパソコンの画面と、プラグインの検索の道具から）
            if not self._origin_ok():
                return self._send(403, {"error": "bad origin"})
            return self._history_get(path)
        if path == "/api/bridge/next":
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            with _lock:
                _last_poll = time.time()
                if not _queue:
                    job = None
                else:
                    job = _jobs[_queue.pop(0)]
                    job["status"] = "running"
                    job = dict(job)
            if not job:
                self.send_response(204)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            return self._send(200, job)
        return self._send(404, {"error": "not found"})

    def _history_get(self, path: str):
        qs = {k: v[0] for k, v in urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).items()}
        try:
            if path == "/api/history/stats":
                return self._send(200, history.stats())
            if path == "/api/history/search":
                res = history.search(qs.get("q", "")[:500], source=qs.get("source") or None, since=qs.get("since") or None,
                                     limit=max(1, min(int(qs.get("limit", 40)), 100)), per_session=3)
                return self._send(200, {"results": res})
            if path == "/api/history/sessions":
                return self._send(200, history.list_sessions(source=qs.get("source") or None, title=qs.get("title") or None,
                                                             offset=max(0, int(qs.get("offset", 0))), limit=max(1, min(int(qs.get("limit", 50)), 200))))
            if path == "/api/history/session":
                s = history.get_session(qs.get("sid", ""), offset=max(0, int(qs.get("offset", 0))), limit=max(1, min(int(qs.get("limit", 300)), 1000)))
                return self._send(200 if s else 404, s or {"error": "not found"})
            if path == "/api/history/memory":
                return self._send(200, {"text": history.memory_index()})
        except ValueError:
            return self._send(400, {"error": "数の指定が正しくありません"})
        except Exception as e:
            return self._send(500, {"error": repr(e)})
        return self._send(404, {"error": "not found"})

    # ---- POST ----
    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = self.path.split("?", 1)[0]
        if path == "/api/ask":  # 画面から
            if self.headers.get("X-My-AI-Assistant") != "1" or not self._origin_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body()
            text = (body or {}).get("text") if isinstance(body, dict) else None
            mode = (body or {}).get("mode", "chat") if isinstance(body, dict) else "chat"
            if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT or mode not in MODES:
                return self._send(400, {"error": "text (1-4000 chars) and mode (agent|chat) required"})
            jid = uuid.uuid4().hex[:12]
            with _lock:
                _jobs[jid] = {"id": jid, "text": text.strip(), "mode": mode, "status": "queued",
                              "answer": None, "created": time.time()}
                _queue.append(jid)
            return self._send(200, {"id": jid})
        if path == "/api/settings":  # 画面から（設定の保存。検証して待ち行列へ。保存するのはプラグイン）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body(MAX_BODY_SETTINGS)
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "JSON の本文が要ります（256KB まで）"})
            try:
                clean = validate_settings(body)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            if not clean:
                return self._send(400, {"ok": False, "error": "変える項目がありません"})
            jid = "settings-" + uuid.uuid4().hex[:8]
            with _lock:
                for i in list(_queue):   # まだ受け取られていない前の保存は、新しい方に置き換える
                    if _jobs[i].get("mode") == "settings":
                        _queue.remove(i)
                        _jobs[i]["status"], _jobs[i]["answer"] = "failed", "新しい保存に置き換わりました"
                _jobs[jid] = {"id": jid, "text": "", "mode": "settings", "kind": "settings", "settings": clean,
                              "status": "queued", "answer": None, "created": time.time()}
                _queue.append(jid)
            return self._send(200, {"ok": True, "id": jid})
        if path == "/api/bridge/settings":  # プラグインから：保存した（または起動時に読んだ）今の設定を知らせる
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body(MAX_BODY_SETTINGS)
            try:
                clean = validate_settings(body)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            global _settings_synced
            with _lock:
                for k in ("displayName", "extraInstructions", "departments"):
                    if k in clean:
                        _settings[k] = clean[k]
                _settings["customDepartments"] = bool(isinstance(body, dict) and body.get("customDepartments"))
                _settings_synced = True
            return self._send(200, {"ok": True})
        if path == "/api/exec/send":  # 画面から（執行役への発言。添付は保存して本文にパスを付ける）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body(MAX_BODY_SEND)
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "JSON の本文が要ります（添付は合計50MBまで）"})
            text = body.get("text")
            text = text.strip() if isinstance(text, str) else ""
            files = body.get("files") or []
            if (not text and not files) or len(text) > MAX_SEND_TEXT:
                return self._send(400, {"ok": False, "error": "発言が空か、長すぎます"})
            try:
                saved = save_attachments(files)
            except ValueError as e:
                return self._send(400, {"ok": False, "error": str(e)})
            lines = "\n".join(f"添付: {x['path']}" for x in saved)
            full = "\n\n".join(x for x in (text, lines) if x)
            jid = uuid.uuid4().hex[:12]
            fl = [{"name": x["name"], "size": x["size"]} for x in saved]
            with _lock:
                _jobs[jid] = {"id": jid, "text": full.strip(), "mode": "chat", "status": "queued", "answer": None,
                              "created": time.time(), "kind": "exec", "display": text, "files": fl}
                _queue.append(jid)
            return self._send(200, {"ok": True, "message": {"id": "p-" + jid, "role": "user", "text": text,
                                                              "ts": now_iso(), "files": fl}})
        if path == "/api/exec/suggest":  # 画面から（入力の予測を頼む。作るのはプラグイン。同じ返事には1回だけ。自動では送らない）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body()
            for_id = str((body or {}).get("for") or "") if isinstance(body, dict) else ""
            st = build_state()["exec"]
            tgt = suggest_target(st["messages"], bool(st["busy"]))
            if not tgt or tgt["id"] != for_id:
                return self._send(200, {"ok": True, "status": "skip"})
            with _lock:
                if _suggest.get("for") == for_id:
                    return self._send(200, {"ok": True, "status": _suggest.get("status")})
                _suggest.clear()
                _suggest.update({"for": for_id, "status": "pending", "text": None, "reason": None})
                recent = [m["text"] for m in st["messages"] if m["role"] == "user" and (m.get("text") or "").strip()][-SUGGEST_RECENT:]
                jid = "suggest-" + uuid.uuid4().hex[:8]
                _jobs[jid] = {"id": jid, "text": "", "mode": "suggest", "kind": "suggest", "forId": for_id, "status": "queued",
                              "reply": (tgt.get("text") or "")[-SUGGEST_TAIL:], "recent": [r[:300] for r in recent],
                              "answer": None, "created": time.time()}
                _queue.append(jid)
            return self._send(200, {"ok": True, "status": "pending"})
        if path == "/api/exec/stop":  # 画面から（いま動いている発言を止める）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            with _lock:
                if not any(_jobs[i].get("mode") == "stop" for i in _queue):
                    jid = "stop-" + uuid.uuid4().hex[:8]
                    _jobs[jid] = {"id": jid, "text": "", "mode": "stop", "status": "queued", "answer": None,
                                  "created": time.time(), "kind": "exec"}
                    _queue.append(jid)
                for i in list(_queue):  # まだ会話に入っていない依頼は取り下げる
                    j = _jobs[i]
                    if j.get("kind") == "exec" and j.get("mode") not in ("stop", "stoptask"):
                        _queue.remove(i)
                        j["status"], j["answer"] = "failed", "止めました"
            return self._send(200, {"ok": True})
        m = re.fullmatch(r"/api/exec/tasks/([^/]{1,128})/stop", path)
        if m:  # 画面から（仕事を1つ止める。止めるのはプラグイン）
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            tid = urllib.parse.unquote(m.group(1))
            with _lock:
                task = next((t for t in _conv["tasks"] if t["id"] == tid), None)
                if not task:
                    return self._send(404, {"ok": False, "error": "その仕事が見つかりません"})
                if task["status"] != "working":
                    return self._send(200, {"ok": True, "stopped": 0})
                if not any(_jobs[i].get("mode") == "stoptask" and _jobs[i].get("taskId") == tid for i in _queue):
                    jid = "stoptask-" + uuid.uuid4().hex[:8]
                    _jobs[jid] = {"id": jid, "text": "", "mode": "stoptask", "taskId": tid, "title": task["title"],
                                  "status": "queued", "answer": None, "created": time.time(), "kind": "exec"}
                    _queue.append(jid)
            return self._send(200, {"ok": True, "stopped": 1})
        if path == "/api/open":  # 画面の「開く」「Finder で表示」
            if not self._screen_ok():
                return self._send(403, {"error": "screen only"})
            body = self._json_body()
            if not isinstance(body, dict):
                return self._send(400, {"ok": False, "error": "path が要ります"})
            try:
                return self._send(200, open_output(str(body.get("path") or ""), bool(body.get("reveal"))))
            except (ValueError, subprocess.SubprocessError, OSError) as e:
                return self._send(400, {"ok": False, "error": str(e)})
        if path == "/api/bridge/state":  # プラグインから（会話の中身）
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body(MAX_BODY_STATE)
            if not isinstance(body, dict):
                return self._send(400, {"error": "state required"})
            msgs = clean_messages(body.get("messages"))
            valid = {d["name"] for d in effective_settings()[0]["departments"]} | {"other"}
            tasks = clean_tasks(body.get("tasks"), valid)
            outs = {p for m in msgs if m["role"] == "files" for p in m["outputs"]} | {p for t in tasks for p in t["outputs"]}
            with _lock:
                _conv.update(messages=msgs, busy=bool(body.get("busy")), busySince=_str(body.get("busySince"), 40),
                             live=_str(body.get("live"), 200), model=_str(body.get("model"), 100),
                             tasks=tasks, outputs=outs, at=time.time(),
                             usage=clean_usage(body.get("usage")), context=clean_context(body.get("context")),
                             owner=clean_owner(body.get("owner")))
            return self._send(200, {"ok": True, "count": len(msgs), "tasks": len(tasks)})
        if path == "/api/bridge/shutdown":  # プラグインから：新しい版が入ったので、持ち主がサーバーを手放す
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            self._send(200, {"ok": True})
            threading.Thread(target=Handler.httpd.shutdown, daemon=True).start()
            return
        if path == "/api/bridge/result":  # プラグインから
            if not self._bridge_ok():
                return self._send(401, {"error": "bridge token required"})
            body = self._json_body()
            if not isinstance(body, dict) or not isinstance(body.get("id"), str):
                return self._send(400, {"error": "id required"})
            with _lock:
                job = _jobs.get(body["id"])
                if not job:
                    return self._send(404, {"error": "no such job"})
                job["status"] = "done" if body.get("ok") else "failed"
                job["answer"] = str(body.get("text") or "")[:20000]
                if job.get("mode") == "suggest":   # 入力の予測：まだ同じ返事が最後のときだけ置く。出すのは ready のときだけ
                    if _suggest.get("for") == job.get("forId"):
                        if not body.get("ok"):   # 作れなかった：failed と短い理由（理由は suggestStatus で見える）
                            _suggest.update(status="failed", text=None, reason=short(job["answer"], 80) or "理由は不明です")
                        else:
                            line = unquote((job["answer"].strip().splitlines() or [""])[0])
                            if not line or line == "なし":
                                _suggest.update(status="none", text=None, reason=None)
                            elif len(line) > SUGGEST_MAX_LEN:
                                _suggest.update(status="failed", text=None, reason=f"予測が長すぎました（{len(line)}字）")
                            else:
                                _suggest.update(status="ready", text=line, reason=None)
                    job["answer"] = ""   # 予測の中身は /api/jobs に残さない
                    return self._send(200, {"ok": True})
                if isinstance(body.get("note"), str) and body["note"].strip():   # 止めるボタンの結果を会話に一言出す
                    _notes.append({"id": "n-" + uuid.uuid4().hex[:8], "role": "note", "text": body["note"][:500], "ts": now_iso()})
                    del _notes[:-20]
            return self._send(200, {"ok": True})
        return self._send(404, {"error": "not found"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8790)
    ap.add_argument("--version", default="?")
    ap.add_argument("--data-dir", default="")
    args = ap.parse_args()
    for stream in (sys.stdout, sys.stderr):   # Windows の既定（cp932 など）で日本語のログが落ちないように
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    global DATA_DIR
    if args.data_dir:
        DATA_DIR = Path(args.data_dir)
    elif not os.environ.get("MYAI_DATA_DIR"):
        msg = migrate_old_data_dir(Path.home())
        if msg:
            sys.stderr.write("[server] " + msg + "\n")
    if args.port == 8787:
        sys.exit("8787 は本番の画面のポートなので使いません")
    history.configure(DATA_DIR / "history.db")
    history.start_background(interval=300)   # 起動時に1回、その後5分ごとに差分を取り込む（裏のスレッド）
    Handler.token = os.environ.get("MYAI_BRIDGE_TOKEN", "")
    Handler.port = args.port
    Handler.version = args.version
    if not Handler.token:
        sys.stderr.write("[server] MYAI_BRIDGE_TOKEN がありません（プラグインからの答えを受け取れません）\n")
    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    Handler.httpd = httpd
    print(f"LISTENING http://127.0.0.1:{args.port}/", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
